# 挑战：配置 kube-proxy 组件

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

在前面的实验《kubeadm 安装》中，我们在阿里云 ECS 服务器上安装配置了一个 `ALL-In-One` 类型的 Kubernetes 集群环境，并且配置了内核模块、内核参数，安装了 ipvsadm 和 ipset 工具，但是集群默认使用的依然是 iptables 模式，本挑战继续在 `ALL-In-One` 类型的 Kubernetes 集群环境中进行操作，要求将 kube-proxy 默认的 iptables 模式修改为 ipvs 模式。

## 目标

- 将 kube-proxy 默认的 iptables 模式修改为 ipvs 模式

## 提示语

- 可以修改 kube-proxy ConfigMap 配置文件，使用命令 `kubectl -n kube-system edit cm kube-proxy`
- 修改完配置文件以后，需要重启 kube-proxy，使用命令 `kubectl -n kube-system rollout restart ds/kube-proxy`

## 知识点

- kube-proxy 组件的配置

## 参考答案

当 Kubernetes 集群运行的服务数量很多时，kube-proxy 工作在 ipvs 模式将获得更好的性能。默认情况下 kube-proxy 允许在 iptables 模式下运行，但我们可以通过修改 kube-proxy ConfigMap 快速将 kube-proxy 切换到 ipvs 模式。

首先，通过下面的命令更新 kube-proxy ConfigMap：

```bash
kubectl -n kube-system edit cm kube-proxy
```

修改 `mode` 字段值为 `ipvs`，如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567215358006/wm)

重启 kube-proxy：

```bash
kubectl -n kube-system rollout restart ds/kube-proxy
```

当重启完成后可以通过如下命令验证 kube-proxy 已经允许在 ipvs 模式下运行：

```bash
kubectl -n kube-system logs -f -l k8s-app=kube-proxy --all-containers
```

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567215565561/wm)

同时通过命令 `ipvsadm -L` 也将会发现各种转发规则已经成功添加。