---
show: step
version: 1.0
---

# API Server 组件

## 1.实验介绍

####  实验内容

本次实验我们将会向大家介绍 Kubernetes API Server 组件。Kubernetes API Server 的核心功能是提供 Kubernetes 各类资源对象（如：Pod、RC、Service 等）的增、删、改、查及 Watch 等 HTTP Rest 接口，成为集群内各个功能模块之间数据交互和通信的中心枢纽，是整个系统的数据中心。

####  实验知识点

- 多种方式访问 API Server
- API Server 工作原理
- 访问控制
- 常用参数介绍
- Kubernetes Proxy API 接口

####  推荐阅读

- [kube-apiserver 全部参数](https://kubernetes.io/zh/docs/reference/command-line-tools-reference/kube-apiserver/)
- [Go 客户端](https://github.com/kubernetes/client-go)
- [Python 客户端](https://github.com/kubernetes-client/python)
- [kubernetes-deep-dive-api-server-part-1](https://blog.openshift.com/kubernetes-deep-dive-api-server-part-1/)
- [Kubernetes API Server, Part I](https://medium.com/@dominik.tornow/kubernetes-api-server-part-i-3fbaf2138a31)

## 2. API Server 概述

Kubernetes API Server 是 Kubernetes 集群最重要的核心组件之一，是唯一能够与存储 etcd 交互通信的组件，主要提供以下功能：

- 整个集群管理的 API 接口：所有对集群进行的查询和管理都要通过 API 来进行
- 集群内部各个模块之间通信的枢纽：所有模块之间不会互相调用，都是通过与 API Server 交互实现对应的功能
- 集群安全控制：API Server 通过提供的验证和授权确保整个集群的安全

###  多种方式访问 API Server

Kubernetes API Server 通过运行在 Master 节点上的名为 kube-apiserver 的进程提供服务：

```bash
$ kubectl get pods -n kube-system|grep kube-apiserver
kube-apiserver-kube-master              1/1     Running   5          28d
```

1. 使用 `curl` 命令访问

默认情况下，kube-apiserver 进程在 Master 节点的 8080 端口提供 REST 服务，在启动服务之后可以使用 docker 命令进入 Master 节点查看 Kubernetes API 版本信息：

```bash
$ docker exec -it d3026facb149 /bin/bash
root@kube-master:/# curl localhost:8080/api
{
  "kind": "APIVersions",
  "versions": [
    "v1"
  ],
  "serverAddressByClientCIDRs": [
    {
      "clientCIDR": "0.0.0.0/0",
      # 6443 端口是 HTTPS 安全端口，可以加强 REST API 访问的安全性
      # 8080 端口是 HTTP 端口，可以直接访问，但是由于没有做任何认证授权机制，不建议生产环境使用
      "serverAddress": "10.192.0.2:6443"
    }
  ]
}
```

比如我们也可以使用命令 curl 直接访问 `http://10.192.0.2:8080` 地址查看 API Server 提供了哪些接口：

```bash
$ curl http://10.192.0.2:8080
{
  "paths": [
    "/api",
    "/api/v1",
    "/apis",
    "/apis/",
    "/apis/admissionregistration.k8s.io",
    "/apis/admissionregistration.k8s.io/v1beta1",
    "/apis/apiextensions.k8s.io",
    "/apis/apiextensions.k8s.io/v1beta1",
    "/apis/apiregistration.k8s.io",
    "/apis/apiregistration.k8s.io/v1",
    "/apis/apiregistration.k8s.io/v1beta1",
    "/apis/apps",
......
```

2. 使用 `浏览器` 访问

在火狐浏览器地址栏输入 `http://10.192.0.2:8080` 可以看到返回的 JSON 信息：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190915-1568547210362/wm)

3. 使用 `kubectl` 命令行工具

```bash
$ kubectl get --raw /api
{"kind":"APIVersions","versions":["v1"],"serverAddressByClientCIDRs":[{"clientCIDR":"0.0.0.0/0","serverAddress":"10.192.0.2:6443"}]}
```

还可以使用命令 `kubectl proxy` 启动代理：

```bash
$ kubectl proxy --port=8080
Starting to serve on 127.0.0.1:8080

# 新开一个终端执行如下命令，可以发现由于启动了代理，我们可以在本地的 8080 端口访问 API Server
$ curl http://localhost:8080/api
{
  "kind": "APIVersions",
  "versions": [
    "v1"
  ],
  "serverAddressByClientCIDRs": [
    {
      "clientCIDR": "0.0.0.0/0",
      "serverAddress": "10.192.0.2:6443"
    }
  ]
}
```

4. 通过编程方式访问 API

kubernetes 官方支持的客户端库有 [Go](https://github.com/kubernetes/client-go) 和 [Python](https://github.com/kubernetes-client/python) 客户端。

###  API Server 工作原理

API Server 的架构如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190915-1568553660892/wm)

整个 API Server 从上往下大致可以分为如下 4 层：

1. `API 层`：主要以 REST 方式提供各种 API 接口，包括：对 kubernetes 资源对象进行 CRUD 和 watch 等操作的核心/分组 API，提供健康检查、UI、日志、性能指标等运维监控相关的 API。

2. `访问控制层`：当客户端访问 API 接口时，访问控制层负责对用户身份鉴权，验明用户身份，核准用户对 kubernetes 资源对象的访问权限，然后根据配置的各种资源访问许可逻辑(Admisson Control)，判断是否允许访问。

3. `注册表层`：kubernetes 把所有资源对象都保存在注册表(Registery)中，并且对于所有的资源对象都定义了：资源对象的类型、如何创建资源对象、如何转换资源的不同版本、以及如何将资源编码和解码为 JSON 或 ProtoBuf 格式进行存储。

4. `etcd 数据库`：用于持久化存储 kubernetes 资源对象的 key-value 数据库。

#### 集群功能模块之间的通信

那么集群中其它的重要的功能模块具体是如何与 API Server 进行交互的呢？

kubelet 与 API Server 的交互：

- 每个 Node 节点上的 kubelet 每隔一段时间向 API Server 的 REST 接口发送自身的状态信息；
- API Server 收到信息后更新到 etcd 中；
- kubelet 通过 API Server 的 watch 接口监听 Pod 的实时变化信息，如果监听到有新的 Pod 对象绑定到这个节点，就创建 Pod；如果是删除某个 Pod，也执行对应的操作。

kube-scheduler 与 API Server 的交互：

- kube-scheduler 通过 API Server 的 watch 接口监听到新建 Pod 副本的信息后，会检索所有符合该 Pod 要求的 Node 列表，开始执行 Pod 调度逻辑，调度成功后将 Pod 绑定到目标节点上。

kube-controller-manager 与 API Server 的交互：

- kube-controller-manager 中的 Node Controller 模块通过 API Server 的 watch 接口实时监控 Node 的信息，并做对应的处理。

为了缓解 API Server 过高的访问负荷，kubernetes 系统提供了缓存机制。各功能模块定时从 API Server 获取指定的资源对象信息（使用 List/Watch 方法），然后保存到本地缓存，各功能模块在某些情况下通过访问缓存获取需要的信息，以便减轻 API Server 的压力。

###  访问控制

kubernetes API 的每个请求都会经过多阶段的访问控制之后才会被接受，整个阶段包括：认证(Authentication)、授权(Authorization)、准入控制(Admisson Control)。

流程如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190915-1568550059541/wm)

1. 认证(Authentication)：开启 TLS 后，所有请求都必须要经过认证。kubernetes 支持多种认证机制，并支持同时开启多个认证插件（只要有一个认证通过即可）。如果认证成功，用户的 username 会被传入授权模块做授权验证，如果认证失败会返回 HTTP 401。目前常用的方式有两种：Token 或是 SSL。

2. 授权(Authorization)：通过认证的请求就传递到了授权模块，kubernetes 支持多种授权机制，并支持同时开启多个授权插件（只要有一个授权通过即可）。如果认证成功，用户的请求会发送到准入控制模块进行请求验证，如果授权失败会返回 HTTP 403。目前常用的方式有四种：ABAC(基于属性的访问控制)、RBAC(基于角色的访问控制)、NODE(基于节点的访问控制)、Webhook(自定义 HTTP 回调的访问控制)

3. 准入控制(Admisson Control)：对请求进一步验证或添加默认参数，认证和授权分别处理了请求的用户和操作，准入控制模块则处理请求的内容，它只对创建、更新、删除或连接（如代理）等有效，对读操作无效。准入控制也支持同时开启多个插件，它们依次调用，只有全部插件都通过的请求才能够获取到最终的数据。

###  常用参数介绍

kube-apiserver 常用且比较重要的参数如下所示：

- `--advertise-address`：向集群成员通知 apiserver 消息的 IP 地址。这个地址必须能够被集群中其他成员访问。如果 IP 地址为空，将会使用 --bind-address，如果未指定 --bind-address，将会使用主机的默认接口地址
- `--allow-privileged`：是否允许特权容器运行，默认值为 false
- `--admission-control`：控制资源进入集群的准入控制插件的顺序列表，逗号分隔的 NamespaceLifecycle 列表，默认值为 [AlwaysAdmit]
- `--authorization-mode`：在安全端口上进行权限验证的插件的顺序列表，以逗号分隔的列表，包括：AlwaysAllow、AlwaysDeny、ABAC、Webhook、RBAC、Node，默认值为 [AlwaysAllow]
- `--bind-address`：HTTPS 安全接口的监听地址，监听 --seure-port 的 IP 地址。如果为空，则将使用所有接口（0.0.0.0），默认值为 0.0.0.0
- `--secure-port`：HTTPS 安全接口的监听端口，用于监听具有认证授权功能的 HTTPS 协议的端口。如果为 0，则不会监听 HTTPS 协议，默认值为 6443
- `--cert-dir`：存放 TLS 证书的目录，如果提供了 --tls-cert-file 和--tls-private-key-file 选项，该标志将被忽略，默认值为 "/var/run/kubernetes"
- `--etcd-prefix`：附加到所有 etcd 中资源路径的前缀，默认值为 "/registry"
- `--etcd-servers`：连接的 etcd 服务器列表，形式为（scheme://ip:port)，使用逗号分隔
- `--insecure-bind-address`：HTTP 访问的地址，用于监听 --insecure-port 的 IP 地址，设置成 0.0.0.0 表示监听所有接口，默认值为 127.0.0.1
- `--insecure-port`：HTTP 访问的端口，用于监听不安全和为认证访问的端口。这个配置假设你已经设置了防火墙规则，使得这个端口不能从集群外访问，对集群的公共地址的 443 端口的访问将被代理到这个端口，默认设置中使用 nginx 实现，默认值为 8080
- `--service-cluster-ip-range`：CIDR 表示的 IP 范围，服务的 cluster ip 将从中分配，一定不要和分配给 nodes 和 pods 的 IP 范围产生重叠

大家可以查看环境中 kube-apiserver 的启动参数：

```bash
$ docker exec -it kube-master /bin/bash
root@kube-master:/# netstat -nap|grep -E '8080|6443'
...
root@kube-master:/# ps -ef|grep -v grep|grep kube-apiserver
...
```

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190915-1568560219426/wm)

###  Kubernetes Proxy API 接口

kubernetes API Server 最主要的 REST 接口是对资源对象执行 CRUD 操作的接口，但是它还有一类很特殊的 REST 接口 -- Kubernetes Proxy API 接口，这类接口的作用是代理 REST 请求，即 kubernetes API Server 把收到的 REST 请求转发到某个 Node 节点上的 kubelet 守护进程的 REST 端口，由该 kubelet 进程负责响应。

#### Node 相关接口

与 Node 相关接口的 REST 路径为 `/api/v1/nodes/{name}/proxy`，其中 {name} 是节点的名称或是 IP 地址。

比如在浏览器访问地址 `http://127.0.0.1:32768/api/v1/nodes/kube-node-1/proxy/pods` 获取 kube-node-1 节点上所有的 pod 信息，结果如下所示：（注意这里获取的数据信息来自于 Node 而不是 etcd 数据库，所以数据有时可能存在一定偏差）

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190916-1568602875884/wm)

还有一些其它的接口：

```text
/api/v1/nodes/{name}/proxy/pods   # 列出指定节点内所有 pod 的信息
/api/v1/nodes/{name}/proxy/stats  # 列出指定节点内物理资源的统计信息
/api/v1/nodes/{name}/proxy/spec   # 列出指定节点的概要信息
/api/v1/nodes/{name}/proxy/logs   # 列出指定节点的各类日志信息
/api/v1/nodes/{name}/proxy/metrics # 列出指定节点的 Metrics 信息
```

#### Pod 相关接口

通过 Pod proxy 接口，我们可以访问 Pod 里面某个容器提供的服务。通常与 Pod 相关接口的 REST 路径为：

```text
/api/v1/namespaces/{namespace}/pods/{name}/proxy  # 访问 Pod
/api/v1/namespaces/{namespace}/pods/{name}/proxy/{path:*}  # 访问 Pod 服务的 URL 路径
```

比如我们部署前面提过的 Tomcat Pod，在 `/home/shiyanlou` 目录下新建 `tomcat.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: ReplicationController
metadata:
  name: myweb # rc 的名称为 myweb
spec:
  replicas: 1 # 只需要创建一个 pod 副本
  selector:
    app: myweb # 选择那些具有 app=myweb 标签的 pod
  template:
    metadata:
      labels:
        app: myweb # 创建的 pod 副本拥有的标签为 app=myweb
    spec:
      containers:
      - name: myweb # 容器名为 myweb
        image: kubeguide/tomcat-app:v1
        ports:
        - containerPort: 8080 # 容器暴露出来的端口为 8080 端口
```

执行创建，然后获取对应的 Pod：

```bash
$ kubectl get pods
NAME          READY   STATUS    RESTARTS   AGE
myweb-wsksc   1/1     Running   0          52s
```

然后在浏览器访问地址 `http://127.0.0.1:32768/api/v1/namespaces/default/pods/myweb-wsksc/proxy/` 就可以访问到 Tomcat 的首页了：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190916-1568604257877/wm)

所以在 kubernetes 集群之外想要访问某个 Pod 容器的 HTTP 服务时，就可以使用 Proxy API 实现。

#### Service 相关接口

与 Service 相关接口的 REST 路径为 `/api/v1/namespaces/{namespace}/services/{name}/proxy`。

比如我们执行脚本启动集群，最后提供了可以访问 dashboard 界面的路径地址：

```text
* Access dashboard at: http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/kubernetes-dashboard:/proxy
* Access dashboard at: http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy (if version>1.6 and HTTPS enabled)
```

在浏览器中访问第二个地址，可以看到 dashboard 的认证页面：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190916-1568604952410/wm)

可以进一步查看 dashboard 在哪一个 Node 节点上：

```bash
$ docker exec -it kube-node-2 /bin/bash
root@kube-node-2:/# docker ps|grep dashboard
00ee7efc72e5        f9aed6605b81           "/dashboard --insecu\u2026"   About an hour ago   Up About an hour                        k8s_kubernetes-dashboard_kubernetes-dashboard-5ff478f859-x7kv5_kube-system_f811c05e-3956-4be8-a0bb-39432f751e12_0
23b738333c81        k8s.gcr.io/pause:3.1   "/pause"                 About an hour ago   Up About an hour                        k8s_POD_kubernetes-dashboard-5ff478f859-x7kv5_kube-system_f811c05e-3956-4be8-a0bb-39432f751e12_0
root@kube-node-2:/#
```

这样就知道了，我们通过前面的 REST 路径访问到了位于 kube-node-2 节点上的 dashboard Service。

## 3. 实验总结

本次实验我们向大家介绍了如下知识点：

- 多种方式访问 API Server
- API Server 工作原理
- 访问控制
- 常用参数介绍
- Kubernetes Proxy API 接口

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。