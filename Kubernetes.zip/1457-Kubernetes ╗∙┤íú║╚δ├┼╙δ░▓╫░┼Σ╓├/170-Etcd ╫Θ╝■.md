---
show: step
version: 1.0
---

# Etcd 组件

## 1.实验介绍

####  实验内容

本节实验我们将带领大家学习 Etcd 组件。Etcd 组件是 kubernetes 集群中非常重要的组件，用于保存集群所有的网络配置和对象的状态信息。

####  实验知识点

- Etcd 工作原理：Raft 协议
- Etcd v2 和 v3 的区别
- Etcd 安装与简单使用
- Etcd 在 kubernetes 中的应用

####  推荐阅读

- [etcd 官网](https://etcd.io/)
- [raft 官网](https://raft.github.io/)
- [raft 一致性算法动画演示](http://thesecretlivesofdata.com/raft/)
- [etcd：从应用场景到实现原理的全方位解读](https://www.infoq.cn/article/etcd-interpretation-application-scenario-implement-principle/)

## 2. Etcd 数据库概述

[Etcd](https://github.com/coreos/etcd/) 是 CoreOS 基于 raft 一致性算法协议开发的一款高可用分布式 key-value 存储数据库，可用于服务发现、共享配置以及一致性保障。数据库本身是基于 Go 语言实现，目前最新版本为 3.4 版本。

Etcd 数据库在设计的时候主要考虑了 4 个要素：

- 简单：具有定义良好、面向用户的 API（gRPC）
- 安全：基于 HTTPS 方式访问
- 快速：支持并发 10K/s 的写操作
- 可靠：支持分布式结构，基于 raft 一致性算法

它的主要功能特点有：

- 基本的 key-value 存储
- 监听机制
- key 的过期及续约机制，用于监控和服务发现
- 原子 CAS 和 CAD，用于分布式锁和 leader 选举

###  Etcd 工作原理：Raft 协议

Etcd 使用的是 Raft 协议实现的，Raft 是一套通过选取主节点来实现分布式系统一致性的算法。关于 Raft 一致性算法可以参考[raft 一致性算法动画演示](http://thesecretlivesofdata.com/raft/)。

如下图所示，每个 ETCD 节点都维护了一个状态机，在任意时刻最多存在一个有效的主节点，主节点处理所有来自客户端的写操作，通过 Raft 协议保证写操作对状态机的改动会可靠的同步到其它节点。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190916-1568624463187/wm)

Raft 协议主要分为 3 个部分：选主、日志复制、安全性。

#### 选主

Raft 协议是用于维护一组服务节点数据一致性的协议。这一组服务节点构成一个集群，并且有一个主节点来对外提供服务。当集群初始化或主节点挂掉后，面临一个选主问题。集群中每个节点，任意时刻处于 Leader、Follower、Candidate(候选) 这三个角色之一，选举特点如下：

- 当集群初始化的时候，每个节点都是 Follower 角色；
- 集群中存在最多一个有效的主节点，主节点通过 heartbeat 与其它节点同步数据；
- 当 Follower 在一定时间内没有收到来自主节点的 heartbeat，会将自己的角色改变成为 Candidate，并发起一次选主投票；当收到集群中过半数节点(包括自己在内)的接收投票后，选举成功，该节点成为 Leader，开始接收保存 Client 的数据并向其它的 Follower 节点同步日志。如果票数不足半数或超时则选举失败。如果本轮没有选举出主节点，将进行下一轮选举。
- Candidate 节点收到来自主节点的信息后，会立即终止选举过程，进入 Follower 角色；
- 为了避免陷入选主失败的循环，每个节点因为没有收到 heartbeat 而发起选举的时间是一定范围内的随机值，这样可以避免 2 个节点同时发起选主。

#### 日志复制

日志复制指的是：主节点将每次操作形成日志条目，并持久化到本地磁盘，然后通过网络 I/O 发送给其它节点。当前 Leader 收到 Client 的事务请求后，先把该日志追加到本地 Log 中，然后通过 heartbeat 把日志同步给其它 Follower，Follower 接收到日志后记录日志然后向 Leader 发送 ACK，当 Leader 收到超过半数 Follower 的 ACK 信息后将该日志设置为已提交并追加到本地磁盘中，将结果返回给 Client，在下一个 heartbeat 中 Leader 将通知所有的 Follower 将该日志持久化到本地。

#### 安全性

选举以及日志复制并不能保证节点间数据完全一致。有一种可能性为：如果某个节点挂掉并在一定时间以后恢复重启，由于挂掉的时候会缺失部分日志，若这个节点当选为 Leader，那么不完整的日志记录会覆盖掉其它节点上完整的日志数据。所以 Raft 协议在选主逻辑中，对能够成为 Leader 的节点加以限制，确保选出的主节点一定包含集群已经提交的所有日志数据。

#### 节点数量为奇数

根据 Raft 协议，节点越多，会降低集群的写性能。在同等配置条件下，节点越少，集群性能越高。并且通常按照需求将部署节点数量定为 3、5、7 ... 等奇数个节点。主要原因是偶数个节点集群不可靠风险更高，在选主的过程中，存在较大概率获得等额选票，导致触发下一轮的选举。

###  Etcd v2 和 v3 的区别

Etcd v2 和 v3 从本质上来说是共享同一套 raft 协议代码的两个独立应用，这两个版本的接口不同，存储不同，数据之间互相隔离、互不兼容。就是说使用 v2 版本创建的数据只能使用 v2 的 API 接口访问，使用 v3 版本创建的数据只能使用 v3 的 API 接口访问。在 kubernetes 集群中推荐使用的是 Etcd v3 版本，Etcd v2 版本在 kubernetes v1.11 中已经被弃用。

## 3. Etcd 安装与简单使用

首先下载安装 Go 程序：

```bash
wget https://dl.google.com/go/go1.13.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.13.linux-amd64.tar.gz
vim /home/shiyanlou/.zshrc # 向文件末尾添加 export PATH=/usr/local/go/bin/:$PATH
source /home/shiyanlou/.zshrc
go version # 输出 go version go1.13 linux/amd64 表示安装成功
```

然后安装 Etcd 单机版本：

```bash
mkdir /home/shiyanlou/etcd/
# 解压的时候可能有一些 Ignoring 的警告，可以忽略
wget https://labfile.oss.aliyuncs.com/courses/1104/etcd-v3.4.0-linux-amd64.tar.gz
tar zxf etcd-v3.4.0-linux-amd64.tar.gz -C /home/shiyanlou/etcd/ --strip-components=1
```

安装成功后，进入目录 /home/shiyanlou/etcd，可以看到目录下有两个二进制文件分别为 `etcd` 和 `etcdctl`，其中 `etcd` 是 server 端，`etcdctl` 是 client 端。

查看 etcd 和 etcdctl 的版本情况：

```bash
$ /home/shiyanlou/etcd/etcd --version
etcd Version: 3.4.0
Git SHA: 898bd1351
Go Version: go1.12.9
Go OS/Arch: linux/amd64
$ ETCDCTL_API=3 /home/shiyanlou/etcd/etcdctl version
etcdctl version: 3.4.0
API version: 3.4
```

启动单节点 etcd：

```bash
$ /home/shiyanlou/etcd/etcd
[WARNING] Deprecated '--logger=capnslog' flag is set; use '--logger=zap' flag instead
2019-09-17 08:48:17.076142 I | etcdmain: etcd Version: 3.4.0
2019-09-17 08:48:17.076188 I | etcdmain: Git SHA: 898bd1351
2019-09-17 08:48:17.076224 I | etcdmain: Go Version: go1.12.9
2019-09-17 08:48:17.076256 I | etcdmain: Go OS/Arch: linux/amd64
2019-09-17 08:48:17.076288 I | etcdmain: setting maximum number of CPUs to 2, total number of available CPUs is 2
2019-09-17 08:48:17.076364 W | etcdmain: no data-dir provided, using default data-dir ./default.etcd
2019-09-17 08:48:17.076446 N | etcdmain: the server is already initialized as member before, starting as etcd member...
[WARNING] Deprecated '--logger=capnslog' flag is set; use '--logger=zap' flag instead
2019-09-17 08:48:17.076949 I | embed: name = default
2019-09-17 08:48:17.076961 I | embed: data dir = default.etcd
2019-09-17 08:48:17.076968 I | embed: member dir = default.etcd/member
2019-09-17 08:48:17.077007 I | embed: heartbeat = 100ms
2019-09-17 08:48:17.077039 I | embed: election = 1000ms
2019-09-17 08:48:17.077070 I | embed: snapshot count = 100000
2019-09-17 08:48:17.077127 I | embed: advertise client URLs = http://localhost:2379
2019-09-17 08:48:17.077138 I | embed: initial advertise peer URLs = http://localhost:2380
2019-09-17 08:48:17.077171 I | embed: initial cluster = 
2019-09-17 08:48:17.078767 I | etcdserver: restarting member 8e9e05c52164694d in cluster cdf818194e3a8c32 at commit index 4
raft2019/09/17 08:48:17 INFO: 8e9e05c52164694d switched to configuration voters=()
raft2019/09/17 08:48:17 INFO: 8e9e05c52164694d became follower at term 2
raft2019/09/17 08:48:17 INFO: newRaft 8e9e05c52164694d [peers: [], term: 2, commit: 4, applied: 0, lastindex: 4, lastterm: 2]
2019-09-17 08:48:17.081170 W | auth: simple token is not cryptographically signed
2019-09-17 08:48:17.082284 I | etcdserver: starting server... [version: 3.4.0, cluster version: to_be_decided]
raft2019/09/17 08:48:17 INFO: 8e9e05c52164694d switched to configuration voters=(10276657743932975437)
2019-09-17 08:48:17.083038 I | etcdserver/membership: added member 8e9e05c52164694d [http://localhost:2380] to cluster cdf818194e3a8c32
2019-09-17 08:48:17.083203 N | etcdserver/membership: set the initial cluster version to 3.4
2019-09-17 08:48:17.083317 I | etcdserver/api: enabled capabilities for version 3.4
2019-09-17 08:48:17.084568 I | embed: listening for peers on 127.0.0.1:2380
raft2019/09/17 08:48:18 INFO: 8e9e05c52164694d is starting a new election at term 2
raft2019/09/17 08:48:18 INFO: 8e9e05c52164694d became candidate at term 3
raft2019/09/17 08:48:18 INFO: 8e9e05c52164694d received MsgVoteResp from 8e9e05c52164694d at term 3
raft2019/09/17 08:48:18 INFO: 8e9e05c52164694d became leader at term 3
raft2019/09/17 08:48:18 INFO: raft.node: 8e9e05c52164694d elected leader 8e9e05c52164694d at term 3
2019-09-17 08:48:18.879525 I | etcdserver: published {Name:default ClientURLs:[http://localhost:2379]} to cluster cdf818194e3a8c32
2019-09-17 08:48:18.879705 I | embed: ready to serve client requests
2019-09-17 08:48:18.880570 N | embed: serving insecure client requests on 127.0.0.1:2379, this is strongly discouraged!
```

根据上面的输出我们可以知道：

- `name` 表示节点名，默认为 default
- `data dir` 表示保存日志和快照的目录，默认为当前工作目录 ./default.etcd
- `heartbeat` 为 100ms，表示 Leader 间隔多长时间发送一次 heartbeat 到 Follower，默认值为 100ms
- `election` 为 1000ms，表示重新投票的超时时间，如果 Follower 在该段时间间隔没有收到 heartbeat 就会触发重新投票，默认值为 1000ms
- `snapshot count` 为 100000，表示指定有多少事务被提交时，触发截图快照保存到磁盘
- `http://localhost:2379` 提供 HTTP API 服务，供 client 交互
- `http://localhost:2380` 和集群中其它节点通信
- 集群和每个节点都会生成一个 uuid
- 启动的时候会运行 raft，选举出 Leader

`etcdctl` 是一个命令行客户端，可以通过它使用简单的命令与 `etcd` 服务端进行交互。`etcdctl` 的命令分为两类：数据库操作、非数据库操作。

###  数据库操作

数据库操作围绕对键值和目录的增、删、改、查（CRUD）操作，etcd 在键的组织上采用了层次化的空间结构，键可以是单独的名字，放在根目录 `/` 下，比如：foo，也可以是指定的目录结构，比如：/cluster/node1/foo。

`etcdctl` 目前 V3 版本兼容 V2 版本的接口 API，所以在使用 `etcdctl` 时要指定使用的 API 版本，一般有两种方式：

- 设置环境变量：`export ETCDCTL_API=3`（这种方式更加方便）
- 在每个执行的命令前加上：`ETCDCTL_API=3`

比如执行简单的读写操作，put 用于指定某个键的值，get 用于获取某个键的值，del 用于删除键值：

```bash
# 设置环境变量
$ export ETCDCTL_API=3

# 键是名字
$ /home/shiyanlou/etcd/etcdctl put foo bar
OK
$ /home/shiyanlou/etcd/etcdctl get foo
foo
bar

# 键是目录
$ /home/shiyanlou/etcd/etcdctl put /testdir/testkey "shiyanlou"
OK
$ /home/shiyanlou/etcd/etcdctl get /testdir/testkey
/testdir/testkey
shiyanlou

# 删除操作
$ /home/shiyanlou/etcd/etcdctl del foo
1
```

###  非数据库操作

`watch`：用于检测一个键值的变化，如果键值发生更新，会输出最新的值或执行指定命令。

输出最新的值：

```bash
# 在一个终端执行如下命令
$ /home/shiyanlou/etcd/etcdctl watch /testdir/testkey

# 新开一个终端执行如下命令
$ /home/shiyanlou/etcd/etcdctl put /testdir/testkey "shiyanlou-test"
OK
$ /home/shiyanlou/etcd/etcdctl put /testdir/testkey "shiyanlou-test-2"
OK
$ /home/shiyanlou/etcd/etcdctl del /testdir/testkey
1

# 这个时候可以看到前面那个终端有了如下的输出
$ /home/shiyanlou/etcd/etcdctl watch /testdir/testkey
PUT
/testdir/testkey
shiyanlou-test
PUT
/testdir/testkey
shiyanlou-test-2
DELETE
/testdir/testkey
```

执行指定的命令：

```bash
# 在一个终端执行如下命令
$ /home/shiyanlou/etcd/etcdctl watch /testdir/testkey -- sh -c 'ls'

# 新开一个终端执行如下命令
$ /home/shiyanlou/etcd/etcdctl put foo bar
OK

# 这个时候可以看到前面那个终端有了如下的输出，这里检测到 foo 键的变化就执行了 ls 命令
$ /home/shiyanlou/etcd/etcdctl watch foo -- sh -c 'ls'
PUT
foo
bar
Code	      dind-cluster-v1.15.sh  etcd			     Music     Templates
default.etcd  Documents		     etcd-v3.4.0-linux-amd64.tar.gz  Pictures  Videos
Desktop       Downloads		     go1.13.linux-amd64.tar.gz	     Public
```

`member`：对于 etcd 实例进行操作，常用的命令有：list、add、remove、update 等。

```bash
$ /home/shiyanlou/etcd/etcdctl member list
8e9e05c52164694d, started, default, http://localhost:2380, http://localhost:2379, false
```

###  docker 容器搭建 etcd 集群

如果大家想要体验使用 docker 容器搭建一个 3 节点的 etcd 集群，可以参考 [etcd_cluster.sh](https://gist.github.com/jolestar/6644dee696dcdce432caa46705ddc7ba)。

最终搭建出来的使用效果如下所示：

```bash
$ docker run -it --name client --network etcd quay.io/coreos/etcd sh
/ # ETCDCTL_API=3 etcdctl --endpoints http://172.19.1.10:2379,http://172.19.1.11:2379,http://172.19.1.12:2379 put
 foo bar
OK
/ # ETCDCTL_API=3 etcdctl --endpoints http://172.19.1.10:2379,http://172.19.1.11:2379,http://172.19.1.12:2379 get
 foo
foo
bar
/ # ETCDCTL_API=3 etcdctl --endpoints http://172.19.1.10:2379,http://172.19.1.11:2379,http://172.19.1.12:2379 mem
ber list
461f12caf6d7b8, started, etcd2, http://172.19.1.12:2380, http://172.19.1.12:2379,http://172.19.1.12:4001
4a5773597c53f4af, started, etcd1, http://172.19.1.11:2380, http://172.19.1.11:2379,http://172.19.1.11:4001
ccf63ebba7c44b18, started, etcd0, http://172.19.1.10:2380, http://172.19.1.10:2379,http://172.19.1.10:4001
```

## 4. Etcd 在 kubernetes 中的应用

在 kubernetes 集群中，Etcd 被用作服务发现和集群状态、配置存储的后端，Etcd 实例被部署运行在 Master 节点的 Pod 中。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568705516441/wm)

下面的图片展示了一个 Pod 完整的创建过程，可以清楚的看到 API Server 与 Etcd 之间的交互：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568706022279/wm)

首先我们查看 etcd Pod 的名称，可以看到这个 Pod 属于 kube-system 命名空间：

```bash
$ kubectl get pods --all-namespaces | grep etcd
kube-system   etcd-kube-master                        1/1     Running   5          30d
```

在终端执行如下命令获取 etcd-kube-master Pod 中关于 etcd 容器运行的配置信息：

```bash
# 获取 etcd 的 HTTP API 端口
$ kubectl exec -it -n kube-system etcd-kube-master -- ps aux
PID   USER     TIME  COMMAND
    1 root      0:07 etcd --advertise-client-urls=https://10.192.0.2:2379 --cer
  689 root      0:00 ps aux
```

根据上面获取到的 API 端口，我们可以使用 etcdctl 命令行工具获取到所有已经存在的 key-value 键值对数据并将其保存到 etcd-kv.json 文件中：

```bash
ADVERTISE_URL="https://10.192.0.2:2379"

# 参数  --prefix=true 表示获取所有 key 值头为某个字符串的数据
kubectl exec etcd-kube-master -n kube-system -- sh -c \
"ETCDCTL_API=3 etcdctl \
--endpoints $ADVERTISE_URL \
--cacert /etc/kubernetes/pki/etcd/ca.crt \
--key /etc/kubernetes/pki/etcd/server.key \
--cert /etc/kubernetes/pki/etcd/server.crt \
get \"\" --prefix=true -w json" > etcd-kv.json
```

获取到所有数据之后可以查看文件中的信息，如下所示（其中的数据都使用 base64 编码）：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568713402670/wm)

但是这样的原始数据并不方便查看，让我们通过组合的命令从文件中提取出所有的 keys 并将其保存到 keys.txt 文件中：

```bash
sudo apt-get install -y jq

for k in $(cat etcd-kv.json | jq '.kvs[].key' | cut -d '"' -f2); do echo $k | base64 --decode; echo; done > keys.txt
```

最后 keys.txt 文件中的 keys 如下所示：（部分截图）

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568713828495/wm)

文件中的 keys 都是用于保存集群中所有资源对象的配置信息和状态，大致可以分为如下几类：

- Nodes
- Namespaces
- ServiceAccounts
- Roles 和 RoleBinding、ClusterRoles 和 ClusterRolesBinding
- ConfigMaps
- Secrets
- Workloads：Deployments、DaemonSets、Pods 等
- 集群证书
- 每个 apiVersion 的资源
- 集群当前状态的所有事件

观察 keys 的格式可以发现：

- kubernetes 把数据都注册到了 `/registry/` 前缀下面（Etcd v3 版本不再使用目录的称呼，而是一切皆前缀）
- kubernetes 中资源对象 key 的格式都为 `/registry/${资源对象的名称}/${命名空间}/${实例名称}`
- 存在一个 key 名为 compact_rev_key，这里用来记录无效数据版本使用的

同样的，可以获取到具体 key 对应的 value 值，比如这里获取 `/registry/deployments/kube-system/coredns` 对应的值：

```bash
kubectl exec etcd-kube-master -n kube-system -- sh -c \
"ETCDCTL_API=3 etcdctl \
--endpoints $ADVERTISE_URL \
--cacert /etc/kubernetes/pki/etcd/ca.crt \
--key /etc/kubernetes/pki/etcd/server.key \
--cert /etc/kubernetes/pki/etcd/server.crt \
get \"/registry/deployments/kube-system/coredns\" --prefix=true "
```

结果如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568717615478/wm)

输出结果中有一些奇怪的无法正常显示的字符，这是因为 etcd 中保存的并不是用户友好的数据，它保存的是 Protocol Buffers 序列化后的数据，也就是将 key-value 值按照特定的算法进行压缩，由于没有压缩得特别厉害，所以这里查看值也可以获取到一些可读的数据。

现在我们可以创建一个新的 Pod，检查整个集群的状态如何被修改以及有哪些新的 keys 添加，在终端执行如下命令创建一个名为 www 的 nginx Pod：

```bash
cat <<EoF | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: www
spec:
  containers:
  - name: nginx
    image: nginx:1.16-alpine
EoF
```

在执行创建以后，使用和前面同样的命令获取到 etcd 数据库中所有的数据并提取 keys 将其保存到 keys-after-nginx-pod.txt 文件中：

```bash
kubectl exec etcd-kube-master -n kube-system -- sh -c \
"ETCDCTL_API=3 etcdctl \
--endpoints $ADVERTISE_URL \
--cacert /etc/kubernetes/pki/etcd/ca.crt \
--key /etc/kubernetes/pki/etcd/server.key \
--cert /etc/kubernetes/pki/etcd/server.crt \
get \"\" --prefix=true -w json" > etcd-kv-after-nginx-pod.json

for k in $(cat etcd-kv-after-nginx-pod.json | jq '.kvs[].key' | cut -d '"' -f2); do echo $k | base64 --decode; echo; done > keys-after-nginx-pod.txt
```

查找 keys-after-nginx-pod.txt 文件中与 www 有关的 keys：

```bash
$ cat keys-after-nginx-pod.txt|grep www
/registry/events/default/www.15c52dae20087f6b
/registry/events/default/www.15c52dae534c3671
/registry/events/default/www.15c52db0385d35f3
/registry/events/default/www.15c52db03a7d30f8
/registry/events/default/www.15c52db047fbd0fe
/registry/pods/default/www
```

这里显示一共有 6 个 keys，其中有 5 个是产生的 events key，剩下一个是 pod key。这 5 个事件是如何产生的呢？执行如下命令获取可以查看到相关信息：

```bash
$ kubectl get pod www
Events:
  Type    Reason     Age    From                  Message
  ----    ------     ----   ----                  -------
  Normal  Scheduled  7m58s  default-scheduler     Successfully assigned default/www to kube-node-1
  Normal  Pulling    7m58s  kubelet, kube-node-1  Pulling image "nginx:1.16-alpine"
  Normal  Pulled     7m49s  kubelet, kube-node-1  Successfully pulled image "nginx:1.16-alpine"
  Normal  Created    7m49s  kubelet, kube-node-1  Created container nginx
  Normal  Started    7m49s  kubelet, kube-node-1  Started container nginx
```

按照时间顺序我们可以猜测到上面的 5 个事件与 `/registry/events/default/www.xxx` 有一一对应的关系。

而最后一个 `/registry/pods/default/www` 则存储了新创建的 www Pod 的所有信息，包括：最新应用的配置、与之关联的 token、Pod 的状态等等。

```bash
kubectl exec etcd-kube-master -n kube-system -- sh -c \
"ETCDCTL_API=3 etcdctl \
--endpoints $ADVERTISE_URL \
--cacert /etc/kubernetes/pki/etcd/ca.crt \
--key /etc/kubernetes/pki/etcd/server.key \
--cert /etc/kubernetes/pki/etcd/server.crt \
get \"/registry/pods/default/www\" --prefix=true "
```

结果如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568718073398/wm)

通过上面的操作我们进一步了解了在 kubernetes 集群中 etcd 数据库中的数据存储流程。

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Etcd 工作原理：Raft 协议
- Etcd v2 和 v3 的区别
- Etcd 安装与简单使用
- Etcd 在 kubernetes 中的应用

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。