---
show: step
version: 1.0
---

# YAML 简介

## 1.实验介绍

####  实验内容

本次实验将会带领大家学习 YAML 语法，主要涉及的方面包括：YAML 的基本语法规则、YAML 的数据结构、常用特殊符号。

####  实验知识点

- YAML 的基本语法规则
- YAML 的数据结构
- 常用特殊符号

####  推荐阅读

- [YAML 官方网站](https://yaml.org/)
- [YAML v1.2](https://yaml.org/spec/1.2/spec.html)

## 2.YAML 简介

YAML 并不是标记语言，它是适用于所有程序语言的人类友好的基于 Unicode 数据序列化标准格式。它被广泛的应用于那些需要通过网络传送配置文件以便于数据校验的程序应用之中。

YAML 的数据组织主要依靠空白、缩进、分行等结构。

YAML 语言比 JSON 更加具有可读性和简洁性，使用 YAML 语言写成的配置文件，以 `.yml` 或是 `.yaml` 结尾。

可以这么认为，YAML 语言已经成为事实标准上的云配置语言，例如：Docker、Kubernetes、Openstack 等的配置文件都采用的是 YAML 格式，使用 YAML 来进行配置有许多优点，比如：

- 方便：不需要将所有参数都添加到命令行中
- 可维护：可以将 YAML 文件添加到代码版本控制仓库，跟踪文件的修改
- 灵活性：可以比使用命令行创建更加复杂的结构

所以在我们真正开始学习 Kubernetes 之前，先来学习一下 YAML 语言的使用语法吧。

###  YAML 的基本语法规则

- 大小写敏感
- 使用缩进表示层级(属性)关系
- 使用空格表示缩进，不允许使用 TAB
- 缩进对空格数目不敏感，相同层级需要对齐(一般 2 个或是 4 个空格)
- 用 `#` 表示行注释

###  YAML 的数据结构

YAML 的数据结构比较简单，只有 3 种：

- `对象`：用 `key: value` 键值对表示(注意：冒号后面有一个空格)

比如：

```yaml
name: zhangsan

# 也可以使用缩进表示层级关系
key:
    child-key1: value1
    child-key2: value2
```

- `数组`：一组用连词线 `-` 构成的数据结构(注意：连词线后面有一个空格)

比如：

```yaml
- A
- B
- C
```

- `常量`(scalars)：元数据，不可再分，大多情况下指基本数据类型，包括：字符串、布尔值、整数、浮点数、null、时间、日期等

比如：

```yaml
# 数值可以直接表示
number: 2.3

# 布尔值用 true 或是 false 表示
isOnline: true

# null 用波浪线表示
isNull: ~

# 时间采用 ISO 8601 格式表示（时间和日期之间使用 T 连接，最后使用 + 代表时区）
time: 2019-08-01T19:02:31+08:00

# 日期用复合 ISO 8601 格式表示
data: 2019-08-01

# 字符串比较复杂
# 默认不用引号
str: shiyanlou
# 如果字符串中间有空格或是特殊字符时，字符串需要放在引号内（单双都可以）
str: 'this is a string'
# 如果字符串中间有单引号，需要用两个单引号进行转义处理
str: 'he''s name is liming'
```

下面的例子展示了对于上面提到的 3 种数据结构的综合使用：

```yaml
# 表示 url 属性的值
url: http://www.shiyanlou.com
# 表示 serverA.host 属性的值
serverA:
    host: http://www.shiyanlou.com
# 数组，表示 serverB 为 [10.192.0.2,10.192.0.3,10.192.0.4]
serverB:
    - 10.192.0.2
    - 10.192.0.3
    - 10.192.0.4
# 常量
pi: 3.14
hasChild: false
name: shiyanlou
```

###  常用特殊符号

#### .1 `---`

`---` 表示一个文档的开始，可以将多个文档写到同一个文件中，比如：

```yaml
---
kube-master:
    profile: master
    server:
        address: 10.192.0.2
---
kube-node-1:
    profile: node
    server:
        address: 10.192.0.3
```

#### .2 `...` 和 `---` 配合使用

`...` 和 `---` 配合使用，在一个配置文件中表示一个文件的结束，等同于在一个 YAML 文件中连续写了两个 YAML 配置项，比如：

```yaml
---
user: shiyanlou1
action: login
...
---
user: shiyanlou2
action: logout
...
```

#### .3 `!!`

`!!` 可以做类型的强行转换，比如：

```yaml
# 表示把数字和布尔类型都强行转换为字符串
string:
  - !!str 123456
  - !!str false
```

#### .4 `*` 和 `&`

在 YAML 中重复的内容可以使用 `&` 来完成锚点定义，使用 `*` 来完成锚点引用，比如：

```yaml
# 这里使用 &name 为 shixiaomei 设置了一个锚点（引用）
hr:
  - shixiaolou
  - &name shixiaomei
# 这里使用 *name 引用锚点，指代 shixiaomei
cto:
  - *name
  - shiyanlou
```

#### .5 `>` 和 `|`

`>` 表示折叠换行，`|` 表示保留换行符，这两个符合在字符串中经常使用到，比如：

```yaml
# 字符串可以写成多行，从第二行开始，必须有一个单空格缩进，换行符会被转换为空格，结果是
# str=这是一段
#      多行
#      字符串
str: 这是一段
 多行
 字符串

# `|` 表示保留换行符，结果是
# this=Foo
#  Bar
this: |
 Foo
 Bar

# `>` 表示折叠换行(即将换行符转化为了空格)，结果是
# that=Foo Bar
that: >
 Foo
 Bar
```

## 3.实验总结

本次实验我们向大家介绍了如下知识点：

- YAML 的基本语法规则
- YAML 的数据结构
- 常用特殊符号

YAML 格式在我们后面编写 YAML 文件中会经常使用到，大家需要清楚其中具体的语法。

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。