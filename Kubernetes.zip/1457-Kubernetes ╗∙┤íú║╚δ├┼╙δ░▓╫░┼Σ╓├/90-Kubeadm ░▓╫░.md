---
show: step
version: 1.0
---

# Kubeadm 安装

## 1.实验介绍

####  实验内容

本次实验我们将会带领大家使用 kubeadm 在阿里云 ECS 服务器上部署 Kubernetes 集群。

注意：本次实验不在实验环境中进行，大家可以在[阿里云](https://cn.aliyun.com/)上注册一个账号，自行创建 ECS 服务器完成本次的实验。

####  实验知识点

- 创建一台 ECS 服务器
- 安装 ALL-In-One 的 Kubernetes 集群
- 部署 Nginx 验证集群
- 部署 Dashboard

####  推荐阅读

- [云服务器 ECS](https://help.aliyun.com/product/25365.html)

## 2.使用 Kubeadm 安装单节点 Kubernetes 集群

使用 kubeadm 工具在阿里云 ECS 服务器上安装一个 `ALL-In-One` 类型的 Kubernetes 集群环境，也就是指这个环境中主要是安装了 Master，但是也可以作为一个 Node 节点使用。

###  创建一台 ECS 服务器

访问[阿里云官网](https://cn.aliyun.com/)，如果没有账号的话可以先注册一个账号，有账号的话可以直接登录，然后点击页面右上方的 `控制台` 进入管理页面，在控制台页面选择 `云服务器 ECS`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567177112279/wm)

在 `基础配置` ，按照如下截图的方式配置，截图中少截取了最后一部分镜像配置，选择 公共镜像 ubuntu 16.04 即可：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567177222079/wm)

`网络和安全`使用默认的配置就可以了，`系统配置` 按照如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567177558749/wm)

`分组设置`使用默认的配置就可以了，`确认订单`注意勾选左边最下方的同意《云服务器 ECS 条款》，最后点击 `创建实例` 就成功创建了一台 ubuntu 16.04 的 ECS 服务器。

跳转到 `云服务器 ECS` 页面，在实例列表中可以看到刚刚创建的实例信息，这里列出了这台服务器的公有 IP 和私有 IP。

在自己的终端使用命令 `ssh root@<公网IP地址>` 然后输入自定义的密码就可以连接远程的服务器了。

###  安装 ALL-In-One 的 Kubernetes 集群

本次的环境统一使用的是：ubuntu16.04，2v、4GB 的配置，全程都是在 root 用户下执行安装。

1. 安装 Docker，在终端执行如下命令：

```bash
apt-get update
apt-get install -y apt-transport-https ca-certificates curl gnupg-agent software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io

# 测试 docker 是否可以使用，版本：19.03.1
docker version
```

2. 配置内核模块（kube-proxy ipvs 模式需要使用）和内核参数，并关闭 swapoff：

```bash
cat >> /etc/modules <<EOF
ip_vs_rr
ip_vs_wrr
ip_vs_sh
nf_conntrack_ipv4
br_netfilter
EOF

cat > /etc/sysctl.d/k8s.conf <<EOF
net.ipv4.ip_forward = 1
vm.swappiness = 0
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

swapoff -a
sed -i 's/.*swap.*/#&/' /etc/fstab
```

3. 安装 kubeadm、kubelet、kubectl、ipvsadm 和 ipset

当 kube-proxy 允许在 ipvs 模式下运行时，可以通过 ipvsadm 工具查看各种规则。

```bash
curl -s https://mirrors.aliyun.com/kubernetes/apt/doc/apt-key.gpg | apt-key add -

cat > /etc/apt/sources.list.d/aliyun-k8s.list <<EOF
deb https://mirrors.aliyun.com/kubernetes/apt/ kubernetes-xenial main
EOF

apt update
apt install -y kubeadm kubelet kubectl ipvsadm ipset
```

4. 配置 Docker

注意配置中比较重要的几点，对于 Docker registry mirrors 的配置，以及关闭 docker 对 iptables 的配置。

```bash
cat > /etc/docker/daemon.json <<EOF
{
    "registry-mirrors": ["https://n6syp70m.mirror.aliyuncs.com"],
    "iptables": false,
    "ip-masq": false,
    "storage-driver": "overlay2",
    "exec-opts": ["native.cgrounpdriver=systemd"],
    "log-driver": "json-file",
    "log-opts": { "max-size": "20m" }
}
EOF

# 重启
reboot
```

5. 使用 kubeadm 初始化集群，同时指定 pod 网段为 flannel 网络插件的默认网段

如果有更多的节点要加入到 Kubernetes 集群，那么需要在每个节点上依次执行上面的 1-4 个步骤。

```bash
$ kubeadm init --image-repository registry.aliyuncs.com/google_containers --pod-network-cidr=10.244.0.0/16

...
...
Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
  https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 172.16.128.59:6443 --token 02ct9e.19dxnkc43n6bzvu2 \
    --discovery-token-ca-cert-hash sha256:d1a7ec1dc24f0a3ba86e5b9f373df19df0ab742f9b59846c91013c715d935fa5
```

当集群初始化成功后，可以看到 kubeadm 已经提供如何在其中工作节点通过 `kubeadm join` 命令加入集群（可以记录下面以备后面的使用）。

6. 复制 kubectl 相关配置文件

```bash
mkdir -p $HOME/.kube
cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
chown $(id -u):$(id -g) $HOME/.kube/config
```

7. 验证集群启动成功

```bash
$ kubectl get nodes
NAME                      STATUS   ROLES    AGE     VERSION
izbp13yx4795aofieb7vatz   NotReady    master   3m46s   v1.15.3

$ kubectl get pod -n kube-system
NAME                                              READY   STATUS    RESTARTS   AGE
coredns-bccdc95cf-6cxqt                           0/1     Pending   0          7m21s
coredns-bccdc95cf-jmsvj                           0/1     Pending   0          7m21s
etcd-izbp13yx4795aofieb7vatz                      1/1     Running   0          6m27s
kube-apiserver-izbp13yx4795aofieb7vatz            1/1     Running   0          6m21s
kube-controller-manager-izbp13yx4795aofieb7vatz   1/1     Running   0          6m37s
kube-proxy-r75xw                                  1/1     Running   0          7m21s
kube-scheduler-izbp13yx4795aofieb7vatz            1/1     Running   0          6m42s
```

可以发现 coredns pod 还处于 Pending 状态，这是由于网络插件还未安装。

8. 安装网络插件 flannel

由于 flannel 使用的镜像默认托管在 quay.io 上，但国内访问速度会特别慢，所以可以先通过其他渠道将镜像拉取到本地，避免后续部署失败。在从 mirror 拉取镜像时，需要先看下 flannel.yaml 文件中指定的镜像版本是什么，比如本实验编写时使用的是 `quay.io/coreos/flannel:v0.11.0-amd64`，所以可以先通过以下命令拉取镜像：

```bash
docker pull quay-mirror.qiniu.com/coreos/flannel:v0.11.0-amd64
docker tag quay-mirror.qiniu.com/coreos/flannel:v0.11.0-amd64 quay.io/coreos/flannel:v0.11.0-amd64
```

部署 flannel：

```bash
kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
```

此时可以再次执行 `kubectl get pod -n kube-system` 验证网络插件是否部署成功，可以看到 coredns pod 已经变为 running 状态。

9. 移除 master 节点的 taint

kubeadm 在 Master 上也安装了 kubelet，在默认情况下不参与工作负载，这里我们是安装一个单机 ALL-In-One 的 Kubernetes 环境，可以执行下面的命令让 Master 成为一个 Node。

```bash
kubectl get nodes #获取到 Master 节点的名称，这里为 izbp13yx4795aofieb7vatz

# 大家用自己环境中的 Master 节点名称替换下面命令的 izbp13yx4795aofieb7vatz
kubectl taint nodes izbp13yx4795aofieb7vatz node-role.kubernetes.io/master-
```

截止这里我们的 ALL-In-One Kubernetes 集群环境就已经搭建完成，下面进行测试验证集群。

###  部署 Nginx 验证集群

通过部署 Nginx 验证集群

```bash
kubectl create deployment nginx --image=nginx
kubectl expose deploy nginx --type=NodePort --port=8080 --target-port=80 --name=nginx-svc
```

通过下面的命令查看创建的 pod、deployment 以及 service：

```bash
$ kubectl get pods
NAME                     READY   STATUS    RESTARTS   AGE
nginx-554b9c67f9-qszt2   1/1     Running   0          2m1s

$ kubectl get deploy
NAME    READY   UP-TO-DATE   AVAILABLE   AGE
nginx   1/1     1            1           2m10s

$ kubectl get svc
NAME         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
kubernetes   ClusterIP   10.96.0.1        <none>        443/TCP          20m
nginx-svc    NodePort    10.104.212.181   <none>        8080:30722/TCP   44s
```

可以发现 nginx 服务暴露在集群 IP 10.104.212.181 的 8080 端口上，下面在节点上使用 curl 可以访问到 nginx：

```bash
$ curl 10.104.212.181:8080
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
....
```

###  部署 Dashboard

Kubernetes Dashboard 是 Kubernetes 集群的 Web 管理界面。类似于 flannel 在部署前需要提前从阿里云镜像仓库中拉取镜像，还有一种方法是直接修改 kubernetes-dashboard.yaml 文件中指定的镜像，这里我们通过提前拉取镜像的方式：

```bash
docker pull registry.aliyuncs.com/google_containers/kubernetes-dashboard-amd64:v1.10.1

docker tag registry.aliyuncs.com/google_containers/kubernetes-dashboard-amd64:v1.10.1 k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1

kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v1.10.1/src/deploy/recommended/kubernetes-dashboard.yaml
```

可以通过 `kubectl get pods -n kube-system` 或者 `kubectl get svc -n kube-system` 来验证 dashboard 是否部署成功。

dashboard 成功部署以后，通过下面的命令将 dashboard 暴露出来：

```bash
$ kubectl proxy --address='0.0.0.0' --port=8080 --disable-filter=true
W0831 08:57:25.193563   25132 proxy.go:142] Request filter disabled, your proxy is vulnerable to XSRF attacks, please be cautious
Starting to serve on [::]:8080
```

在阿里云上开放该实例对应的端口：

在云服务器 ECS 实例列表中，找到创建的实例，单击实例名称，进入该实例的详细配置页面。点击左侧边栏的 `本实例安全组`，选择右边的 `安全组列表 -> 配置规则`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567182736513/wm)

点击 `添加安全组规则`，在弹出的表单中按照下面的方式填写并保存即可：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567182878085/wm)

然后从浏览器上访问节点的公网地址，如下所示就可以看到 Dashboard 界面：

```text
# 其中的 47.98.216.207 要换成你们自己服务器的公网 IP 地址
http://47.98.216.207:8080/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/
```

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567213543869/wm)

我们只需要输入 Kubernetes 集群中的 ServiceAccount 的 Token 就可以访问集群，这里手动创建一个具有集群管理权限的 ServiceAccount，通过下面的命令创建：

```bash
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kube-system
EOF
```

创建完成后通过如下命令获取到 admin-user 账户的 Token：

```bash
kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep admin-user | awk '{print $1}')
```

这下面的结果是我自己新建账户的 Token 值，每个人自己环境中的值都是不一样的：

```text
eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLWhtczV4Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJmMzM3ODg1OS1jY2QzLTQ5NjMtYWQyNi0xZDk2NWY3MWJiZGEiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZS1zeXN0ZW06YWRtaW4tdXNlciJ9.gEzIPCr3QvS4-67hhaI7gB3nQcLgUPzklMig3hF_G63f3gaRgxbqVZLSrvAF2XFzNBhhH12jbXQZGdB_Rt3aDSvR6KrjM0cgWB3tyd-2LrFmHwo1u8cAPp3XWo73cFAnwTH6pzVoSjyblA16IuaI060LD91KWVvSoHxVIA1UR2ADnYKsXUykaY9AMnPJC4CH6j2hfQAvnQYPfz46X77mUHeGUljIyp-Y85P4kQ360EWT0dbbvT3L8PC3KF8yshIYSBtBmE4ybA4oVBSsVeVVPVOIxwI4Z1HjrTtgFSJbtrcHgqKNw150O8cOfdk7EyHmonccFTk0zJW9FdXmua87Cw
```

复制上面命令输出结果的 Token，在 Kubernetes 仪表盘中选择令牌，然后把 Token 粘贴进去就可以完成登录。

需要注意的是通过 `kubectl proxy` 的方式访问 Dashboard 可能遇到登录按钮无响应的情况。此时可以通过将 Dashboard 服务以 NodePort 的方式进行暴露访问：

```bash
kubectl -n kube-system expose service kubernetes-dashboard --type=NodePort --port=443 --target-port=8443 --name=kubernetes-dashboard-nodeport
```

上面的命令通过 NodePort 的方式在 kubernetes-dashboard 服务的基础上创建了一个新的服务 kubernetes-dashboard-nodeport，执行如下命令查看创建的服务：

```bash
$ kubectl -n kube-system get svc kubernetes-dashboard-nodeport
NAME                            TYPE       CLUSTER-IP      EXTERNAL-IP   PORT(S)         AGE
kubernetes-dashboard-nodeport   NodePort   10.97.162.129   <none>        443:30433/TCP   109s
```

可以看到目前服务暴露到了节点的 30433 端口上，登录阿里云修改这台服务器对外开放的端口，我这里将前面定义的 8080/8080 端口修改为 30433/30433（大家按照自己的实际情况进行修改），修改后通过如下地址访问：

```text
# https://<公网IP>:30433
https://47.98.216.207:30433/
```

在 Kubernetes 仪表盘中选择令牌，然后把 Token 粘贴进去就可以完成登录。登录后的页面如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190831-1567214679626/wm)

## 3.实验总结

本次实验我们向大家介绍了如下知识点：

- 创建一台 ECS 服务器
- 安装 ALL-In-One 的 Kubernetes 集群
- 部署 Nginx 验证集群
- 部署 Dashboard

本次实验使用 kubeadm 在阿里云 ECS 服务器上部署了 ALL-In-One 类型的 Kubernetes 集群，这台服务器既是 Master 节点，也充当了 Node 节点，同时也部署了 Dashboard 可以直接通过 Web 界面查看 Kubernetes 集群的状态。

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
