---
show: step
version: 1.0
---

# kube-proxy 组件

## 1.实验介绍

####  实验内容

本节实验内容我们将会向大家介绍 kube-proxy 组件，主要分为两大部分：一部分是介绍 kube-proxy 组件的三种不同的代理模式，分别为：userspace 模式、iptables 模式 以及 ipvs 模式，另一部分就是 kube-proxy 常用的启动参数。

####  实验知识点

- userspace 模式
- iptables 模式
- ipvs 模式
- kube-proxy 启动参数

####  推荐阅读

- [kube-proxy](https://kubernetes.io/zh/docs/reference/command-line-tools-reference/kube-proxy/)
- [Virtual IPs and service proxies](https://kubernetes.io/docs/concepts/services-networking/service/#virtual-ips-and-service-proxies)
- [kube-proxy 工作模式分析](http://kidlj.com/blog/2018-11-28-kube-proxy.html)
- [浅析 kube-proxy 中的 IPVS 模式](https://mp.weixin.qq.com/s/Hb1WAh15-NhvDHmzu-6v4Q)
- [Understanding Kubernetes Kube-Proxy](https://supergiant.io/blog/understanding-kubernetes-kube-proxy/)

## 2.kube-proxy 组件详解

在前面我们讲解过提供相同服务的一组 Pod 可以抽象成为一个 Service，通过 Service 提供的统一入口（一个虚拟的 Cluster IP 地址）来提供服务，Service 在这里起到了负载均衡器的作用，它会将接收到的请求转发给后端的 Pod。在大部分情况下，Service 只是一个概念，而真正起作用的是在各个 Node 节点上运行的 kube-proxy 服务进程。本实验将会介绍 kube-proxy 的原理和机制，方便大家能够更加深入的理解 Service 背后的实现逻辑。

在 Kubernetes 集群中的每个 Node 节点上都会运行一个 kube-proxy 服务进程，可以把这个进程看作是 Service 的透明代理兼负载均衡器，它的核心功能是将到某个 Service 的访问请求转发到后端的多个 Pod 实例上。

kube-proxy 提供了三种服务负载模式：

- 基于用户态的 userspace 模式：早期的代理模式
- iptables 模式：默认内核级代理模式
- ipvs 模式：处于实验性阶段的代理模式

###  userspace 模式

userspace 模式是 kube-proxy 使用的第一代模式，该模式在 kubernetes v1.0 版本开始支持使用。

userspace 模式的实现原理图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190912-1568251992379/wm)

kube-proxy 会为每个 Service 随机监听一个端口(proxy port)，并增加一条 iptables 规则。所以通过 ClusterIP:Port 访问 Service 的报文都 redirect 到 proxy port，kube-proxy 从它监听的 proxy port 收到报文以后，走 round robin(默认) 或是 session affinity(会话亲和力，即同一 client IP 都走同一链路给同一 pod 服务)，分发给对应的 pod。

由于 userspace 模式会造成所有报文都走一遍用户态（也就是 Service 请求会先从用户空间进入内核 iptables，然后再回到用户空间，由 kube-proxy 完成后端 Endpoints 的选择和代理工作），需要在内核空间和用户空间转换，流量从用户空间进出内核会带来性能损耗，所以这种模式效率低、性能不高，不推荐使用。

###  iptables 模式

iptables 模式是 kube-proxy 使用的第二代模式，该模式在 kubernetes v1.1 版本开始支持，从 v1.2 版本开始成为 kube-proxy 的默认模式。

iptables 模式的负载均衡模式是通过底层 netfilter/iptables 规则来实现的，通过 Informer 机制 Watch 接口实时跟踪 Service 和 Endpoint 的变更事件，并触发对 iptables 规则的同步更新。

iptables 模式的实现原理图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190912-1568251051797/wm)

通过图示我们可以发现在 iptables 模式下，kube-proxy 只是作为 controller，而不是 server，真正服务的是内核的 netfilter，体现用户态的是 iptables。所以整体的效率会比 userspace 模式高。

下面我们使用一个例子来查看 iptables 模式下的转发规则。

在 `/home/shiyanlou` 目录下新建 `nginx.yaml` 文件，并向文件中写入如下内容：

```yaml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: my-nginx
spec:
  replicas: 2
  template:
    metadata:
      labels:
        run: my-nginx
    spec:
      containers:
      - name: my-nginx
        image: nginx
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: my-nginx
  labels:
    run: my-nginx
spec:
  ports:
  - port: 80
    protocol: TCP
  selector:
    run: my-nginx
```

在这个 YAML 文件中我们使用 Deployment 创建了两个 nginx pod 副本，并定义了名为 my-nginx 的服务，选择所有标签为 run: my-nginx 的 pod，指定端口为 80。

然后执行资源创建：

```bash
$ kubectl create -f nginx.yaml
deployment.extensions/my-nginx created
service/my-nginx created
```

创建成功以后查看新建的 Pod 和 Service 的 IP 地址：

```bash
$ kubectl get pods -o wide
NAME                        READY   STATUS    RESTARTS   AGE   IP           NODE          NOMINATED NODE   READINESS GATES
my-nginx-756fb87568-5zs9w   1/1     Running   0          45s   10.244.2.4   kube-node-1   <none>           <none>
my-nginx-756fb87568-wkzjg   1/1     Running   0          45s   10.244.3.3   kube-node-2   <none>           <none>
$ kubectl get svc
NAME         TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)   AGE
kubernetes   ClusterIP   10.96.0.1       <none>        443/TCP   25d
my-nginx     ClusterIP   10.111.212.58   <none>        80/TCP    105s
$ kubectl describe svc my-nginx
Name:              my-nginx
Namespace:         default
Labels:            run=my-nginx
Annotations:       <none>
Selector:          run=my-nginx
Type:              ClusterIP
IP:                10.111.212.58
Port:              <unset>  80/TCP
TargetPort:        80/TCP
Endpoints:         10.244.2.4:80,10.244.3.3:80
Session Affinity:  None
Events:            <none>
```

可以看到两个 Pod 分别运行在两个 Node 节点上，其中运行在 kube-node-1 节点上的 Pod 的 IP 地址为：10.244.2.4，运行在 kube-node-2 节点上的 Pod 的 IP 地址为：10.244.3.3，my-nginx Service 的 ClusterIP 地址为 10.111.212.58，其对应的 Endpoints 地址为 10.244.2.4:80、10.244.3.3:80，也就是两个 Pod 的服务地址。

我们可以任意进入一个节点，访问 my-nginx Service 的 ClusterIP 地址：

```bash
$ docker exec -it kube-node-1 /bin/bash
root@kube-node-1:/# curl 10.111.212.58:80
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>
```

可以看到能够通过 Service 的 ClusterIP 地址实现成功的访问服务背后对应的 Pod。同样的，使用 curl 访问 Endpoints 对应的地址也可以访问 nginx 服务。

现在我们分别在 kube-node-1 节点和 kube-node-2 节点执行 `iptables-save` 命令查看这两个节点的 iptables，下面选取了与 my-nginx Service 相关的链路给大家展示并作说明：

```text
# kube-node-1，对应的 Pod Endpoints 为 10.244.2.4:80

1. -A KUBE-SERVICES -d 10.111.212.58/32 -p tcp -m comment --comment "default/my-nginx: cluster IP" -m tcp --dport 80 -j KUBE-SVC-BEPXDJBUHFCSYIC3

2. -A KUBE-SVC-BEPXDJBUHFCSYIC3 -m statistic --mode random --probability 0.50000000000 -j KUBE-SEP-NUDSVAACGYR7V2T7
3. -A KUBE-SVC-BEPXDJBUHFCSYIC3 -j KUBE-SEP-XGCTD4B5NHFEPCP2

4. -A KUBE-SEP-NUDSVAACGYR7V2T7 -s 10.244.2.4/32 -j KUBE-MARK-MASQ
5. -A KUBE-SEP-NUDSVAACGYR7V2T7 -p tcp -m tcp -j DNAT --to-destination 10.244.2.4:80

# kube-node-2，对应的 Pod Endpoints 为 10.244.3.3:80

1. -A KUBE-SERVICES -d 10.111.212.58/32 -p tcp -m comment --comment "default/my-nginx: cluster IP" -m tcp --dport 80 -j KUBE-SVC-BEPXDJBUHFCSYIC3

2. -A KUBE-SVC-BEPXDJBUHFCSYIC3 -m statistic --mode random --probability 0.50000000000 -j KUBE-SEP-NUDSVAACGYR7V2T7
3. -A KUBE-SVC-BEPXDJBUHFCSYIC3 -j KUBE-SEP-XGCTD4B5NHFEPCP2

4. -A KUBE-SEP-XGCTD4B5NHFEPCP2 -s 10.244.3.3/32 -j KUBE-MARK-MASQ
5. -A KUBE-SEP-XGCTD4B5NHFEPCP2 -p tcp -m tcp -j DNAT --to-destination 10.244.3.3:80
```

从第 1 条规则中可以看到 my-nginx clusterIP，Node 节点上不需要有这个 ip 地址，iptables 在看到目的地址为 clusterIP 的符合规则的 tcp 报文会走 KUBE-SVC-BEPXDJBUHFCSYIC3 规则。

第 2、3 条规则，KUBE-SVC-BEPXDJBUHFCSYIC3 链实现了按 50% 的统计概率随机匹配到两条规则。

第 4、5 条规则是成对的两组规则，将报文转给了真正服务的 Pod。

上面的整个过程，从物理 Node 收到目的地址为 10.111.212.58，端口号为 80 的报文开始，到 my-nignx Pod 收到报文并响应，形成了一个完整的链路。可以发现整个报文链路上没有经过任何用户态进程，因此效率和稳定性都比较高。

iptables 模式实现起来比较简单，但存在无法避免的缺陷：当集群中的 Service 和 Pod 大量增加以后，iptables 中的规则会急剧增加，导致性能显著下降，在某些极端情况下甚至会出现规则丢失的情况，并且这种故障难以重现和排查。

iptables 模式相关的常用参数有：

- `--iptables-masquerade-bit`：标记数据包将进行 SNAT 的 fwmark 位设置，有效范围为 [0,31]，默认值为 14
- `--iptables-min-sync-period`：刷新 iptables 规则的最小时间间隔
- `--iptables-sync-period`：刷新 iptables 规则的最大时间间隔，必须大于 0，默认值为 30s

###  ipvs 模式

ipvs 模式被 kube-proxy 采纳为第三代模式，模式在 kubernetes v1.8 版本开始引入，在 v1.9 版本中处于 beta 阶段，在 v1.11 版本中正式开始使用。

ipvs(IP Virtual Server) 实现了传输层负载均衡，也就是 4 层 `LAN` 交换，作为 Linux 内核的一部分。`ipvs` 运行在主机上，在真实服务器前充当负载均衡器。ipvs 可以将基于 TCP 和 UDP 的服务请求转发到真实服务器上，并使真实服务器上的服务在单个 IP 地址上显示为虚拟服务。

ipvs 模式的实现原理图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190912-1568251317418/wm)

ipvs 和 iptables 都是基于 netfilter 的，那么 ipvs 模式有哪些更好的性能呢？

- ipvs 为大型集群提供了更好的可拓展性和性能
- ipvs 支持比 iptables 更复杂的负载均衡算法（包括：最小负载、最少连接、加权等）
- ipvs 支持服务器健康检查和连接重试等功能
- 可以动态修改 ipset 的集合，即使 iptables 的规则正在使用这个集合

ipvs 依赖于 iptables。ipvs 会使用 iptables 进行包过滤、airpin-masquerade tricks(地址伪装)、SNAT 等功能，但是使用的是 iptables 的扩展 ipset，并不是直接调用 iptables 来生成规则链。通过 ipset 来存储需要 DROP 或 masquerade 的流量的源或目标地址，用于确保 iptables 规则的数量是恒定的，这样我们就不需要关心有多少 Service 或是 Pod 了。

使用 ipset 相较于 iptables 有什么优点呢？iptables 是线性的数据结构，而 ipset 引入了带索引的数据结构，当规则很多的时候，ipset 依然可以很高效的查找和匹配。我们可以将 ipset 简单理解为一个 IP(段) 的集合，这个集合的内容可以是 IP 地址、IP 网段、端口等，iptables 可以直接添加规则对这个“可变的集合进行操作”，这样就可以大大减少 iptables 规则的数量，从而减少性能损耗。

举一个例子，如果我们要禁止成千上万个 IP 访问我们的服务器，如果使用 iptables 就需要一条一条的添加规则，这样会在 iptables 中生成大量的规则；如果用 ipset 就只需要将相关的 IP 地址(网段)加入到 ipset 集合中，然后只需要设置少量的 iptables 规则就可以实现这个目标。

下面的表格是 ipvs 模式下维护的 ipset 表集合：

| 设置名称 | 成员 | 用法 |
| ------- | --- | ---- |
| KUBE-CLUSTER-IP | 所有服务 IP + 端口 | 在 masquerade-all=true 或 clusterCIDR 指定的情况下对 Service Cluster IP 地址进行伪装，解决数据包欺骗问题 |
| KUBE-LOOP-BACK | 所有服务 IP + 端口 + IP | 解决数据包欺骗问题 |
| KUBE-EXTERNAL-IP | 服务外部 IP + 端口 | 将数据包伪装成 Service 的外部 IP 地址 |
| KUBE-LOAD-BALANCER | 负载均衡器入口 IP + 端口 | 将数据包伪装成 Load Balancer 类型的 Service |
| KUBE-LOAD-BALANCER-LOCAL | 负载均衡器入口 IP + 端口 以及 `externalTrafficPolicy=local` | 接受数据包到 Load Balancer externalTrafficPolicy=local |
| KUBE-LOAD-BALANCER-FW | 负载均衡器入口 IP + 端口 以及 `loadBalancerSourceRanges` | 使用指定的 loadBalancerSourceRanges 丢弃 Load Balancer 类型 Service 的数据包 |
| KUBE-LOAD-BALANCER-SOURCE-CIDR | 负载均衡器入口 IP + 端口 + 源 CIDR | 接受 Load Balancer 类型 Service 的数据包，并指定 loadBalancerSourceRanges |
| KUBE-NODE-PORT-TCP | NodePort 类型服务 TCP 端口 | 将数据包伪装成 NodePort（TCP）|
| KUBE-NODE-PORT-LOCAL-TCP | NodePort 类型服务 TCP 端口，带有 `externalTrafficPolicy=local` | 接受数据包到 NodePort 服务，使用 externalTrafficPolicy=local |
| KUBE-NODE-PORT-UDP | NodePort 类型服务 UDP 端口 | 将数据包伪装成 NodePort(UDP) |
| KUBE-NODE-PORT-LOCAL-UDP | NodePort 类型服务 UDP 端口，使用 `externalTrafficPolicy=local` | 接受数据包到 NodePort 服务，使用 externalTrafficPolicy=local |

ipvs 模式相关的常用参数有：

- `--cleanup-ipvs`：值为 true 时清除在 ipvs 模式下创建的 ipvs 配置和 iptables 规则
- `--proxy-mode`：通过 --proxy-mode = ipvs 进行设置，隐式使用 ipvs NAT 模式进行服务端口映射
- `--ipvs-scheduler`：指定 ipvs 负载均衡算法，如果未配置，则默认为 round-robin(rr) 算法

- `--ipvs-sync-period`：刷新 ipvs 规则的最大间隔时间（比如 5s、1m），必须大于 0
- `--ipvs-min-sync-period`：刷新 ipvs 规则的最小间隔时间间隔（比如 5s、1m），必须大于 0
- `--ipvs-sync-period`：刷新 ipvs 规则的最大时间间隔，必须大于 0，默认值为 30s
- `--ipvs-exclude-cidrs`：清除 ipvs 规则时 ipvs 代理不应触及的 CIDR 的逗号分隔列表，因为 ipvs 代理无法区分 kube-proxy 创建的 ipvs 规则和用户原始 ipvs 规则，如果在环境中使用 ipvs 代理模式和自己的 ipvs 规则，则应指定此参数，否则将清除原始规则

###  kube-proxy 启动参数

kube-proxy 其它启动参数有：

- `--bind-address`：kube-proxy 绑定主机的 IP 地址，默认值为 0.0.0.0，表示绑定所有 IP 地址
- `--cleanup`：设置为 true 表示在清除 iptables 规则和 ipvs 规则后退出
- `--cluster-cidr`：集群中 Pod 的 CIDR 地址范围，用于桥接集群外部流量到内部
- `--config`：kube-proxy 的主配置文件
- `--config-sync-period`：从 API Server 更新配置的时间间隔，必须大于 0，默认值为 15m0s
- `--conntrack-max-per-core`：跟踪每个 CPU core 的 NAT 连接的最大数量（设置为 0 表示无限制，并忽略 conntrack-min 的值），默认值为 32768
- `--conntrack-min`：最小 conntrack 条目的分配数量，默认值为 131072
- `--conntrack-tcp-timeout-close-wait`：当 TCP 连接处于 CLOSE_WAIT 状态时的 NAT 超时时间，默认值为 1h0m0s
- `--conntrack-tcp-timeout-established`：建立 TCP 连接的超时时间，设置为 0 表示无限制，默认值为 24h0m0s
- `--healthz-bind-address`：healthz 服务绑定主机 IP 地址，设置为 0.0.0.0 表示使用所有 IP 地址，默认值为 0.0.0.0:10256
- `--healthz-port`：healthz 服务监听的主机端口号，设置为 0 表示不启用，默认值为 10256
- `--hostname-override`：设置本 Node 在集群中的主机名，不设置时将使用本机 hostname
- `--kube-api-burst`：每秒发送到 API Server 的请求的数量，默认值为 10
- `--kubeconfig`：kubeconfig 配置文件路径，在配置文件中包括 Master 地址信息及必要的认证信息
- `--masquerade-all`：设置为 true 表示使用纯 iptables 代理，所有网络包都将进行 SNAT 转换
- `--master`：API Server 的地址
- `--metrics-bind-address`：Metrics Server 的监听地址，设置为 0.0.0.0 表示使用所有 IP 地址，默认值为 127.0.0.1:10249
- `--proxy-mode`：代理模式，可选项为 userspace、iptables、ipvs，默认值为 iptables，当操作系统内核版本或 iptables 版本不够新时，将自动降级为 userspace 模式

## 3.实验总结

本次实验我们向大家介绍了如下知识点：

- userspace 模式
- iptables 模式
- ipvs 模式
- kube-proxy 启动参数

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
