---
show: step
version: 1.0
---

# 使用 WebUI

## 1.实验介绍

####  实验内容

本次实验我们将会带领大家学习使用 kubernetes dashboard，它是一个 Web UI 网页管理工具，可以提供部署应用、资源对象管理、容器日志查询、系统监控等常用的集群管理功能。

我们的实验环境中已经部署了 dashboard 组件，可以直接访问使用。

####  实验知识点

- 创建 admin 用户
- 访问 Dashboard Service 的 4 种方式
- WebUI 界面简介

####  推荐阅读

- [dashboard GitHub](https://github.com/kubernetes/dashboard)
- [dashboard 参数](https://github.com/kubernetes/dashboard/blob/master/docs/common/dashboard-arguments.md)

## 2. Dashboard 配置及访问

当我们启动集群之后可以看到访问 dashboard 的 URL 地址：(注意：这里的端口可能发生变化，以启动集群时最后提示的 `Access dashboard` 地址端口为准)

```text
* Access dashboard at: http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/kubernetes-dashboard:/proxy
* Access dashboard at: http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy (if version>1.6 and HTTPS enabled)
```

由于 kubernetes-dashboard 的版本大于 1.6，只能通过 HTTPS endpoint 进行访问，所以我们通过浏览器访问第二个链接地址：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568728523673/wm)

我们需要输入 Kubernetes 集群中的 ServiceAccount 的 Token 才能够访问集群。

###  创建 admin 用户

使用 Kubernetes 集群中的 Service Account 创建一个新用户，给这个新用户 admin 权限，并且允许使用绑定在该用户上的 bearer token 登录 dashboard。

在 /home/shiyanlou 目录下新建 `dashboard-adminuser.yaml` 文件并写入如下内容：

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin-user
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-user
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: admin-user
  namespace: kube-system
```

在这个文件中第一个 YAML 文档表示在 kube-system 命名空间下创建名为 admin-user 的 ServiceAccount，第二个 YAML 文档表示为上面刚刚创建的 admin-user ServiceAccount 绑定名为 cluster-admin 的 ClusterRole 角色（这个角色拥有集群最高权限）。所以这种认证本质上是通过 ServiceAccount 的身份认证加上 Bearer token 请求 API Server 的方式实现。

接下来我们执行资源对象的创建：

```bash
$ kubectl create -f dashboard-adminuser.yaml
serviceaccount/admin-user created
clusterrolebinding.rbac.authorization.k8s.io/admin-user created
```

获取登录所需的 token，在终端执行如下命令：

```bash
$ kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep admin-user | awk '{print $1}')
Name:         admin-user-token-8d6zw
Namespace:    kube-system
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: admin-user
              kubernetes.io/service-account.uid: e1cec333-1de5-476a-8360-9b52010b679a

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1025 bytes
namespace:  11 bytes
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLThkNnp3Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJlMWNlYzMzMy0xZGU1LTQ3NmEtODM2MC05YjUyMDEwYjY3OWEiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZS1zeXN0ZW06YWRtaW4tdXNlciJ9.FvDBr8c0tjrsD04RUiTW_inWPb-T_Gg-jj1paFwQVrb8ZFvCxxZ_MIKQ4SqXrlS0z535tLuxKgIpAq17OgoGN4-B6XPLudj0F2mXUa0Fm5s7gyqEz5vOscitRsfzoiUBPfJDHvR_VHmmZkqBookuPzM6PsuRgdY8bwGw3pz0N5GOxyhTCCy2Gi8UtQppA8m7WYYEXhKrczgmDx6fCzdG1n5y8OKw_Ixfrec6bEGPnKDZxTgmmn2cynWKjrlswBz7tkTB7zh2V7nD7yr1540Mw3TqhgrLgxXGUC5WKuZ5zirWGLUFwhXits5oKqRpNMX4AHnwupB55uH2jXJ1X9ly7Q
```

复制上面输出的 token，然后在 Web UI 界面选择 Enter Token 并粘贴 token 值进行登录，登录后的界面如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568731149308/wm)

###  访问 Dashboard Service 的 4 种方式

```bash
# 查看 kubernetes-dashboard service
$ kubectl get services kubernetes-dashboard -n kube-system
NAME                   TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)   AGE
kubernetes-dashboard   ClusterIP   10.96.231.6   <none>        443/TCP   30d

# 查看 kubernetes-dashboard pod
$ kubectl get pods -n kube-system -o wide|grep dashboard
kubernetes-dashboard-5ff478f859-5lv4d   1/1     Running   0          13m   10.244.3.2   kube-node-2   <none>           <none>
```

1.API Server

前面我们使用 URL 链接地址 `http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy` 就是采用 API Server 的方式进行访问的。

2.kubectl proxy

使用 kubectl proxy 可以在 Client 与 kubernetes API 之间创建一个代理，启动代理只需要执行命令：

```bash
$ kubectl proxy
Starting to serve on 127.0.0.1:8001
```

现在我们可以通过 `http://127.0.0.1:8080/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy` 成功访问到登录页面：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568767587579/wm)

3.NodePort

这种方式将节点直接暴露在外网，建议只在开发环境、单节点使用，不建议在生产环境中使用。不过我们这里依然可以试一下。

执行如下命令修改 kubernetes-dashboard.yaml 文件的设置，将 `type:ClusterIp` 修改为 `type:NodePort`：

```bash
$ kubectl -n kube-system edit service kubernetes-dashboard
service/kubernetes-dashboard edited
```

查看映射后的 Node 端口：

```bash
# 发现映射的 Node 端口为 31147，这里的端口是随机的，大家实验时以你们环境中为准
$ kubectl get service kubernetes-dashboard -n kube-system
NAME                   TYPE       CLUSTER-IP    EXTERNAL-IP   PORT(S)         AGE
kubernetes-dashboard   NodePort   10.96.231.6   <none>        443:31147/TCP   30d

# kubernetes-dashboard 运行在 kube-node-2 节点上
$ kubectl get pods -n kube-system -o wide|grep dashboard
kubernetes-dashboard-5ff478f859-5lv4d   1/1     Running   0          44m   10.244.3.2   kube-node-2   <none>           <none>

# 查看 kube-node-2 节点的集群 IP 地址
$ kubectl get nodes -o wide|grep kube-node-2
kube-node-2   Ready    <none>   30d   v1.15.0   10.192.0.4    <none>        Debian GNU/Linux 9 (stretch)   4.4.0-151-generic   docker://18.9.0
```

在浏览器访问地址 `http://10.192.0.4:31147` 效果如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568770024005/wm)

这里由于缺乏证书并没有成功的响应页面，所以在正式环境中并不推荐使用 NodePort 方式访问 dashboard。

4.Ingress

Ingress 是将开源的反向代理负载均衡器（比如：Nginx）与 kubernetes 集成，这样可以动态更新 Nginx 的配置，是更为灵活、推荐的暴露服务的方式，我们将在后面的实验中加以介绍。

## 3. WebUI 界面简介

kubernetes dashboard 由 4 个部分构成，分别是：

- Cluster
- Workloads
- Discovery and Load Balancing
- Config and Storage

###  Cluster View

点击 Cluster，可以对整个集群的基本情况有一个大致的了解：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190917-1568734093524/wm)

Cluster View 有 5 个子界面，分别为：Namespaces、Nodes、Persistent Volumes、Roles、Storage Classes。点击任意一个子界面都可以查看到该界面的整体视图。

**Namespaces**

Namespaces 子界面展示了整个集群中所有的命名空间，如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568774685470/wm)

点击任意一个 Namespace 可以看到该 Namespace 下的所有相关信息，包括：Name、Creation Time、Status、以及 Events：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568774963438/wm)

**Nodes**

Nodes 子界面展示了整个集群中所有的 Node 列表信息，包括：每个 Node 的 Labels、Status、CPU 和 Memory 的 requests 和 limits：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568775316740/wm)

点击任意一个 Node 可以看到该 Node 下的所有相关信息，包括：Node 的详细信息、分配资源的信息（CPU、Memory、Pods）、Conditions、Pods、Events。

详细信息部分展示了 Node 的基本信息包括：名字、标签、kubelet 版本、kube-proxy 版本、操作系统等信息：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568775909933/wm)

分配资源的信息部分有 3 个视图：CPU allocation、Memory allocation、Pods allocation。CPU 和 Memory 分配视图展示了该节点上的 CPU 和 Memory 的容纳能力、以及该节点所有 Pods 共享的 CPU 的 requests 和 limits。这些数据都可以用绝对值或是百分比来表示，如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568778337798/wm)

CPU requests 是 0.55 个 cpu 或者说是 55% cpu，而集群中是 2 核 cpu，所以在环形图中 CPU requests 占整个节点 CPU 资源的 27.5%。Pods 的分配也是同样的，110 是整个节点可以运行的 Pods 的数量，5 个 Pods 或者是 4.55% 是节点正在运行的 Pods 的数量。

Node 状态部分描述了节点的状态，包括：MemoryPressure、DiskPressure、PIDPressure、Ready，它们的状态都使用 true 或是 false 来表示。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568778976086/wm)

Pods 部分展示了该 Node 上的所有 Pod 列表信息，任意点击一个 Pod 可以看到该 Pod 的详细信息、运行的容器、Pod 的状态、创建信息、事件、持久化存储等信息。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568779446952/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568779608034/wm)

按照同样的方式可以查看剩下的 3 个（Persistent Volumes、Roles、Storage Classes）界面的信息。

###  Workloads View

在 Namespace 部分可以选择 All namespaces 或是其它具体的 namespace（default、kube-node-lease、kube-public、kube-system 等），以此来切换查看不同 namespace 空间下那些非常重要的 kubernetes 资源对象。

Workloads 部分描述了在集群中运行的所有应用，包括 Deployments、Pods、ReplicaSets 等。

比如我们查看 All namespaces 下的 Pods，这个列表展示了所有 Pods 的信息，包括：Namespace、Node、Status、Restarts 等：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568781862522/wm)

点击任意一个 Pod 可以查看到对应 Pod 的相关信息，在页面右上方有一个 LOGS，点击查看该 Pod 的日志：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568789548290/wm)

使用同样的方法可以查看到集群下的其它资源信息。

###  Discovery and Load Balancing

接下来我们看一下服务发现和负载均衡，包括两部分内容：Ingresses 和 Sercices。

Services 部分列出了所属命名空间下每个服务重要的信息，包括：Namespaces、Labels、ClusterIP、Endpoints 等：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568784017307/wm)

点击任意一个 Service，可以看到服务的详细信息、Endpoints、Pods、Events 等：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568784147015/wm)

###  Config and Storage

配置和存储部分包括：ConfigMaps、Persistent Volume Claims、Secrets 这 3 部分的视图。

ConfigMaps 和 Secrets 的界面分别如下所示，查看方式和上面一样，这里我们就不再一一展示了：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568784466438/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568784497347/wm)

## 4. 实验总结

本次实验我们向大家介绍了如下知识点：

- 创建 admin 用户
- 访问 Dashboard Service 的 4 种方式
- WebUI 界面简介

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。