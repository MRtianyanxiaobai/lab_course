# 挑战：修复 YAML 配置文件的格式错误

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

实小楼刚刚开始学习 Kubernetes，他想要使用 Deployment 资源对象创建 2 个 Pod 副本，每个 Pod 中都运行了两个分别名为：front-end 和 rss-reader 的容器，由于不懂 YAML 格式语法，虽然他的数据内容没有错误，但是直接使用 kubectl 创建资源对象会报错，你能帮帮他将格式修改正确吗？

在 `/home/shiyanlou` 目录下新建 `rss-site-deployment.yaml` 文件，目前该文件的内容如下所示：

```yaml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
name: rss-site
spec:
replicas: 2
template:
metadata:
labels:
app: web
spec:
containers:
name: front-end
image: nginx
ports:
containerPort: 80
name: rss-reader
image: nickchase/rss-php-nginx:v1
ports:
containerPort: 88
```

## 目标

修改 `rss-site-deployment.yaml` 文件的 YAML 格式，使得能够成功使用 kubeclt 命令行工具创建 Deployment 资源对象：

```bash
$ kubectl create -f rss-site-deployment.yaml
deployment.extensions/rss-site created

$ kubectl get deployments
NAME       READY   UP-TO-DATE   AVAILABLE   AGE
rss-site   2/2     2            2           2m11s

$ kubectl get pods
NAME                        READY   STATUS    RESTARTS   AGE
rss-site-6d74dff966-7wx6w   2/2     Running   0          3m5s
rss-site-6d74dff966-rx8kx   2/2     Running   0          3m5s
```

如果执行上面的命令可以获取到类似的输出，则表明这个 Deployment 资源对象已经创建成功了。

## 提示语

- 关注 YAML 文件中的属性层级结构
- 将数据在合适的地方修改为数组类型

## 知识点

- 使用 YAML 语法修复配置文件中的格式错误

## 参考答案

修改 `rss-site-deployment.yaml` 文件格式为如下所示：

```yaml
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: rss-site
spec:
  replicas: 2
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
        – name: front-end
          image: nginx
          ports:
            – containerPort: 80
        – name: rss-reader
          image: nickchase/rss-php-nginx:v1
          ports:
            – containerPort: 88
```
