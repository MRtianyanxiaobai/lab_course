# 挑战：使用 WebUI 进行配置

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

还记得前面在实验《部署第一个例子》中我们创建能够成功访问的第一个 web 应用吗？现在我们将尝试通过 kubernetes-dashboard 的 Web 界面来进行资源对象的创建，赶紧使用 WebUI 页面试试吧！

## 目标

- 在 WebUI 页面中创建资源对象，实现成功访问 `10.192.0.2:30001/demo/index.jsp` 页面
- 需要混合使用 3 种创建资源对象的方式：`CREATE FROM TEXT INPUT`、`CREATE FROM FILE` 以及 `CREATE AN APP`

## 提示语

- 进入主页面以后，点击右上方的 CREATE 就可以进行资源的创建
- 相关的 YAML 文件可以参考实验《部署第一个例子》

## 知识点

- 使用 kubernetes-dashboard 的 Web 界面进行资源的创建

## 参考答案

点击页面右上方的 CREATE 按钮进行创建：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797083466/wm)

复制 `mysql-rc.yaml` 文件的内容到 `CREATE FROM TEXT INPUT`，然后点击 UPLOAD：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797328506/wm)

等待 mysql Pod 的创建：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797481398/wm)

mysql Pod 创建成功：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797503521/wm)

在 `/home/shiyanlou` 目录下新建 `mysql-svc.yaml` 文件并写入对应的代码，使用 `CREATE FROM FILE` 方式进行创建：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797660919/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568797730608/wm)

参考 myweb-rc.yaml 文件的内容，使用 `CREATE AN APP` 的方式进行创建，注意相应数据的填写：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800035334/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800051920/wm)

等待 myweb Pod 创建：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800082611/wm)

myweb Pod 创建成功：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800095841/wm)

复制 myweb-svc.yaml 文件的内容到 `CREATE FROM TEXT INPUT`，然后点击 UPLOAD：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800127258/wm)

查看 myweb Service 创建成功：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800135678/wm)

最后通过浏览器能够成功访问 `10.192.0.2:30001/demo/index.jsp` 页面：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190918-1568800195713/wm)