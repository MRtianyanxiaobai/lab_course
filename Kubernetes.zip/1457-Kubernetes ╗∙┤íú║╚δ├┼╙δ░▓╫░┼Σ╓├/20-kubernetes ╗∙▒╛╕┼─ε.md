---
show: step
version: 1.0
---

# Kubernetes 基本概念

## 1.实验介绍

####  实验内容

本次实验我们主要向大家介绍 Kubernetes 的架构以及其中涉及到的核心概念。

####  实验知识点

- Kubernetes 架构
- Kubernetes API 对象和核心概念

####  推荐阅读

- [CoreDNS 使用与架构分析](https://zhengyinyong.com/coredns-basis.html)
- [深入解析声明式 API（一）：API 对象的奥秘](http://www.unmin.club/?p=670)

## 2.Kubernetes 架构

Kubernetes 采用微服务架构设计，整个系统被划分为各个功能独立的组件，这些组件之间边界清晰，部署简单，可以运行在多种系统和环境中。

Kubernetes 采用主从分布式架构，节点在角色上分为 Master 和 Node，下图为 Kubernetes 的架构图：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190822-1566461864714/wm)

下面这张图表示的也是 Kubernetes 的架构设计以及组件之间的通信协议：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190823-1566516102920/wm)

如果大家依然觉得上面的图示看上去比较抽象复杂的话，下面还有一个最简化的架构版本可以供大家目前作为参考理解：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190823-1566516308652/wm)

最后，Kubernetes 的设计理念和功能类似于 Linux 分层架构，示意图如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190823-1566527315918/wm)

### Master 节点中的组件

Kubernetes Master 是控制节点，用于调度管理整个系统。它的架构图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190823-1566516544539/wm)

有如下组件：

- `Kubernetes API Server`: 这是 Kubernetes 系统资源操作的唯一入口，并提供认证、授权、访问控制、API 注册和发现等机制，其中封装了核心对象的增删改查操作，外部的客户端和内部的组件可以通过调用 REST API 接口的方式获取数据信息，这些数据信息都存储到了 Etcd 中。
- `Kubernetes Scheduler`: 负责集群中的资源调度，比如：为新建的 Pod 分配机器。后续也可以根据需要替换为其它的调度器。
- `Kubernetes Controller Manager`: 负责执行各种控制器，用于保证 Kubernetes 的正常运行和维护集群的状态。
- `Etcd`: 存储中间件，用于保存集群所有的网络配置和对象的状态信息。Etcd 是高可用的键值存储系统，通过 Raft 一致性算法处理日志复制来保证强一致性。Kubernetes 中的重要数据都持久化到 Etcd 中，所有架构中的各个组件都是无状态的。

Kubernetes 中的控制器列表如下所示：

| 控制器 | 作用 |
| ----- | --- |
| Replication Controller | 保证 Replication Controller 定义的副本数量与实际运行 Pod 的数量一致 |
| Node Controller | 定期检查 Node 的健康状态，标识出失效的 Node |
| Namespace Controller | 定期清理无效的 Namespace，以及 Namespace 下的 API 对象，比如：Pod、Service、Secrte 等|
| Endpoints Controller | 创建 Endpoints 作为 Service 的后端，当 Pod 发生变化时，定期刷新 Endpoints |
| Service Account Controller | 为每个 Namespace 创建默认的 Service Account，并为 Service Account 创建 Service Account Secret |
| Persistent Volume Controller | 使用 Persistent Volume 绑定新的 Persistent Volume Claim，清理回收已经释放的 Volume Claim |
| Daemon Set Controller | 创建 Daemon Pod，保证指定的 Node 上正常运行 Daemon Pod |
| Deployment Controller | 保证运行指定数目的 Pod，当 Deployment 更新时，控制实现 Replication Controller 和 Pod 的更新 |
| Job Controller | 为 Job 创建一次性任务 Pod，确保完成 Job 指定完成的任务数目 |
| Pod Autoscaler Controller | 实现 Pod 的自动伸缩，定时获取监控数据，进行策略匹配，当满足条件时执行 Pod 的伸缩动作 |

### Node 节点中的组件

Kubernetes Node 是运行节点，主要用于运行管理业务的容器。它的架构图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190823-1566516674564/wm)

有如下组件：

- `Kubelet`：主要负责维护容器的生命周期，Kubelet 可以从 Master 节点中的 Kubernetes REST API Server 中接收创建 Pod 的请求，启动和停止容器，监控容器运行状态并汇报给 Kubernetes API Server，也负责 Volume（CSI） 和网络（CNI）的管理。
- `Kubernetes Proxy`：负责为 Pod 创建代理服务，Kubernetes Proxy 会从 Master 节点中的 Kubernetes REST API Server 中获取所有的 Service，根据 Service 信息创建代理服务，实现 Service 到 Pod 的请求路由转发，实现 Kubernetes 层级的虚拟转发网络，换句话说也就是集群内部的服务发现和负载均衡。
- `Kubernetes Container Runtime`：容器运行时，Node 是使用容器运行的节点，可以使用多种容器，其中最常使用的就是 Docker 服务（CRI）。

### 推荐的插件

除了前面提到的核心组件外，还有一些推荐的插件：

- `CoreDNS`：为整个集群提供 DNS 服务。
- `Ingress Controller`：为服务提供外网入口。
- `Dashboard`：提供 GUI（图形用户界面）。
- `Federation`：提供跨可用区的集群。
- `Fluentd`：日志收集。

### 开放接口

Kubernetes 作为云原生应用的基础调度平台，等同于云原生的操作系统，考虑到系统的可扩展性开放了以下的接口，我们可以按照自己业务的需求对接不同的后端进行定制化，下面的三种资源类型是一个分布式操作系统最基础的资源类型，Kubernetes 将它们整合在了一起：

- `CRI`(Container Runtime Interface)：容器运行时接口，提供计算资源。其中定义了容器和镜像的服务接口，容器运行时和镜像的生命周期是彼此隔离的。Kubernetes 默认使用 Docker 作为容器运行时，也可以通过 CRI 接口指定其它容器运行时作为 Pod 的后端。
- `CNI`(Container Network Interface)：容器网络接口，提供网络资源。它由一组配置 Linux 容器的网络接口的规范和库组成，同时还包含了一些插件。
- `CSI`(Container Storage Interface)：容器存储接口，提供存储资源。

## 3.Kubernetes API 对象和核心概念

本节我们主要介绍 Kubernetes API 对象和其中的核心概念，只有理解了这些核心概念才能理解  Kubernetes 的运行原理。

#### API 对象

Kubernetes 中大部分的概念都可以被看做是一种资源对象，通过 `kubectl` 命令行工具就可以实现对这些资源对象执行增、删、改、查等操作并且保存在 Etcd 中进行持久化存储。Kubernetes 通过对比存储在 Etcd 库里面的“资源期望状态”和当前环境中的“实际资源状态”的差异来实现自动控制和自动纠错，努力使“实际资源状态”和“资源期望状态”保持一致。

API 对象是 Kubernetes 集群中的管理操作单元。一旦创建对象 Kubernetes 会持续工作来保证对象的存在。

在 Kubernetes 中，一个 API 对象在 Etcd 中的完整资源路径是由：Group(API 组)、Version(API 版本) 和 Resource(API 资源类型) 构成。如果想要查找更多关于 API 信息可以参考 [kubernetes-api/v1.15](https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.15/#-strong-api-overview-strong-)。

在声明一个 Kubernetes 资源对象时需要注意一个关键属性：apiVersion。

每个 API 对象有 3 大类属性：

- `metadata`：元数据。用来标识 API 对象，每个对象都至少有 3 个元数据：`namespace`、`name` 和 `uid`，还可以使用标签 `labels` 标识和匹配不同的对象。
- `spec`：规范。描述用户期望集群中的分布式系统达到的理想状态。
- `status`：状态。描述系统当前达到的状态。在任何时候，Kubernetes 会管理对象使它的实际状态和期望状态相一致。

#### Pod

Pod 是 Kubernetes 中最重要的核心概念，Kubernetes 中其它的对象都是在管理、暴露 Pod 或是被 Pod 使用。一个 Pod 是 Kubernetes 最基本的构建单元，也是最小、最简单的构建单元。Pod 也是扩缩容的基本单位，Kubernetes 的扩容和缩容都是直接对 Pod 进行操作的，直接增加 Pod 或是减少 Pod。

#### Label

Label(标签)，一个 Label 是一个 key=value 的键值对，用户可以自定义 key 和 value。标签可以添加到各种资源对象上，标签和资源对象是多对多的关系。通过标签可以对资源对象进行多维度的管理，这样可以方便灵活的进行资源分配、调度、配置和部署等工作。

#### ReplicationController

ReplicationController(副本控制器，简写：RC)，RC 是 Kubernetes 最开始用来保证集群中 Pod 高可用的资源对象。它通过启动或删除 Pod 来保证运行中的 Pod 数量跟要求一致。RC 只适用于长期运行的服务型应用，它已经被更加强大的 RS 取代。

#### ReplicaSet

ReplicaSet(副本集，简写：RS)，RS 是 RC 的替代者，相比于 RC，它支持更多种的应用类型。RS 一般不单独使用，而是作为 Deployment 的期望状态来使用。

#### Deployment

Deployment(部署)，用来描述应用的运行状态，包括运行多少个 Pod 副本，每个 Pod 里包含哪些容器，每个容器运行哪个镜像等。Deployment 创建完成之后，可以对其进行更新，比如修改镜像版本，扩容或缩减副本数量等。如果更新出现问题，还可以回滚到以前的版本。

#### Service

Service(服务)，通过 Deployment 我们能够完成应用部署，但如何访问应用提供的服务呢？因为 Deployment 的 Pod 可能有多个，并且这些 Pod 所在的 Node 并不固定，因此没法使用固定的 IP 和端口去访问。Kubernetes 使用 Service 来解决此问题，一个 Service 对应一个应用，代表该应用提供的服务。每个 Service 有一个集群内部的虚拟 IP，客户端通过该 IP 来请求应用服务时，kube-proxy 会将请求转发给 Deployment 中的某个 Pod。当 Pod 位置发生变化时，kube-proxy 能够及时感知到。通过 kube-proxy 就解决了单个 Pod 服务的注册和发现问题，同时也实现了负载均衡。

#### Horizontal Pode Autoscaler

Horizontal Pode Autoscaler(Pod 横向自动扩容，简写：HPA)，通过追逐分析指定 RS 控制的所有目标 Pod 的负载变化情况，来确定是否需要有针对性地调整目标 Pod 的副本数量，目前有两种方式来作为 Pod 负载的度量指标：CPUUtilizationPercentage(目标 Pod 所有副本自身的 CPU 利用率的平均值)，和应用程序自定义的度量指标。

#### StatefulSet

StatefulSet(有状态服务集)，有时候希望在所有 Node 上都运行某个 Pod，比如网络路由、存储、日志、监控等服务，这个时候就可以使用 DaemonSet。

#### Job

Job(任务)，Deployment 代表的是长期运行的应用服务，而短暂运行的应用（比如定时任务）就要用 Job 来表示。Job 有开始和结束，可以使用一个或多个 Pod 来执行。在多个 Pod 上运行时，运行成功可以配置为是其中一个完成还是全部都完成。

#### Volume

Volume(存储卷)，Volume 是存储的抽象，Kubernetes 中的存储卷跟 Docker 中的类似，只不过 Docker 中存储卷的作用范围是单个容器，而 Kubernetes 中是单个 Pod，被 Pod 中的多个容器共享。

#### Persistent Volume 和 Persistent Volume Claim

Persistent Volume(持久存储卷，简写：PV)，Persistent Volume Claim(持久存储卷声明，简写：PVC)，就像 Node 提供计算资源，PV 提供了存储资源。PV 是对底层存储服务的抽象，其实现方式可以是本地磁盘，也可以是网络磁盘。PVC 用来描述 Pod 对存储资源的需求，它需要绑定到某个 PV。PV 和 PVC 是一对一关系，而 PV 和 Pod 是多对多关系，单个 PV 可以被多个 Pod 共享，且单个 Pod 可以绑定多个 PV。

#### Namespace

Namespace(命名空间)，命名空间为同一个 Kubernetes 集群里的资源对象提供了虚拟的隔离空间，避免了命名冲突，比如在同一个集群里同时部署测试环境和生产环境服务。Kubernetes 里默认提供了两个命名空间，分别是 default 和 kube-system，前者是资源对象默认所属的空间，后者是 Kubernetes 自身资源对象所属的空间。只有集群管理员能够创建新的命名空间。

#### Secret

Secret(密钥对象)，Secret 对象用来存放密码、CA 证书等敏感信息，这些信息不适合直接用明文写在 Kubernetes 的对象配置文件里。Secret 对象可以由管理员预先创建好，然后在对象配置文件里通过名称来引用。这样可以降低敏感信息暴露的风险，也便于统一管理。

#### User Account 和 Service Account

User Account(用户帐号)和 Service Account(服务帐号)，用户帐号为人提供身份标识，而服务帐号为 Kubernetes 集群中的 Pod 提供身份标识。用户帐号与命名空间无关，是跨命名空间的，而服务帐号属于某一个命名空间。

#### Role-based Access Control

Role-based Access Control(访问授权，简写：RBAC)，使用 RBAC，用户不再直接跟权限进行关联，而是通过角色。角色代表的一组权限，用户可以具备一种或多种角色，从而具有这些角色所包含的权限。如果角色权限有调整，那么所有具有该角色的用户权限自然而然就随之改变。

#### Annotation

Annotation(注解)，与 Label 类似，使用 Key/Value 键值对的形式进行定义，相较于 Label，它可以用来保存更大的键值对，并且可能包含可读性低的数据，目的是用来保存非辨认性目的的数据，特别是那些由工具和系统扩展操作的数据。主要是用于用户任意定义的附加信息，方便外部工具的查找。Annotation 的值无法用来进行有效地过滤。

## 4.实验总结

本次实验我们主要向大家介绍了如下的内容：

- Kubernetes 架构
- Kubernetes API 对象和核心概念

前面介绍的这些组件是 Kubernetes 的核心组件，它们共同构成了 Kubernetes 的框架和计算模型，通过灵活运用这些组件和概念，我们可以快速灵活地对 Kubernetes 集群进行配置、创建和管理。

希望可以通过前面的架构分析和核心概念梳理，大家能够对 Kubernetes 有一个全局整体的认识，后面还会多次遇到这些概念，通过反复的运用大家一定可以深入的理解 Kubernetes 集群。

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。