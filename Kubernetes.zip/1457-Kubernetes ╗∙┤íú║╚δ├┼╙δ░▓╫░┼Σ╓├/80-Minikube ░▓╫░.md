---
show: step
version: 1.0
---

# Minikube 安装

## 1.实验介绍

####  实验内容

本次实验我们主要带领大家在本地机器使用 Minikube 运行单节点 Kubernetes 集群，然后使用一个简单的例子测试集群。

注意：本次实验不在实验环境中进行，需要大家在自己的本地进行安装。

####  实验知识点

- Minikube 的安装
- Minikube 的简单使用

####  推荐阅读

- [Minikube GitHub 仓库](https://github.com/kubernetes/minikube)
- [Minikube 官方网站](https://minikube.sigs.k8s.io/)
- [install and set up kubectl](https://kubernetes.io/docs/tasks/tools/install-kubectl/)

## 2.Minikube 的安装

在本地机器使用 Minikube 运行单节点 Kubernetes 集群，对于测试和本地开发都非常有帮助。

Minikube 使用本地虚拟机环境部署 Kubernetes，其基本架构如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567149890236/wm)

###  安装虚拟软件

- 对于 macOS，可安装 [VirtualBox](https://www.virtualbox.org/wiki/Downloads)，[VMware Fusion](https://www.vmware.com/products/fusion) 或 [HyperKit](https://github.com/moby/hyperkit)
- 对于 Linux，可安装 [VirtualBox](https://www.virtualbox.org/wiki/Downloads) 或 [KVM](https://www.linux-kvm.org/page/Main_Page)
- 对于 Windows，可安装 [VirtualBox](https://www.virtualbox.org/wiki/Downloads) 或 [Hyper-V](https://docs.microsoft.com/zh-cn/virtualization/hyper-v-on-windows/quick-start/enable-hyper-v)

> 对于 Linux，Minikube 也可以通过 `–vm-driver=none` 选项支持在本地系统里运行 Kubernetes 各个组件，而不是在虚拟机里。这种方式只依赖 Docker，不需要安装虚拟机软件。

###  安装 kubectl

[kubectl](https://kubernetes.io/docs/reference/kubectl/kubectl/) 是一个命令行工具，可以使用它来部署和管理 Kubernetes 集群。其安装方式也有很多种，这里只挑选几种典型的加以介绍：

#### Ubuntu 和 Debian 系统

说明：源都在国外，大家注意网络问题。

```bash
$ sudo apt-get update && sudo apt-get install -y apt-transport-https
$ curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
# 如果上面这条命令执行报错，可以执行下面这条命令
$ curl -s https://labfile.oss.aliyuncs.com/courses/1457/apt-key.gpg | sudo apt-key add -
$ echo "deb https://apt.kubernetes.io/ kubernetes-xenial main" | sudo tee -a /etc/apt/sources.list.d/kubernetes.list
$ sudo apt-get update
$ sudo apt-get install -y kubectl
```

#### CentOS 和 RHEL 系统

说明：源都在国外，大家注意网络问题。

```bash
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF
yum install -y kubectl
```

#### macOS 系统

可通过 [Homebrew](https://brew.sh/) 工具来安装，如果没有该工具请先安装。

```bash
brew install kubernetes-cli
```

有的时候使用 brew 比较慢的话，也可以使用 curl 进行安装：

```bash
curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.15.0/bin/darwin/amd64/kubectl
chmod +x ./kubectl
sudo mv ./kubectl /usr/local/bin/kubectl
```

#### Windows 系统

可通过 [Powershell Gallery](https://www.powershellgallery.com/) 工具来安装，如果没有该工具请先安装。

```bash
Install-Script -Name install-kubectl -Scope CurrentUser -Force
install-kubectl.ps1 [-DownloadLocation <path>]
```

如果 Downloadlocation 未指定，则会安装在用户的 `temp` 目录。配置文件存放在 `$HOME/.kube` 目录下。如果要更新重新运行 `install-kubectl.ps1` 脚本即可。

###  验证是否安装成功

```bash
$ kubectl version
Client Version: version.Info{Major:"1", Minor:"15", GitVersion:"v1.15.0", GitCommit:"e8462b5b5dc2584fdcd18e6bcfe9f1e4d970a529", GitTreeState:"clean", BuildDate:"2019-06-19T16:40:16Z", GoVersion:"go1.12.5", Compiler:"gc", Platform:"darwin/amd64"}
The connection to the server localhost:8080 was refused - did you specify the right host or port?
```

###  安装 Minikube

对于 Linux 系统可以执行如下命令进行安装：

```bash
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64 \
   && sudo install minikube-linux-amd64 /usr/local/bin/minikube
```

Windows 系统可以直接下载安装包：[minikube installer](https://storage.googleapis.com/minikube/releases/latest/minikube-installer.exe) 进行安装。

接下来我们基于 macOS 系统进行演示。

#### 有代理可以直接访问国外网络

执行如下命令进行安装：

```bash
brew cask install minikube

# 如果上述方式比较慢的话，也可以采用 curl 的方式
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-darwin-amd64 \
  && sudo install minikube-darwin-amd64 /usr/local/bin/minikube
```

在这里我们使用的是 VirtualBox 作为虚拟机（注意 VirtualBox 需要 5.2 或是更高的版本），现在执行如下命令来部署和启动一个 Kubernetes 集群，在部署过程中会下载各个组件的镜像，由于镜像仓库在国外，请设置好系统全局代理：

```bash
minikube start --vm-driver=virtualbox
```

#### 没有代理无法直接访问国外网络

如果大家在部署的过程中遇到了 `ERROR ImagePull` 的错误，可以尝试使用阿里云修改后的 minikube 文件进行解决。

对于 Mac OSX 系统：

```bash
curl -Lo minikube http://kubernetes.oss-cn-hangzhou.aliyuncs.com/minikube/releases/v1.3.1/minikube-darwin-amd64 && chmod +x minikube && sudo mv minikube /usr/local/bin/
```

对于 Linux 系统：

```bash
curl -Lo minikube http://kubernetes.oss-cn-hangzhou.aliyuncs.com/minikube/releases/v1.3.1/minikube-linux-amd64 && chmod +x minikube && sudo mv minikube /usr/local/bin/
```

对于 Windows 系统：

下载 [minikube-windows-amd64.exe](http://kubernetes.oss-cn-hangzhou.aliyuncs.com/minikube/releases/v1.2.0/minikube-windows-amd64.exe) 文件，并重命名为 `minikube.exe`。

然后执行创建：

```bash
# 这里用了中科大镜像加速地址，并且指定 kubernetes 的版本为 v1.15.2
$ minikube start --vm-driver=virtualbox --registry-mirror=https://docker.mirrors.ustc.edu.cn --kubernetes-version v1.15.2

😄  minikube v1.3.1 on Darwin 10.14.6
✅  Using image repository registry.cn-hangzhou.aliyuncs.com/google_containers
💡  Tip: Use 'minikube start -p <name>' to create a new cluster, or 'minikube delete' to delete this one.
🔄  Starting existing virtualbox VM for "minikube" ...
⌛  Waiting for the host to be provisioned ...
🐳  Preparing Kubernetes v1.15.2 on Docker 18.09.8 ...
🔄  Relaunching Kubernetes using kubeadm ...
⌛  Waiting for: apiserver proxy etcd scheduler controller dns
🏄  Done! kubectl is now configured to use "minikube"
```

在 minikube 启动以后我们可以使用 kubectl 命令行工具和 minikube 集群进行交互，比如查看 Pod 的运行情况：

```bash
$ kubectl get po -A
NAMESPACE     NAME                                  READY   STATUS             RESTARTS   AGE
kube-system   coredns-6967fb4995-jc2m5              1/1     Running            2          41m
kube-system   coredns-6967fb4995-m92nm              1/1     Running            2          41m
kube-system   etcd-minikube                         1/1     Running            1          40m
kube-system   kube-addon-manager-minikube           1/1     Running            1          40m
kube-system   kube-apiserver-minikube               1/1     Running            1          40m
kube-system   kube-controller-manager-minikube      1/1     Running            1          40m
kube-system   kube-proxy-hkpwt                      1/1     Running            1          41m
kube-system   kube-scheduler-minikube               1/1     Running            1          40m
kube-system   kubernetes-dashboard-95564f4f-5bn8p   0/1     CrashLoopBackOff   9          9m14s
kube-system   storage-provisioner                   1/1     Running            2          41m
```

可以看到集群中 kubernetes-dashboard 没有正常启动，通过 `kubectl logs kubernetes-dashboard-95564f4f-5bn8p --namespace=kube-system` 命令可以查看其中的原因，现在解决方法如下：

```bash
# 创建集群角色绑定
$ kubectl create clusterrolebinding kube-system-cluster-admin --clusterrole=cluster-admin --serviceaccount=kube-system:default
clusterrolebinding.rbac.authorization.k8s.io/kube-system-cluster-admin created

# 删除之前失败的 kubernetes-dashboard pod
$ kubectl delete pod kubernetes-dashboard-95564f4f-5bn8p -n kube-system
pod "kubernetes-dashboard-95564f4f-5bn8p" deleted

# 重新查看系统级别的 pod 可以发现 kubernetes-dashboard 已经成功启动
$ kubectl get po -A
NAMESPACE     NAME                                  READY   STATUS    RESTARTS   AGE
kube-system   coredns-6967fb4995-jc2m5              1/1     Running   2          60m
kube-system   coredns-6967fb4995-m92nm              1/1     Running   2          60m
kube-system   etcd-minikube                         1/1     Running   1          59m
kube-system   kube-addon-manager-minikube           1/1     Running   1          59m
kube-system   kube-apiserver-minikube               1/1     Running   1          59m
kube-system   kube-controller-manager-minikube      1/1     Running   1          59m
kube-system   kube-proxy-hkpwt                      1/1     Running   1          60m
kube-system   kube-scheduler-minikube               1/1     Running   1          59m
kube-system   kubernetes-dashboard-95564f4f-j6nk2   1/1     Running   0          30s
kube-system   storage-provisioner                   1/1     Running   2          60m
```

现在打开 Kubernetes Web 控制台，在 Web 控制台里可查看集群状态和执行管理操作。

```bash
$ minikube dashboard
🤔  Verifying dashboard health ...
🚀  Launching proxy ...
🤔  Verifying proxy health ...
🎉  Opening http://127.0.0.1:51187/api/v1/namespaces/kube-system/services/http:kubernetes-dashboard:/proxy/ in your default browser...
```

页面效果如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567147065974/wm)

## 3.Minikube 的简单使用

集群部署和启动成功后，执行下面的命令部署一个测试用的 echoserver 应用到集群里来测试集群的正确性。

创建一个名为 hello-minikube 的 deployment 资源对象，使用的镜像是存储在阿里云服务器上的一个镜像资源 echoserver:1.4，并且指定创建的容器开放 8080 端口：

```bash
$ kubectl run hello-minikube --image=registry.cn-hangzhou.aliyuncs.com/chenshi-kubernetes/echoserver:1.4 --port=8080
deployment.apps/hello-minikube created

$ kubectl get deployments
NAME             READY   UP-TO-DATE   AVAILABLE   AGE
hello-minikube   1/1     1            1           3m46s

$ kubectl get pods
NAME                             READY   STATUS    RESTARTS   AGE
hello-minikube-9594c7764-lpl4w   1/1     Running   0          3m54s
```

暴露出可供外部访问的服务端口：

```bash
$ kubectl expose deployment hello-minikube --type=NodePort
service/hello-minikube exposed
```

执行如下命令使 minikube 在浏览器自动打开暴露出来的 URL 地址：

```bash
# 查看 url 地址
$ minikube service hello-minikube --url
http://192.168.99.101:30826

$ minikube service hello-minikube
|-----------|----------------|-----------------------------|
| NAMESPACE |      NAME      |             URL             |
|-----------|----------------|-----------------------------|
| default   | hello-minikube | http://192.168.99.101:30826 |
|-----------|----------------|-----------------------------|
🎉  Opening kubernetes service  default/hello-minikube in default browser...
```

页面如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567149426458/wm)

这个时候刷新 Kubernetes Web 控制台可以看到整个集群的状态信息：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190830-1567149691942/wm)

测试没有问题的话，可以删除服务和应用：

```bash
$ kubectl delete services hello-minikube
service "hello-minikube" deleted

$ kubectl delete deployment hello-minikube
deployment.extensions "hello-minikube" deleted
```

Minikube 提供了大量的内建插件可以被设置为使用或是禁用，使用如下命令列出可以使用的插件：

```bash
$ minikube addons list
- addon-manager: enabled
- dashboard: enabled
- default-storageclass: enabled
- efk: disabled
- freshpod: disabled
- gvisor: disabled
- heapster: disabled
- ingress: disabled
- logviewer: disabled
- metrics-server: disabled
- nvidia-driver-installer: disabled
- nvidia-gpu-device-plugin: disabled
- registry: disabled
- registry-creds: disabled
- storage-provisioner: enabled
- storage-provisioner-gluster: disabled
```

可以开启使用一个插件，比如 `heapster`：

```bash
$ minikube addons enable heapster
✅  heapster was successfully enabled
```

查看创建的 pod 和 service，可以看到 heapster 插件已经被启用：

```bash
$ kubectl get pod,svc -n kube-system
NAME                                      READY   STATUS    RESTARTS   AGE
pod/coredns-6967fb4995-jc2m5              1/1     Running   2          133m
pod/coredns-6967fb4995-m92nm              1/1     Running   2          133m
pod/etcd-minikube                         1/1     Running   1          132m
pod/heapster-qvp87                        1/1     Running   0          7m13s
pod/influxdb-grafana-pbbwf                2/2     Running   0          7m13s
pod/kube-addon-manager-minikube           1/1     Running   1          132m
pod/kube-apiserver-minikube               1/1     Running   1          132m
pod/kube-controller-manager-minikube      1/1     Running   1          132m
pod/kube-proxy-hkpwt                      1/1     Running   1          133m
pod/kube-scheduler-minikube               1/1     Running   1          132m
pod/kubernetes-dashboard-95564f4f-j6nk2   1/1     Running   0          73m
pod/storage-provisioner                   1/1     Running   2          133m

NAME                           TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)                  AGE
service/heapster               ClusterIP   10.111.223.48   <none>        80/TCP                   7m13s
service/kube-dns               ClusterIP   10.96.0.10      <none>        53/UDP,53/TCP,9153/TCP   133m
service/kubernetes-dashboard   ClusterIP   10.99.230.22    <none>        80/TCP                   101m
service/monitoring-grafana     NodePort    10.102.52.249   <none>        80:30002/TCP             7m13s
service/monitoring-influxdb    ClusterIP   10.107.157.61   <none>        8083/TCP,8086/TCP        7m13s
```

执行如下命令禁用 heapster 插件：

```bash
$ minikube addons disable heapster
✅  "heapster" was successfully disabled
```

最后停止集群：

```bash
$ minikube stop
✋  Stopping "minikube" in virtualbox ...
🛑  "minikube" stopped.
```

## 4.实验总结

本次实验我们向大家介绍了如下知识点：

- Minikube 的安装
- Minikube 的简单使用

主要集中在安装和简单的运行使用，可以发现使用 Minikube 在本地进行部署和使用还是比较方便，对于新手而言相对比较友好，大家如果想要更加深入的学习和使用 Minikube，推荐参考官方文档 [Core Tasks](https://minikube.sigs.k8s.io/docs/tasks/) 继续学习。

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
