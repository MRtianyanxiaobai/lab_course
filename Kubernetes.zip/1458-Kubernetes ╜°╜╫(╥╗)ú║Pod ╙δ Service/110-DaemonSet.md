---
show: step
version: 1.0
---

# DaemonSet

## 1.实验介绍

####  实验内容

本次实验我们将会介绍 DaemonSet，它的作用是在每个 Node 上都调度一个 Pod，因此 DaemonSet 的出现解决了集群中的一个问题：如何同时在集群中的所有节点上提供基础服务和守护进程。

####  实验知识点

- DaemonSet 简介
- 运行示例程序
- 滚动更新

## 2. DaemonSet 简介

DaemonSet 资源对象可以保证 kubernetes 集群中所有或部分 Node 都只能够运行一份 Pod 副本实例。当有新的 Node 加入集群时，kubernetes 将会在新 Node 上创建新的 Pod 副本；如果有 Node 被集群移除，节点上对应的 Pod 也会被清除。

DaemonSet 会管理所有 Node 上的 Pod 副本，保持集群中的 Pod 和 Node 为一一对应的关系，同时也负责对它们进行更新和删除。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20190928-1569648832899/wm)

DaemonSet 类似于计算机中的守护进程，运行集群中必备的基础服务，常见的用法如下：

- `集群存储`：比如 GlusterFS 存储、Ceph 存储等
- `日志收集`：比如 Fluentd、Logstash 等
- `性能监控`：用于采集 Node 的运行数据，比如 Prometheus Node Exporter、collectd、New Relic agent、Ganglia gmond 等
- `系统程序`：比如 kube-proxy、kube-dns、glusterd、ceph 等

## 3. 运行示例程序

比如我们要求在每个 Node 节点都运行一个 fluentd 容器，并且每个容器都需要挂载物理机的两个目录 `/var/log` 和 `/var/lib/docker/containers`，在 `/home/shiyanlou` 目录下新建 `fluentd-ds.yaml` 文件，并写入如下内容：

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd-cloud-logging
  namespace: kube-system
spec:
  selector:
    matchLabels:
      k8s-app: fluentd-cloud-logging
  template:
    metadata:
      namespace: kube-system
      labels:
        k8s-app: fluentd-cloud-logging
    spec:
      containers:
      - name: fluentd-cloud-logging
        image: registry-vpc.cn-hangzhou.aliyuncs.com/chenshi-kubernetes/fluentd-elasticsearch:1.17
        resources:
          limits:
            cpu: 100m
            memory: 200Mi
        env:
        - name: FLUENTD_ARGS
          value: -q
        volumeMounts:
        - name: varlog
          mountPath: /var/log
          readOnly: false
        - name: containers
          mountPath: /var/lib/docker/containers
          readOnly: false
      volumes:
      - name: varlog
        hostPath:
          path: /var/log
      - name: containers
        hostPath:
          path: /var/lib/docker/containers
```

执行创建：

```bash
$ kubectl create -f fluentd-ds.yaml
daemonset.apps/fluentd-cloud-logging created
```

查看创建好的 DaemonSet 和 Pod：

```bash
$ kubectl get daemonset -n kube-system
NAME                    DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR                 AGE
fluentd-cloud-logging   2         2         2       2            2           <none>                        63s

# 分别在 kube-node-1 和 kube-node-2 两个节点上创建了一个 fluentd-cloud Pod
$ kubectl get pods -n kube-system -o wide|grep fluentd-cloud-logging
fluentd-cloud-logging-4p6k5             1/1     Running   0          2m24s   10.244.2.5   kube-node-1   <none>           <none>
fluentd-cloud-logging-qmt5h             1/1     Running   0          2m24s   10.244.3.4   kube-node-2   <none>           <none>
```

执行删除：

```bash
$ kubectl delete daemonsets.app fluentd-cloud-logging -n kube-system
daemonset.apps "fluentd-cloud-logging" deleted

# 也可以通过 YAML 文件删除
$ kubectl delete -f fluentd-ds.yaml
daemonset.apps/fluentd-cloud-logging deleted
```

## 4. 滚动更新

DaemonSet 可以使用字段 `spec.updateStrategy.type` 设置更新策略，目前支持两种策略：

- `RolingUpdate`：更新 DaemonSet 模板后，自动删除旧的 Pod 并创建新的 Pod
- `OnDelete`：默认策略，更新 DaemonSet 模板后，只有手动删除了旧的 Pod 才会创建新的 Pod

在使用 `RolingUpdate` 策略时，还可以设置字段：

- `spec.updateStrategy.rollingUpdate.maxUnavailable`，默认值为 1
- `spec.minReadySeconds`，默认值为 0

具体的设置信息可以如下所示：

```yaml
...
spec:
  updateStrategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 2
  minReadySeconds: 30
...
```

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- DaemonSet 简介
- 运行示例程序
- 滚动更新

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
