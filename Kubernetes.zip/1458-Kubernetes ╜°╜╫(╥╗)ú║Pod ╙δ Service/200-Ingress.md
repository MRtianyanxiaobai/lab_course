---
show: step
version: 1.0
---

# Ingress

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Ingress。

从前面介绍的几种服务类型 ClusterIP、NodePort、LoadBalancer 来看，使用 Service 提供的负载均衡有以下几种限制：

- 使用方式为 `IP:Port`，只提供 4 层负载均衡（TCP/IP 层），不支持 7 层负载均衡功能。比如：不能按需要的匹配规则自定义转发请求。
- 对于 NodePort Service，需要在集群外部署负载均衡器。
- 对于 LoadBalancer Service，集群必须运行在云服务上。

如果只使用 Service 局限性也比较大，对于提供 HTTP 服务而言，不同的 URL 地址需要不同的后端服务进行处理。因此在 kubernetes v1.1 版本中，添加了 `Ingress` API（beat 版本），这样就可以提供 7 层负载均衡（HTTP/HTTPS）。Ingress 资源对象可以将客户端对不同 URL 的访问转发到不同的后端 Service，这样就实现了 HTTP/HTTPS 层的路由转发功能。

需要注意的是：Ingress 并不是服务。它是位于多个服务之间，充当集群中的智能路由器或是入口点。

####  实验知识点

- Ingress 简介
- 部署 nginx-ingress-controller
- 部署一个简单的 Nginx 实例
- 不同的 Ingress 策略配置类型
- 配置 Ingress 处理 TLS 传输

####  推荐阅读

- [Ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/)
- [Ingress Controllers](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/)
- [ingress-nginx GitHub 仓库](https://github.com/kubernetes/ingress-nginx)
- [ingress-nginx 官方文档](https://kubernetes.github.io/ingress-nginx/)

## 2. Ingress 简介

Ingress 不仅可以让外部客户端访问服务，还可以自定义服务的访问策略。在前面介绍的 LoadBalancer Service 中，我们知道每一个服务都需要定义一个负载均衡器和唯一的共有 IP 地址，如果一个应用可以提供多种服务，那么显然这种方式是不够友好的。而 Ingress 只需要一个公网 IP 地址就可以为多个服务提供自定义的访问。因此，Ingress 是一种非常灵活、得到越来越多厂商支持的集群服务暴露方式，在实际的生产环境中使用得最多，而其他的服务暴露方式更多地适用于服务调试、特殊应用部署等方面。

####  Ingress 和 Ingress Controller

在 kubernetes 集群中，Ingress 只是一个统称，具体而言由两部分组成：

- `Ingress`：Ingress 资源对象，使用 YAML 文件定义负载均衡的策略（规则）
- `Ingress Controller`：控制器，以插件形式存在于集群中，从 apiServer 中获取 Ingress 的规则变化

在集群中，需要先部署 Ingress Controller，再创建 Ingress 资源对象。Ingress Controller 控制器是一个 docker 容器，容器镜像中包含一个负载均衡器（比如：Nginx 或是 HAProxy）和一个 Ingress Controller。

整个底层的实现是这样的：Ingress Controller 从 kubernetes apiServer 中（实际上是监控 apiServer 的 /ingress 接口后端的 backend services）获取 Ingress 的配置信息，然后动态生成一个 Nginx 或 HAProxy 配置文件，重启负载均衡器进程使配置生效。所以，虽然 Ingress Controller 是以插件形式集成在环境中，但依然是由 kubernetes 管理的负载均衡器。

Ingress Controller 容器中的负载均衡器可以是各种主流的负载均衡软件，比如：Nginx、HAProxy、Traefik 等。不管具体的软件类型是什么，官方都统称为 Ingress Controller。

####  原理图

当集群使用 Ingress 进行负载分发时，Ingress Controller 基于 Ingress 规则将客户端请求直接转发到 Service 对应的后端 Endpoint(Pod) 上，所以会跳过 kube-proxy 的转发功能，kube-proxy 在这里并不会起作用。这种方式比 LoadBalancer 更加高效。

比如下面的例子：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191114-1573723470844/wm)

当客户端访问实验楼（www.shiyanlou.com）时：

- 访问 http://www.shiyanlou.com/courses 的请求会被路由到后端名为 courses 的 Service；
- 访问 http://www.shiyanlou.com/louplus 的请求会被路由到后端名为 louplus 的 Service；
- 访问 http://www.shiyanlou.com/vip 的请求会被路由到后端名为 vip 的 Service；

使用 Ingress 不仅可以实现对 HTTP 的路由，还可以实现基于 cookie 的会话亲和性、SSL 直通/终止等功能。

## 3. 部署 nginx-ingress-controller

我们的环境中还没有部署 ingress 插件，因此首先需要做的是在环境中将插件安装上。在 kubernetes 集群中，Ingress Controller 是以 Pod 形式运行的。根据负载均衡器的不同出现了多种 Ingress Controller，比如：

- [Kubernetes Ingress Controller](https://github.com/kubernetes/ingress-nginx): Kubernetes 官方推荐的控制器，由社区开发，最适合新手。
- [NGINX Ingress Controller](https://github.com/nginxinc/kubernetes-ingress): Nginx 公司开发的官方产品。有一个基于 NGINX Plus 的商业版。
- [Traefik](https://github.com/containous/traefik): 为部署微服务更加便捷而诞生的现代 HTTP 反向代理、负载均衡工具。支持多种后台来自动化、动态的应用它的配置文件。
- [HAProxy Ingress](https://github.com/jcmoraisjr/haproxy-ingress): 这也是在传统配置时应用非常广泛的负载均衡器。它提供了“软”配置更新（无流量损失）、基于 DNS 的服务发现和通过 API 进行动态配置。

本次实验中将会使用官方推荐的控制器 Kubernetes Ingress Controller，它的创建其实也比较简单，直接使用 YAML 文件创建即可。

需要下载 `nginx-ingress-controller.yaml` 文件和 `ingress-service-nodeport.yaml` 文件，这里已经提供了完整的 YAML 文件，大家执行下载即可：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1457/nginx-ingress-controller.yaml
wget https://labfile.oss.aliyuncs.com/courses/1457/ingress-service-nodeport.yaml
```

下载以后可以分别打开这两个文件查看具体的内容。

`nginx-ingress-controller.yaml` 文件中，创建了名为 `ingress-nginx` 的命名空间(没有使用 kube-system 系统默认空间)，并在该命名空间下分别创建了名为 nginx-configuration、tcp-services、udp-services 的 ConfigMap，创建了相关的服务账户、集群角色、集群角色绑定，最后使用 Deployment 部署一个名为 nginx-ingress-controller-xxx 的 Pod 副本，这个 Pod 就是 Ingress Controller。注意在 Deployment.spec.template.spec 中设置 `hostNetwork: true`，将 Pod 中所有容器的端口号都映射到 Node 节点上，因为是在本机进行测试，直接使用 `NodePort:containerPort` 就可以直接访问该控制器。同时由于国外的镜像无法下载，这里使用阿里云提供的镜像 `registry.aliyuncs.com/google_containers/nginx-ingress-controller:0.26.1`，这个容器有两个端口：`80` 端口提供 `http` 访问，`443` 端口提供 `https` 访问。

`nginx-ingress-controller:0.26.1` 镜像实现 Ingress Controller 的基本逻辑为：监听 APIServer，获取在 Ingress 中定义的配置信息；基于 Ingress 配置信息，生成 Nginx 所需的配置文件 /etc/nginx/nginx.conf；执行 `nginx -s reload` 命令重新加载配置文件内容。

`ingress-service-nodeport.yaml` 文件中，为 Ingress Controller Pod 创建 NodePort 类型的 Service，接收集群外部的流量。

先创建 nginx-ingress-controller Pod：

```bash
$ kubectl create -f nginx-ingress-controller.yaml
namespace/ingress-nginx created
configmap/nginx-configuration created
configmap/tcp-services created
configmap/udp-services created
serviceaccount/nginx-ingress-serviceaccount created
clusterrole.rbac.authorization.k8s.io/nginx-ingress-clusterrole created
role.rbac.authorization.k8s.io/nginx-ingress-role created
rolebinding.rbac.authorization.k8s.io/nginx-ingress-role-nisa-binding created
clusterrolebinding.rbac.authorization.k8s.io/nginx-ingress-clusterrole-nisa-binding created
deployment.apps/nginx-ingress-controller created
```

然后为 nginx-ingress-controller Pod 创建 NodePort 类型的 Service：

```bash
$ kubectl create -f ingress-service-nodeport.yaml
service/ingress-nginx created
```

查看 ingress-nginx 命令空间下所有创建好的资源对象：

```bash
$ kubectl get all -o wide -n ingress-nginx
NAME                                            READY   STATUS    RESTARTS   AGE   IP           NODE          NOMINATED NODE   READINESS GATES
pod/nginx-ingress-controller-6c7b8c7775-c66rv   1/1     Running   0          19m   10.192.0.3   kube-node-1   <none>           <none>


NAME                    TYPE       CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE   SELECTOR
service/ingress-nginx   NodePort   10.106.187.230   <none>        80:31990/TCP,443:31480/TCP   17m   app.kubernetes.io/name=ingress-nginx,app.kubernetes.io/part-of=ingress-nginx


NAME                                       READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS                 IMAGES                                                                    SELECTOR
deployment.apps/nginx-ingress-controller   1/1     1            1           19m   nginx-ingress-controller   registry.aliyuncs.com/google_containers/nginx-ingress-controller:0.26.1   app.kubernetes.io/name=ingress-nginx,app.kubernetes.io/part-of=ingress-nginx

NAME                                                  DESIRED   CURRENT   READY   AGE   CONTAINERS                 IMAGES                                                                    SELECTOR
replicaset.apps/nginx-ingress-controller-6c7b8c7775   1         1         1       19m   nginx-ingress-controller   registry.aliyuncs.com/google_containers/nginx-ingress-controller:0.26.1   app.kubernetes.io/name=ingress-nginx,app.kubernetes.io/part-of=ingress-nginx,pod-template-hash=6c7b8c7775
```

## 4. 部署一个简单的 Nginx 实例

接下来我们部署一个 Nginx 服务，通过 Ingress 对外暴露 Nginx Service 进行访问，方便大家熟悉 Ingress 的使用流程。

首先使用 Deployment 创建 2 个 Nginx Pod 副本，指定容器端口为 80 端口；然后创建 Nginx Cluster Service，服务端口依然为 80 端口。在 `/home/shiyanlou` 目录下新建 `nginx.yaml` 文件并向其中写入如下代码：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
spec:
  selector:
    matchLabels:
      app: nginx
  replicas: 2
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.7.9
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: nginx
spec:
  selector:
    app: nginx
  ports:
    - port: 80
      targetPort: 80
```

执行创建：

```bash
$ kubectl create -f nginx.yaml
deployment.apps/nginx-deployment created
service/nginx created
```

设置 ingress 策略，将服务的域名命名为 `nginx.kube.com`，将客户端对于根路径的访问转发给后端的 nginx Service 进行响应。在 `/home/shiyanlou` 目录下新建 `ingress.yaml` 文件，并向其中写入如下代码：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-nginx
spec:
  rules:
  - host: nginx.kube.com # 对外访问的域名为 nginx.kube.com
    http:
      paths:
      - path: / # 转发路径为根路径 /
        backend:
          serviceName: nginx # 对外暴露 Service 的名称为 nginx
          servicePort: 80 # nginx Service 的 ClusterPort 为 80
```

当外部客户端访问地址 `http://nginx.kube.com` 时，kubernetes 集群内部会将这个访问请求转发给地址 `nginx:80`。需要注意的是：创建的 Ingress 必须和提供服务的 Service 处于同一命名空间下。

执行创建：

```bash
$ kubectl create -f ingress.yaml
ingress.extensions/ingress-nginx created
```

查看创建的 ingress：

```bash
$ kubectl get ingress
NAME            HOSTS            ADDRESS          PORTS   AGE
ingress-nginx   nginx.kube.com   10.106.187.230   80      3m56s
# 验证 ingress-nginx CLUSTER-IP  
$ kubectl get service -n ingress-nginx
NAME            TYPE       CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE
ingress-nginx   NodePort   10.106.187.230   <none>        80:31990/TCP,443:31480/TCP   98m
```

可以看到这里的 ADDRESS 为 10.106.187.230，也就是 ingress-nginx Service 的 ClusterIP。这说明 Nginx 设置好了后端服务的 Endpoint，Ingress Controller 中的转发规则已经配置好。如果 ADDRESS 中没有地址，则表示没有配置好。

登录 nginx-ingress-controller Pod，查看 /etc/nginx/nginx.conf 文件是否正确配置转发规则：

```bash
$ kubectl exec -n ingress-nginx -it nginx-ingress-controller-6c7b8c7775-c66rv -- /bin/sh
$ cat nginx.conf
...
	## start server nginx.kube.com
	server {
		server_name nginx.kube.com ;
		
		listen 80  ;
		listen 443  ssl http2 ;
		
		set $proxy_upstream_name "-";
		
		ssl_certificate_by_lua_block {
			certificate.call()
		}
		
		location / {
			
			set $namespace      "default";
			set $ingress_name   "ingress-nginx";
			set $service_name   "nginx";
			set $service_port   "80";
			set $location_path  "/";
...
```

在客户端配置静态解析，公网 IP 是 Ingress Controll Service 的公网 IP（在这里即 NodeIp），域名是 ingress 的 host（在这里即 nginx.kube.com）。

执行命令 `sudo vim /etc/hosts`，并向其中添加如下代码：

```text
# 可以查看 nginx-ingress-controller Pod 所在的 Node 名称，只配置该 Node 的地址
10.192.0.3  nginx.kube.com

# 如果配置了多个 nginx-ingress-controller Pod，可以将所有 Node 的地址都配置上
10.192.0.3  nginx.kube.com
10.192.0.4  nginx.kube.com
```

```bash
$ ping nginx.kube.com
PING nginx.kube.com (10.192.0.3) 56(84) bytes of data.
64 bytes from nginx.kube.com (10.192.0.3): icmp_seq=1 ttl=64 time=0.079 ms
64 bytes from nginx.kube.com (10.192.0.3): icmp_seq=2 ttl=64 time=0.049 ms
64 bytes from nginx.kube.com (10.192.0.3): icmp_seq=3 ttl=64 time=0.076 ms
^C
--- nginx.kube.com ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 1998ms
rtt min/avg/max/mdev = 0.049/0.068/0.079/0.013 ms

$ curl nginx.kube.com
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
    body {
        width: 35em;
        margin: 0 auto;
        font-family: Tahoma, Verdana, Arial, sans-serif;
    }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>
```

使用浏览器访问 `nginx.kube.com`，看到 nginx 首页：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191118-1574072547168/wm)

在上面的过程中，我们成功通过 Ingress Controller 访问到了后端服务中的 Pod。这里再强调一下，Ingress Controller 从与后端 Service 关联的 Endpoint 对象查看 Pod IP，然后 Ingress Controller 会直接将请求转发给任一的 Pod（即 Ingress Controller 不会将请求转发给 Service，只是通过 Service 获取符合要求的 Pod 的 IP 地址）。

## 5. 不同的 Ingress 策略配置类型

对于后端服务的访问规则全部都需要在 Ingress 中进行配置。常用的如下几种：

- 不使用域名，转发到单个后端服务
- 不使用域名，不同的 URL 路径被转发到不同的服务
- 同一域名，不同的 URL 路径被转发到不同的服务
- 不同的域名，转发到不同的服务

####  不使用域名，转发到单个后端服务

这种配置适用的场景是：网站不使用域名，直接通过运行 Ingress Controller 的 Node IP 地址访问后端服务。

Ingress Controller 将来自客户端的请求全部转发到后端的单一服务上，比如把对 Ingress Controller 全部的请求都转发到 `nginx:80` 服务上：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-nginx
spec:
  serviceName: nginx # 对外暴露 Service 的名称为 nginx
  servicePort: 80 # nginx Service 的 ClusterPort 为 80
```

需要注意的是，使用无域名的 Ingress 转发规则会默认禁用非安全 HTTP，强制使用 HTTPS 访问。

####  不使用域名，不同的 URL 路径被转发到不同的服务

即使不使用域名，也可以配置对于不同 URL 路径的访问请求转发到不同的服务上。

比如对 `<NodeIP>/courses` 的请求转发到 `courses:8080` 服务上；对 `<NodeIP>/louplus` 的请求转发到 `louplus:8081` 服务上：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-shiyanlou
spec:
  rules:
  - http:
      paths:
      - path: /courses
        backend:
          serviceName: courses
          servicePort: 8080
      - path: /louplus
        backend:
          serviceName: louplus
          servicePort: 8081
```

####  同一域名，不同的 URL 路径被转发到不同的服务

不过通常情况下，还是推荐使用域名的，这样更加方便外部客户端的访问。使用域名访问网站，通过不同的路径提供不同的服务。

比如对 `http://www.shiyanlou.com/courses` 的请求转发到后端 `courses:8080` 服务上；对 `http://www.shiyanlou.com/vip` 的请求转发到后端 `vip:2000` 服务上：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-shiyanlou
spec:
  rules:
  - host: www.shiyanlou.com
    http:
      paths:
      - path: /courses
        backend:
          serviceName: courses
          servicePort: 8080
      - path: /vip
        backend:
          serviceName: vip
          servicePort: 2000
```

####  不同的域名，转发到不同的服务

同样也可以配置通过不同的域名提供不同的服务。

比如对 `courses.shiyanlou.com` 的请求转发到后端 `courses:8080` 服务上；对 `vip.shiyanlou.com` 的请求转发到后端 `vip:2000` 的服务上：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-shiyanlou
spec:
  rules:
  - host: courses.shiyanlou.com
    http:
      paths:
      - backend:
          serviceName: courses
          servicePort: 8080
  - host: vip.shiyanlou.com
    http:
      paths:
      - backend:
          serviceName: vip
          servicePort: 2000
```

## 6. 配置 Ingress 处理 TLS 传输

上面讲解的是配置 Ingress 处理 HTTP 请求，而如果想要使用 HTTPS 访问，则需要配置 Ingress 支持 TLS。

比如在 kubernetes 集群中的 Pod 上运行的是 web 服务器，在集群内部通信使用的是 HTTP 协议。那么只需要 Ingress Controller 处理 HTTPS 连接的相关内容即可。

具体的操作步骤为：

- 创建自签名的密钥和 SSL 证书文件；
- 将证书保存到 kubernetes 中的 Secret 资源对象上；
- 将 Secret 对象添加到 Ingress 中。

使用 OpenSSL 工具生成密钥和证书文件：

```bash
# CN=nginx.kube.com 用于指定网站域名
$ openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout nginx-kube.key -out nginx-kube.crt -subj "/CN=nginx.kube.com"
Generating a 2048 bit RSA private key
.................................................................+++
......................+++
writing new private key to 'nginx-kube.key'
-----
```

可以看到在当前目录 /home/shiyanlou 下生成了两个文件，分别为 nginx-kube.key 和 nginx-kube.crt。

接下来使用命令 `kubectl create secret tls` 创建 Secret 资源对象：

```bash
$ kubectl create secret tls nginx-kube-secret --key nginx-kube.key --cert nginx-kube.crt
secret/nginx-kube-secret created
```

最后修改前面的 ingress.yaml 文件，将其修改为如下所示：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-nginx
spec:
  tls: # 在 tls 字段下进行配置
  - hosts:
    - nginx.kube.com # 域名
    secretName: nginx-kube-secret # 对应的 secret
  rules:
  - host: nginx.kube.com
    http:
      paths:
      - path: /
        backend:
          serviceName: nginx
          servicePort: 80
```

更新配置信息：

```bash
$ kubectl apply -f ingress.yaml
# 查看更新后的 ingress，可以看到开放了 443 端口
$ kubectl get ingress
NAME            HOSTS            ADDRESS         PORTS     AGE
ingress-nginx   nginx.kube.com   10.106.187.230  80, 443   51m
```

现在通过浏览器访问地址 `https://nginx.kube.com`，浏览器会提示不安全，点击 `Advanced` -> `Accept the Risk and Continue`，就可以看到 nginx 页面了。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191119-1574145302570/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191119-1574145314615/wm)

也可以通过 curl 访问：

```bash
$ curl -k -v https://nginx.kube.com
* Rebuilt URL to: https://nginx.kube.com/
*   Trying 10.192.0.3...
* Connected to nginx.kube.com (10.192.0.3) port 443 (#0)
...
* 	 subject: CN=nginx.kube.com
...
```

## 7. 实验总结

本次实验我们向大家介绍了如下知识点：

- Ingress 简介
- 部署 nginx-ingress-controller
- 部署一个简单的 Nginx 实例
- 不同的 Ingress 策略配置类型
- 配置 Ingress 处理 TLS 传输

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
