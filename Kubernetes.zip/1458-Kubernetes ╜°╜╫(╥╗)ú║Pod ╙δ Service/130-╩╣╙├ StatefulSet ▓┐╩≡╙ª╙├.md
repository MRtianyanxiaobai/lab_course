# 挑战：使用 StatefulSet 部署应用

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

本次挑战我们将会使用 StatefulSet 在两个 Node 节点上分别运行 MongoDB 应用。

具体要求如下：

- Headless Service 服务名为：`mongo`，对外开放 `port: 27017` 和 `targetPort: 27017`
- StatefulSet 名称为：`mongo`，其中 Pod 副本数量为 2，image 为：`mongo`，启动命令 command 为：`mongod`，容器对外开放端口 27017，容器中挂载存储卷的路径为：`/data/db`
- volumeClaimTemplates 名称为：`mongo-persistent-storage`，使用 local PV 挂载，要求最少使用 100Mi 的内存

## 目标

- 成功创建本地持久存储卷 PV 和持久存储卷声明 PVC
- 能够使用 StatefulSet 成功运行两个 Mongo Pod

## 提示语

- 关于“创建本地持久存储卷”和“将本地持久存储卷绑定到 Node 上”可以参考实验“StatefulSet”中的方法

## 知识点

- 创建本地持久存储卷
- 将本地持久存储卷绑定到 Node 上
- 创建 StatefulSet 运行 MongoDB 应用

## 参考答案

在 /home/shiyanlou 目录下新建 `local-storage.yaml` 文件，并向其中写入如下代码：

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: local-storage
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer
```

执行创建：

```bash
$ kubectl create -f local-storage.yaml
storageclass.storage.k8s.io/local-storage created
```

在 /home/shiyanlou 目录下新建 `local-pv.yaml` 文件，并向其中写入如下内容：

```yaml
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: local-pv1
spec:
  capacity:
    storage: 1Gi
  accessModes:
  - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: local-storage
  local:
    path: /tmp
  nodeAffinity:
    required:
      nodeSelectorTerms:
      - matchExpressions:
        - key: kubernetes.io/hostname
          operator: In
          values:
          - kube-node-1
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: local-pv2
spec:
  capacity:
    storage: 1Gi
  accessModes:
  - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: local-storage
  local:
    path: /tmp
  nodeAffinity:
    required:
      nodeSelectorTerms:
      - matchExpressions:
        - key: kubernetes.io/hostname
          operator: In
          values:
          - kube-node-2
```

执行创建：

```bash
$ kubectl create -f local-pv.yaml
persistentvolume/local-pv1 created
persistentvolume/local-pv2 created
```

在 /home/shiyanlou 目录下新建 `mongo.yaml` 文件，并向其中写入如下代码：

```yaml
apiVersion: v1
kind: Service
metadata:
  name: mongo
  labels:
    app: mongo
spec:
  ports:
  - port: 27017
    targetPort: 27017
    name: mongo
  clusterIP: None
  selector:
    app: mongo
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mongo
spec:
  serviceName: "mongo"
  replicas: 2
  selector:
    matchLabels:
      app: mongo
  template:
    metadata:
      labels:
        app: mongo
    spec:
      containers:
      - name: mongo
        image: mongo
        command:
        - mongod
        ports:
        - containerPort: 27017
        volumeMounts:
        - name: mongo-persistent-storage
          mountPath: /data/db
  volumeClaimTemplates:
  - metadata:
      name: mongo-persistent-storage
    spec:
      accessModes:
      - ReadWriteOnce
      storageClassName: local-storage
      resources:
        requests:
          storage: 100Mi
```

在执行创建之前可以监听 Pod 的创建过程，在一个新的终端执行如下命令：

```bash
kubectl get pods -w -l app=mongo
```

然后执行创建：

```bash
$ kubectl create -f mongo.yaml
service/mongo created
statefulset.apps/mongo created
```

查看创建过程：

```bash
$ kubectl get pods -w -l app=mongo
NAME      READY   STATUS              RESTARTS   AGE
mongo-0   0/1     Pending             0          0s
mongo-0   0/1     Pending             0          0s
mongo-0   0/1     ContainerCreating   0          18s
mongo-0   1/1     Running             0          35s
mongo-1   0/1     Pending             0          0s
mongo-1   0/1     Pending             0          1s
mongo-1   0/1     ContainerCreating   0          1s
mongo-1   1/1     Running             0          31s
```

查看创建成功的 Pod：

```bash
$ kubectl get pods -o wide
NAME      READY   STATUS    RESTARTS   AGE   IP           NODE          NOMINATED NODE   READINESS GATES
mongo-0   1/1     Running   0          69s   10.244.2.4   kube-node-1   <none>           <none>
mongo-1   1/1     Running   0          34s   10.244.3.3   kube-node-2   <none>           <none>
```

检查 PVC：

```bash
$ kubectl get pvc
NAME                               STATUS   VOLUME      CAPACITY   ACCESS MODES   STORAGECLASS    AGE
mongo-persistent-storage-mongo-0   Bound    local-pv1   1Gi        RWO            local-storage   3m2s
mongo-persistent-storage-mongo-1   Bound    local-pv2   1Gi        RWO            local-storage   2m27s
```
