---
show: step
version: 1.0
---

# 使用 Deployment 进行 Pod 升级与回滚

## 1.实验介绍

####  实验内容

本次实验我们将会介绍使用 Deployment 进行 Pod 的部署、升级与回滚。Deployment 为 Pod 和 ReplicaSet 提供了声明式定义方法，可以替代之前使用的 ReplicationController（RC）来管理应用。

####  实验知识点

- Deployment 简介
- Deployment 的升级
- Deployment 的回滚
- Deployment 的暂停与恢复

## 2. Deployment 简介

Deployment 资源对象为 Pod 和 ReplicaSet（ReplicationController 的升级版）提供了声明式定义，在 Deployment YAML 文件中描述期望达到的目标状态，Deployment Controller 会创建符合目标状态的 ReplicaSet 和 Pod，如果更新 Deployment，对应的 ReplicaSet 和 Pod 的状态也会改变以符合新的目标状态。

Deployment 的典型应用场景包括：

1. 定义 Deployment 来创建 ReplicaSet 和 Pod

使用 Deployment 来创建 ReplicaSet，ReplicaSet 又会在后台创建 Pod。可以检查 Pod 的启动状态，观察是成功还是失败。

也可以根据 Deployment 的状态判断上线是否 hang 住了。

2. 滚动升级和回滚应用

通过更新 Deployment 的 PodTemplateSpec 字段来声明 Pod 的新状态，更新 Deployment 后会创建一个新的 ReplicaSet，Deployment 会按照控制的速率删除由旧的 ReplicaSet 创建的 Pod、并使用新的 ReplicaSet 创建新的 Pod，当新生成的 Pod 达到要求的目标状态后，会清除旧的 ReplicaSet。

如果当前状态不稳定，可以回滚到之前的 Deployment revision，每次回滚都会更新 Deployment 的 revision。

3. 扩容和缩容

根据系统负载进行 Deployment 的扩容和缩容。

4. 暂停和继续 Deployment

暂停 Deployment 并修改 PodTemplateSpec 字段，然后重新恢复上线。

#### 运行示例

我们定义一个 Deployment YAML 文件，它可以创建一个 Replica Set 来启动 3 个 nginx Pod，在 `/home/shiyanlou` 目录下新建 `nginx-deployment.yaml` 文件，并向其中写入如下内容：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
spec:
  selector:
    matchLabels:
      app: nginx
  replicas: 3
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.7.9
        ports:
        - containerPort: 80
```

执行创建：

```bash
$ kubectl create -f nginx-deployment.yaml
deployment.apps/nginx-deployment created
```

查看 Deployment 的状态、RS 的状态、以及运行的 Pod 副本数量：

```bash
# 可以看到已经创建了 3 个符合要求的 Pod，这 3 个 Pod 都是最新的、都处于可用状态
$ kubectl get deployments
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
nginx-deployment   3/3     3            3           39s

# 该 RS 需要 3 个 Pod，当前符合要求的有 3 个 Pod 并且已经创建好，RS 名字的组成：<Deployment 的名字>-<Pod template 的 hash 值>
$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   3         3         3       6m18s

# 使用 nginx-deployment-5754944d6c RS 创建的 3 个 Pod
$ kubectl get pods
NAME                                READY   STATUS    RESTARTS   AGE
nginx-deployment-5754944d6c-gv8x8   1/1     Running   0          6m36s
nginx-deployment-5754944d6c-hsp99   1/1     Running   0          6m36s
nginx-deployment-5754944d6c-qqh42   1/1     Running   0          6m36s
```

查看 nginx-deployment 的详细信息：

```bash
$ kubectl describe deployment nginx-deployment
Name:                   nginx-deployment
Namespace:              default
CreationTimestamp:      Sun, 29 Sep 2019 11:12:45 +0800
Labels:                 <none>
# 在 Annotations 记录了版本 revision: 1
Annotations:            deployment.kubernetes.io/revision: 1
Selector:               app=nginx
Replicas:               3 desired | 3 updated | 3 total | 3 available | 0 unavailable
# 默认更新策略使用的是 RollingUpdate
StrategyType:           RollingUpdate
MinReadySeconds:        0
# max unavailable 和 max surge 的默认值都为 25%
RollingUpdateStrategy:  25% max unavailable, 25% max surge
Pod Template:
  Labels:  app=nginx
  Containers:
   nginx:
    Image:        nginx:1.7.9
    Port:         80/TCP
    Host Port:    0/TCP
    Environment:  <none>
    Mounts:       <none>
  Volumes:        <none>
Conditions:
  Type           Status  Reason
  ----           ------  ------
  Available      True    MinimumReplicasAvailable
  Progressing    True    NewReplicaSetAvailable
OldReplicaSets:  <none>
# ReplicaSet 为 nginx-deployment-5754944d6c
NewReplicaSet:   nginx-deployment-5754944d6c (3/3 replicas created)
Events:
  Type    Reason             Age   From                   Message
  ----    ------             ----  ----                   -------
  Normal  ScalingReplicaSet  14m   deployment-controller  Scaled up replica set nginx-deployment-5754944d6c to 3
```

## 3. Deployment 的升级

设想一个场景，我们的服务需要升级，传统的做法是：暂停与该服务相关的所有 Pod，下载新镜像并创建新的 Pod，这种方式不好的地方是升级的过程中，会导致服务不可用，进而影响整体的产品体验。因此 kubernetes 提供了滚动升级功能来解决这个问题。

通常使用 Deployment 来创建 Pod 资源对象，当 Pod 在运行中，可以修改 Deployment 的 Pod 定义或是镜像名称，并应用到 Deployment 对象上，这样就完成了 Deployment 的自动更新操作。在更新过程中发生了错误，可以通过回滚操作恢复 Pod 的版本。

这里我们将 Pod 的镜像更新为 `nginx:1.9.1`：

```bash
$ kubectl set image deployment/nginx-deployment nginx=nginx:1.9.1
deployment.extensions/nginx-deployment image updated

# 也可以使用 kubectl edit 命令进行更新，把 image 字段下的 nginx:1.7.9 更改为 nginx:1.9.1
$ kubectl edit deployment/nginx-deployment
deployment.extensions/nginx-deployment edited
```

上面我们修改了镜像名，就会触发系统完成 Deployment 所有运行 Pod 的滚动升级操作，查看 rollout 的状态：

```bash
$ kubectl rollout status deployment/nginx-deployment
deployment "nginx-deployment" successfully rolled out
```

需要注意的是：当且仅当 Deployment 的 `.spec.template` 字段下的 `labels` 或是 `image` 更新时才会触发 rollout，其它的更新并不会触发 rollout。

查看更新后的 Deployment、RS、Pods：

```bash
# 可以看到 UP-TO-DATE 的数量已经变成了 3，说明已经全部更新完成
$ kubectl get deployment
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
nginx-deployment   3/3     3            3           143m

# 查看两个 RS 的最终状态，可以看到旧的 RS 已经没有 Pod 在运行了，新的 RS 创建好了 3 个新的 Pod
$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   0         0         0       143m
nginx-deployment-7448597cd5   3         3         3       6m11s

# 由新 nginx-deployment-7448597cd5 RS 创建出来的 3 个 Pod
$ kubectl get pods
NAME                                READY   STATUS    RESTARTS   AGE
nginx-deployment-7448597cd5-7c9ms   1/1     Running   0          6m19s
nginx-deployment-7448597cd5-h6k89   1/1     Running   0          5m58s
nginx-deployment-7448597cd5-m8dnk   1/1     Running   0          5m25s
```

查看现在 nginx-deployment 的详细信息：

```bash
$ kubectl describe deployments/nginx-deployment
...
Annotations:            deployment.kubernetes.io/revision: 2
...
    Image:        nginx:1.9.1
...
OldReplicaSets:  <none>
# ReplicaSet 更新为 nginx-deployment-7448597cd5
NewReplicaSet:   nginx-deployment-7448597cd5 (3/3 replicas created)
Events:
  Type    Reason             Age   From                   Message
  ----    ------             ----  ----                   -------
  Normal  ScalingReplicaSet  14m   deployment-controller  Scaled up replica set nginx-deployment-7448597cd5 to 1
  Normal  ScalingReplicaSet  14m   deployment-controller  Scaled down replica set nginx-deployment-5754944d6c to 2
  Normal  ScalingReplicaSet  14m   deployment-controller  Scaled up replica set nginx-deployment-7448597cd5 to 2
  Normal  ScalingReplicaSet  13m   deployment-controller  Scaled down replica set nginx-deployment-5754944d6c to 1
  Normal  ScalingReplicaSet  13m   deployment-controller  Scaled up replica set nginx-deployment-7448597cd5 to 3
  Normal  ScalingReplicaSet  13m   deployment-controller  Scaled down replica set nginx-deployment-5754944d6c to 0
```

从 `Events` 事件中我们可以看到 Pod 的更新过程：

- 系统创建了一个新的 RS（nginx-deployment-7448597cd5），将其副本数量扩展到 1；将旧的 RS（nginx-deployment-5754944d6c）副本数量缩减为 2
- 新的 RS 副本数量扩展到了 2，旧的 RS 副本数量缩减为 1
- 新的 RS 副本数量扩展到了 3，旧的 RS 副本数量缩减为 0

就是通过这样逐步替换的过程完成了整个 Pod 的更新，这个过程中保证了整体服务不中断，并且副本数量始终维持为用户指定的数量。

Deployment 通过字段 `spec.strategy` 设置 Pod 更新策略，我们上面创建的 Deployment 的相关默认设置如下：

```yaml
spec:
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
```

Deployment 的更新策略有两种：

- `Recreat`（重建）: 先 kill 掉所有正在运行的 Pod，然后创建新的 Pod。
- `RollingUpdate`（滚动更新）: 逐个更新 Pod。可以在字段 `spec.strategy.rollingUpdate` 下设置两个参数 `maxSurge` 和 `maxUnavailable` 来控制滚动更新的过程。

关于两个参数的详细说明：

- `maxUnavailable`：指定更新过程中不可用状态的 Pod 数量上限。默认值 25% 指的是：Pod 期望副本数的 25%，然后系统会以向下取整的方式计算出绝对值（整数）。对于这里而言，当开始滚动更新时，旧的 RS 立即将副本数缩小到所需副本总数的 75%（3 * 75% = 2.25，然后向下取整，绝对值为 2），一旦新的 Pod 创建并准备好，旧的 RS 会进一步缩容，新的 RS 会进一步扩容，整个过程中系统在任意时刻都可以确保可用状态的 Pod 总数至少占 Pod 期望副本总数的 75%。
- `maxSurge`：指定更新过程中 Pod 总数超过 Pod 期望副本数部分的最大值。默认值 25% 指的是：Pod 期望副本数的 25%，然后系统会以向上取整的方式计算出绝对值（整数）。对于这里而言，新的 RS 可以在滚动更新开始时立即进行副本数扩容，只要保证新旧 RS 的 Pod 副本总数之和不超过期望副本数的 125% 即可。一旦旧的 Pod 被 kill 掉，新的 RS 会进一步扩容。在整个过程中系统在任意时刻都能确保新旧 RS 的 Pod 副本总数之和不超过所需副本数的 125%。

###  多重更新（Rollover）

“多重更新”也就是多个滚动更新（Rollout）同时进行。

每当 Deployment Controller 检测到有新的 Deployment 创建时，如果没有已存在的 ReplicaSet 来创建期望个数的 Pod，Deployment Controller 就会创建一个新的 ReplicaSet 来执行改变，已存在的 ReplicaSet 控制 label 匹配字段 `spec.selector` 但是 template 不匹配字段 `spec.template` 的 Pod 进行缩容，然后新的 ReplicaSet 将会扩容出匹配字段 `spec.replicas` 指定数目的 Pod，旧的 ReplicaSet 将会缩容到 0。

举个例子：比如创建了一个有 5 个 `nginx:1.7.9` replica 的 Deployment，当刚刚创建到 3 个 `nginx:1.7.9` replica 时，开始更新 Deployment 将其镜像修改为 `nginx:1.9.1`。在这种情况下，Deployment 会立即 kill 掉已创建的 3 个 `nginx:1.7.9` 的 Pod，并开始创建 `nginx:1.9.1` 的 Pod，它不会等到所有 5 个 `nginx:1.7.9` 的 Pod 都创建完成后才开始执行滚动更新。

###  更新 Deployment 的标签选择器（Label Selector）

通常情况下不建议更新 Deployment 的标签选择器，因为这样会导致 Deployment 选择的 Pod 列表发生变化，可能与其他控制器发生冲突。

1. 添加标签选择器

在添加标签选择器时，注意要同步修改 Deployment 配置的 Pod 标签，为 Pod 添加新的标签。

这里有点不同的是，添加标签选择器无法向后兼容，新的标签选择器不会匹配和使用旧选择器创建的 ReplicaSets 和 Pod，因此添加新的选择器会导致所有旧版本的 ReplicaSets 和由旧 ReplicaSets 创建的 Pod 处于孤立状态，即：不会被系统自动删除，也不受新的 ReplicaSet 控制。

向字段 `spec.selector.matchLabels` 和字段 `spec.template.matedata.labels` 同时添加标签 `k8s: nginx-pod`，使用如下命令进行修改：

```bash
$ kubectl edit deployment/nginx-deployment
deployment.extensions/nginx-deployment edited
```

查看更新后的 Deployment、RS、Pods：

```bash
# 可以看到更新完成
$ kubectl get deployment/nginx-deployment
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
nginx-deployment   3/3     3            3           3h58m

# 创建了新的 RS：
$ kubectl get rs nginx-deployment-8ff4cd577
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   0         0         0       3h58m
nginx-deployment-7448597cd5   3         3         3       101m
nginx-deployment-8ff4cd577    3         3         3       88s

# 使用新的 RS nginx-deployment-8ff4cd577 创建了 3 个 Pod，可以发现之前的 3 个 Pod 依然存在着，没有被删除
$ kubectl get pods
NAME                                READY   STATUS    RESTARTS   AGE
nginx-deployment-7448597cd5-7c9ms   1/1     Running   0          101m
nginx-deployment-7448597cd5-h6k89   1/1     Running   0          100m
nginx-deployment-7448597cd5-m8dnk   1/1     Running   0          100m
nginx-deployment-8ff4cd577-8gxw2    1/1     Running   0          95s
nginx-deployment-8ff4cd577-8plkw    1/1     Running   0          95s
nginx-deployment-8ff4cd577-g7bc2    1/1     Running   0          95s
```

2. 更新标签选择器

比如更新选择器中标签的键或值，这种做法产生的效果与添加新选择器标签类似。

3. 删除标签选择器

从 Deployment 的标签选择器中删除一个或多个标签，该 Deployment 的 ReplicaSet 和 Pod 不会受到任何影响，只是被删除的标签依然会存在与现有的 ReplicaSet 和 Pod 上。

## 4. Deployment 的回滚

有的时候由于升级后的 Deployment 不稳定，我们需要将 Deployment 回滚到旧的版本。默认情况下，kubernetes 会在系统中保存所有 Deployment 的 rollout 历史记录，方便随时回退。

这里需要注意的是，只有更新 Deployment template 中的 label 和 image，才会创建一个新的 revision，而扩缩容不会创建 revision，所以回退历史 revision 时，只有 Deployment 中的 template 部分才会回退。

比如我们先进行一次升级，要修改容器的镜像，但是不小心手误写成了 `nginx:1.91`，这是一个不存在的版本镜像，所以 Deployment 不会更新成功：

```bash
$ kubectl set image deployment/nginx-deployment nginx=nginx:1.91
deployment.extensions/nginx-deployment image updated
```

查看 Deployment 的部署过程以及 RS 的状态：

```bash
# 可以看到部署过程卡住了，按 Ctrl+C 终止查看
$ kubectl rollout status deployments nginx-deployment
Waiting for deployment "nginx-deployment" rollout to finish: 1 out of 3 new replicas have been updated...
^C

# 新创建的 nginx-deployment-5b4b548d5f RS 也卡在了第一个 Pod 的创建过程中，主要是镜像拉取不成功
$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   0         0         0       4h23m
nginx-deployment-5b4b548d5f   1         1         0       52s
nginx-deployment-7448597cd5   3         3         3       126m
nginx-deployment-8ff4cd577    3         3         3       26m
```

使用 `kubectl rollout history` 命令查看部署的历史记录，由于我们在创建 Deployment 的时候没有使用 `--record` 参数，CHANGE-CAUSE 中没有记录下更新每个版本使用的命令，大家在创建的时候可以把这个参数加上：

```bash
$ kubectl rollout history deployment/nginx-deployment
deployment.extensions/nginx-deployment
REVISION  CHANGE-CAUSE
1         <none>
2         <none>
```

使用 `--revision=<N>` 参数可以查看特定版本的详细信息：

```bash
$ kubectl rollout history deployment/nginx-deployment --revision=2
deployment.extensions/nginx-deployment with revision #2
Pod Template:
  Labels:	app=nginx
	k8s=nginx-pod
	pod-template-hash=5b4b548d5f
  Containers:
   nginx:
    Image:	nginx:1.91
    Port:	80/TCP
    Host Port:	0/TCP
    Environment:	<none>
    Mounts:	<none>
  Volumes:	<none>
```

撤销本次发布并回滚到上一个部署版本：

```bash
$ kubectl rollout undo deployment/nginx-deployment
deployment.extensions/nginx-deployment rolled back

# 也可以使用参数 --to-revision 指定回滚到的部署版本
$ kubectl rollout undo deployment/nginx-deployment --to-revision=1
```

现在检查 Deployment 是否回滚到了上一个版本：

```bash
$ kubectl describe deployment/nginx-deployment
...
Pod Template:
  Labels:  app=nginx
           k8s=nginx-pod
  Containers:
   nginx:
    Image:        nginx:1.9.1
...
NewReplicaSet:   nginx-deployment-8ff4cd577 (3/3 replicas created)
Events:
  Type    Reason             Age    From                   Message
  ----    ------             ----   ----                   -------
  Normal  ScalingReplicaSet  30m    deployment-controller  Scaled up replica set nginx-deployment-8ff4cd577 to 3
  Normal  ScalingReplicaSet  4m50s  deployment-controller  Scaled up replica set nginx-deployment-5b4b548d5f to 1
  Normal  ScalingReplicaSet  22s    deployment-controller  Scaled down replica set nginx-deployment-5b4b548d5f to 0
```

从 Events 事件中可以看到 Deployment 回滚的过程是：先创建一个新 RS（nginx-deployment-8ff4cd577）扩容到 3 个 Pod，然后旧的 RS（nginx-deployment-5b4b548d5f）的 Pod 从 1 缩减为 0。

## 5. Deployment 的暂停与恢复

有的时候我们需要频繁的对 Deployment 的配置进行修改，如果每修改一次就触发一次更新的话会显得比较麻烦，这个时候可以暂停 Deployment 的更新操作，多次修改配置，然后再恢复 Deployment，一次性触发完整的更新操作。

我们这里先删除掉前面创建的 nginx-deployment，然后重新使用文件进行创建（注意创建的时候可以加上 --record 参数）：

```bash
$ kubectl create -f nginx-deployment.yaml --record
deployment.apps/nginx-deployment created

$ kubectl get deployments
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
nginx-deployment   3/3     3            3           28s

$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   3         3         3       34s
```

使用命令 `kubectl rollout pause` 暂停 Deployment 的更新操作：

```bash
$ kubectl rollout pause deployment/nginx-deployment
deployment.extensions/nginx-deployment paused
```

修改 Deployment 的镜像信息为 nginx:1.9.1：

```bash
$ kubectl set image deployment/nginx-deployment nginx=nginx:1.9.1
deployment.extensions/nginx-deployment image updated
```

查看更新历史记录，可以看到并没有触发对应的更新操作：

```bash
$ kubectl rollout history deployment/nginx-deployment
deployment.extensions/nginx-deployment
REVISION  CHANGE-CAUSE
1         kubectl create --filename=nginx-deployment.yaml --record=true
```

这里我们再一次更新 Deployment 配置，限制容器的资源使用：

```bash
$ kubectl set resources deployment nginx-deployment -c=nginx --limits=cpu=200m,memory=512Mi
deployment.extensions/nginx-deployment resource requirements updated
```

恢复 Deployment 的部署操作：

```bash
$ kubectl rollout resume deploy nginx-deployment
deployment.extensions/nginx-deployment resumed
```

查看 RS 资源和 Deployment 的详细信息：

```bash
# 可以看到新创建的 RS（nginx-deployment-7576c67d77）
$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
nginx-deployment-5754944d6c   0         0         0       6m40s
nginx-deployment-7576c67d77   3         3         3       58s

# 观察 nginx-deployment 的配置信息是否修改
$ kubectl describe deployment/nginx-deployment
...
Annotations:            deployment.kubernetes.io/revision: 2
                        kubernetes.io/change-cause: kubectl create --filename=nginx-deployment.yaml --record=true
...
Pod Template:
  Labels:  app=nginx
  Containers:
   nginx:
    Image:      nginx:1.9.1 # 镜像已经更新
    Port:       80/TCP
    Host Port:  0/TCP
    Limits: # 容器资源的限制已经生效
      cpu:        200m
      memory:     512Mi
...
```

## 6. 实验总结

本次实验我们向大家介绍了如下知识点：

- Deployment 简介
- Deployment 的升级
- Deployment 的回滚
- Deployment 的暂停与恢复

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
