---
show: step
version: 1.0
---

# LoadBalancer Service 和 ExternalName Service

## 1.实验介绍

####  实验内容

本次实验我们将介绍 LoadBalancer Service 和 ExternalName Service。

`LoadBalancer Service` 是在 Node Service 的基础上继续扩展的，类似于 Node Service 在 Cluster Service 的基础上进行扩展。

`ExternalName Service` 适用于外部服务使用域名的方式，它的缺点是不能指定端口。

####  实验知识点

- LoadBalancer Service 简介
- 使用 nginx 软件手动实现负载均衡
- 由云服务商提供负载均衡器
- ExternalName Service 简介

####  推荐阅读

- [阿里云容器服务 kubernetes 版](https://www.alibabacloud.com/help/zh/doc-detail/86745.htm?spm=a2c63.p38356.b99.32.73527e23aix1Cf)
- [通过负载均衡（Server Load Balancer）访问服务](alibabacloud.com/help/zh/doc-detail/86531.htm)

## 2. LoadBalancer Service 简介

上一个实验介绍了 NodePort Service，我们知道了通过任意一个 `NodeIP:NodePort` 就可以访问集群服务，假如集群有多个 Node 节点，比如 10 个、20 个，如何分配对于这些节点的访问请求呢？这个时候最好是有一个负载均衡器，外部的客户端请求只需要访问负载均衡器的 IP 地址，然后由外部负载均衡器分配转发流量到后端 Node 的 NodePort 上，具体如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191112-1573542629563/wm)

## 3. LoadBalancer Service 实例

LoadBalancer 组件一般是独立于 kubernetes 集群之外的，大部分的时候是一个硬件的负载均衡器，也可以用软件方式实现，比如：HAProxy 或是 Nginx。对于每个服务都需要配置一个与之对应的 LoadBalancer 实例，这样会增加工作量和出错的概率。

###  使用 nginx 软件手动实现负载均衡

在 `/home/shiyanlou` 目录下新建 `tomcat-deployment.yaml`，并向其中写入如下内容：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tomcat
spec:
  selector:
    matchLabels:
      app: tomcat
  replicas: 2
  template:
    metadata:
      labels:
        app: tomcat
    spec:
      containers:
      - name: tomcat
        image: tomcat
        ports:
        - containerPort: 8080
```

执行创建：

```bash
$ kubectl create -f tomcat-deployment.yaml
deployment.apps/tomcat created
```

在 `/home/shiyanlou` 目录下新建 `tomcat-svc.yaml` 文件，并向其中写入如下内容：

```bash
apiVersion: v1
kind: Service
metadata:
  name: tomcat-svc
spec:
  type: NodePort
  ports:
  - port: 80 # 设置 ClusterIP 对应的端口为 80
    targetPort: 8080 # Pod 开放的端口为 8080
    nodePort: 30001 # 设置在 Node 上开放的端口为 30001
  selector:
    app: tomcat
```

执行创建：

```bash
$ kubectl create -f tomcat-svc.yaml
service/tomcat-svc created
# 创建 NodePort 类型的服务成功
$ kubectl get svc
NAME         TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)        AGE
tomcat-svc   NodePort    10.98.46.27   <none>        80:30001/TCP   22m
```

可以先试着访问一下：

```bash
$ curl 10.192.0.2:30001
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Apache Tomcat/8.5.47</title>
        <link href="favicon.ico" rel="icon" type="image/x-icon" />
        <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="tomcat.css" rel="stylesheet" type="text/css" />
    </head>
...
```

接下来我们安装并配置 nginx 作为负载均衡器进行模拟，帮助大家更好的理解。

环境中已经安装 nginx，查看版本信息：

```bash
$ nginx -v
nginx version: nginx/1.10.3 (Ubuntu)
```

编辑 nginx 配置文件，使用命令 `sudo vim /etc/nginx/nginx.conf`，向文件中添加如下内容：

```text
http {
...
    # 添加 k8s 集群所有可用的 nodeIP:nodePort
    upstream k8snode {
        server 10.192.0.2:30001;
        server 10.192.0.3:30001;
        server 10.192.0.4:30001;
    }

    # 设置虚拟主机
    server {
        # 监听 81 端口
        listen 81;
        location / {
            # 反向代理指令，将所有的请求都发送给 k8snode 机器组中的机器
            proxy_pass http://k8snode;
        }
    }

}
```

保存配置文件，检查配置文件是否有误：

```bash
$ sudo nginx -t
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

配置无误，使配置文件生效：

```bash
sudo nginx -s reload
```

现在直接通过桌面上的 firefox 浏览器访问地址 `http://localhost:81`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191112-1573552742788/wm)

可以看到已经能够成功访问页面了。

###  由云服务商提供负载均衡器

前面介绍的方式是通过 nginx 软件实现负载均衡，通常而言 kubernetes 集群都是部署在云上的，比如：谷歌云、阿里云等等，这些云服务商一般都可以自动提供负载均衡器，大家需要去查看相关的云服务平台的官方文档了解更加详细的使用方法。

我们实验环境中暂时不能很好的演示，下面的内容主要讲解配置方法，无法查看效果。但是主要的实现逻辑和上面的 nginx 是相同的。

在 `/home/shiyanlou` 目录下新建 `tomcat-svc-loadbalancer.yaml` 文件，并向其中写入如下内容：

```yaml
apiVersion: v1
kind: Service
metadata:
  name: tomcat-loadbalancer
spec:
  type: LoadBalancer # 注意：这里 type 设置为 LoadBalancer
  ports:
  - port: 80
    targetPort: 8080
  selector:
    app: tomcat
```

执行创建：

```bash
$ kubectl create -f tomcat-svc-loadbalancer.yaml
service/tomcat-loadbalancer created
# PORT(S) 这里，80 为集群内部服务的端口，30544 为 nodePort 端口（由集群随机选择）
$ kubectl get svc
NAME                  TYPE           CLUSTER-IP     EXTERNAL-IP   PORT(S)        AGE
kubernetes            ClusterIP      10.96.0.1      <none>        443/TCP        86d
tomcat-loadbalancer   LoadBalancer   10.109.126.5   <pending>     80:30544/TCP   8s
```

这里由于环境中我们采用的是 dind 方式搭建集群并且配置了防火墙，无法成功创建 EXTERNAL-IP（“EXTERNAL-IP”为 pending 状态，说明外部网络不通），大家可以在阿里云上自行搭建一个单节点的 kubernetes 服务，然后尝试这种方式。

创建服务以后，云服务商需要一段时间才能创建负载均衡器并将其 IP 地址写入服务对象。如果成功创建阿里云的负载均衡器，比如获取服务信息的时候显示 `EXTERNAL-IP` 为 `101.37.XX.XX`，可以在通过本地浏览器直接访问 `http://101.37.XX.XX`。

在国内通常使用阿里云比较多，可以参考 [通过负载均衡（Server Load Balancer）访问服务](https://help.aliyun.com/document_detail/86531.html)。

使用 LoadBalancer Service 的优点和缺点都来源于云服务商的负载均衡器，优点是使用负载均衡器以后可以只对外暴露公有云的 IP 地址即可；缺点是这样会有一定的成本，适合公司或是组织使用。

## 4. ExternalName Service 简介

`ExternalName Service` 是一种特殊类型的 Service，主要用于访问位于集群外部的服务。它没有选择器 Selector，也没有定义任何端口 Port 或是 Endpoints。它的作用是返回集群外服务的域名。

通过返回 `CNAME` 和它的值，可以将服务映射到 `externalName` 字段对应的内容（比如：www.shiyanlou.com）。使用这种类型的服务不会创建任何类型的代理。

在 `/home/shiyanlou` 目录下新建 `externalname-svc.yaml` 文件，并向其中写入如下代码：

```yaml
apiVersion: v1
kind: Service
metadata:
  name: en-svc
  namespace: default
spec:
  type: ExternalName  # type 类型需要选择 ExternalName
  externalName: www.shiyanlou.com  # externalName 中填写外部服务对应的域名
```

执行创建：

```bash
$ kubectl create -f externalname-svc.yaml
service/en-svc created
# 查看服务，可以看到 en-svc 服务没有集群IP，只有一个 EXTERNAL-IP，为：www.shiyanlou.com
$ kubectl get svc
NAME         TYPE           CLUSTER-IP   EXTERNAL-IP         PORT(S)   AGE
en-svc       ExternalName   <none>       www.shiyanlou.com   <none>    6s
```

在实验环境中通过 ping 查看 www.shiyanlou.com 对应的 IP 地址：

```bash
$ ping www.shiyanlou.com
PING www.shiyanlou.com (121.40.227.60) 56(84) bytes of data.
64 bytes from 121.40.227.60: icmp_seq=1 ttl=100 time=3.82 ms
64 bytes from 121.40.227.60: icmp_seq=2 ttl=100 time=3.77 ms
64 bytes from 121.40.227.60: icmp_seq=3 ttl=100 time=3.78 ms
```

`www.shiyanlou.com` 对应的 IP 地址为：`121.40.227.60`。

现在可以进入容器内部通过 DNS 查找 en-svc 服务对应的 IP 地址，这里单独运行一个使用 utils 镜像创建的 pod 执行命令（镜像中已经安装了 dnsutils）：

```bash
$ kubectl run --generator=run-pod/v1 --rm utils -it --image registry-vpc.cn-hangzhou.aliyuncs.com/chenshi-kubernetes/utils:latest bash
If you don't see a command prompt, try pressing enter.
root@utils:/# nslookup en-svc
Server:		10.96.0.10
Address:	10.96.0.10#53

en-svc.default.svc.cluster.local	canonical name = www.shiyanlou.com.
Name:	www.shiyanlou.com
Address: 121.40.227.60

root@utils:/#
```

通过这样的方式也就验证了，使用 ExternalName Service 可以使集群连接外部服务，在 `spec.externalName` 字段中定义外部服务的域名即可使用。

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- LoadBalancer Service 简介
- 使用 nginx 软件手动实现负载均衡
- 由云服务商提供负载均衡器
- ExternalName Service 简介

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
