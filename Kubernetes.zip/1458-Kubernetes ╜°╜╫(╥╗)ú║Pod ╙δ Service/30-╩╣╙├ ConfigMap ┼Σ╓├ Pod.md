# 挑战：使用 ConfigMap 配置 Pod

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

本次挑战我们将会运行一个 MySQL Pod，要求使用 ConfigMap 将一个配置文件挂载容器到 `/etc/mysql/mysql.conf.d` 目录下，以及使用环境变量的方式设置 MySQL 密码。

在 `/home/shiyanlou` 目录下新建 `mysqld.cnf` 文件，这个文件就是待挂载到容器目录下的配置文件，向文件中写入如下内容：

```bash
[client]
port = 3306
socket = /var/run/mysqld/mysqld.sock
[mysql]
no-auto-rehash
[mysqld]
user = mysql
port = 3306
socket = /var/run/mysqld/mysqld.sock
datadir = /var/lib/mysql
[mysqld_safe]
log-error= /var/log/mysql/mysql_oldboy.err
pid-file = /var/run/mysqld/mysqld.pid
```

使用该文件创建的 ConfigMap 名为 `mysql-config`。

使用名为 `myconfig` 的 ConfigMap 存储 MySQL 密码，配置信息为 `v1=shiyanlou`。

在 `/home/shiyanlou` 目录下新建 `mysql-d.yaml` 文件，该文件用于创建符合要求的 MySQL Pod，其中有一部分内容省略了，需要大家根据题目要求将其补充完整：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
spec:
  selector:
    matchLabels:
      app: mysql
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
      - image: mysql:5.7
        name: mysql
        ports:
        - containerPort: 3306
        ========== 待补充部分 ========
        要求：
        1. 将 mysqld.cnf 文件挂载到容器内部的 /etc/mysql/mysql.conf.d 目录下
        2. 使用环境变量设置 MySQL 密码
        ============================
```

由于 DIND 部署方式，需要配置环境，在终端执行如下命令：

```bash
sudo ln -s /etc/apparmor.d/usr.sbin.mysqld /etc/apparmor.d/disable/
sudo apparmor_parser -R /etc/apparmor.d/usr.sbin.mysqld
docker pull mysql:5.7
```

## 目标

- 成功创建 MySQL Pod
- 进入 MySQL Pod，执行命令 `mysql -uroot -pshiyanlou` 可以登录 MySQL 交互式界面
- 进入 MySQL Pod，执行命令 `cat /etc/mysql/mysql.conf.d/mysqld.cnf` 的输出与 `/home/shiyanlou/mysqld.cnf` 文件相同

## 提示语

- 从文件创建 ConfigMap，可以使用参数 `--from-file`
- 使用 key-value 键值对创建 ConfigMap，可以使用参数 `--from-literal`
- 在 Deployment YAML 文件，在 `env` 字段下配置环境变量

## 知识点

- 使用 ConfigMap 配置 Pod

## 参考答案

从文件创建名为 mysql-config 的 ConfigMap：

```bash
$ kubectl create configmap mysql-config --from-file=mysqld.cnf
configmap/mysql-config created
```

使用 key-value 键值对创建名为 myconfig 的 ConfigMap：

```bash
$ kubectl create configmap myconfig --from-literal=v1=shiyanlou
configmap/myconfig created
```

补充完整的 `mysql-d.yaml` 文件内容如下：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
spec:
  selector:
    matchLabels:
      app: mysql
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
      - image: mysql:5.7
        name: mysql
        ports:
        - containerPort: 3306
        env:
        - name: MYSQL_ROOT_PASSWORD
          valueFrom:
            configMapKeyRef:
              name: myconfig
              key: v1
        volumeMounts:
        - name: mysql
          mountPath: /etc/mysql/mysql.conf.d
      volumes:
      - name: mysql
        configMap:
          name: mysql-config
```

执行创建：

```bash
$ kubectl create -f mysql-d.yaml
deployment.apps/mysql created
```

验证文件是否挂载成功，以及 MySQL 密码是否能够使用：

```bash
$ kubectl get pods
mysql-6574f97df5-wc2vg   1/1     Running     0          52s

$ kubectl exec -it mysql-6574f97df5-wc2vg bash
root@mysql-6574f97df5-wc2vg:/# mysql -uroot -pshiyanlou
mysql: [Warning] Using a password on the command line interface can be insecure.
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.7.27 MySQL Community Server (GPL)

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> exit;
Bye
root@mysql-6574f97df5-wc2vg:~# cat /etc/mysql/mysql.conf.d/mysqld.cnf
[client]
port = 3306
socket = /var/run/mysqld/mysqld.sock
[mysql]
no-auto-rehash
[mysqld]
user = mysql
port = 3306
socket = /var/run/mysqld/mysqld.sock
datadir = /var/lib/mysql
[mysqld_safe]
log-error= /var/log/mysql/mysql_oldboy.err
pid-file = /var/run/mysqld/mysqld.pid
```

通过 Pod 的具体信息也可以查看 ConfigMap 的配置：

```bash
$ kubectl describe pod mysql-6574f97df5-wc2vg
......

    Environment:
      MYSQL_ROOT_PASSWORD:  <set to the key 'v1' of config map 'myconfig'>  Optional: false
    Mounts:
      /etc/mysql/mysql.conf.d from mysql (rw)

......
```

另外在这里介绍一下卷挂载的方式可以使用 ConfigMap 热更新，比如我们修改 mysql-config ConfigMap，在 [mysqld] 字段下添加一项配置 `server-id = 1`，等待一会儿进入容器查看就可以发现文件的配置也响应进行了更改（热更新需要的时间相对要长一点，可能在一到两分钟左右）：

```bash
$ kubectl edit configmap mysql-config
configmap/mysql-config edited

$ kubectl exec -it mysql-6574f97df5-wc2vg bash
root@mysql-6574f97df5-wc2vg:~# cat /etc/mysql/mysql.conf.d/mysqld.cnf
[client]
port = 3306
socket = /var/run/mysqld/mysqld.sock
[mysql]
no-auto-rehash
[mysqld]
user = mysql
port = 3306
socket = /var/run/mysqld/mysqld.sock
datadir = /var/lib/mysql
server-id = 1 # 完成了热更新，配置文件已经修改
[mysqld_safe]
log-error= /var/log/mysql/mysql_oldboy.err
pid-file = /var/run/mysqld/mysqld.pid
```
