# 挑战：使用 Deployment 升级 Pod

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

本次挑战我们将会使用 Deployment 来创建 3 个镜像名为 mysql:5.7 的 Pod，创建完成后，要求使用命令将 mysql:5.7 的镜像升级到 mysql:8.0。

## 目标

- 编写 YAML 文件使用 Deployment 创建符合要求的 Pod
- 把 Pod 的镜像从 mysql:5.7 升级到 mysql:8.0

## 提示语

对于采用 kubeadm-dind 部署方式而言，后面创建 Pod 运行 MySQL 会不成功，会有相关报错如下所示：`ERROR: mysqld failed whilmysqld: error while loading shared libraries: libpthread.so.0: cannot stat shared object: Permission denied`，主要原因是在 dind 环境中 MySQL 的权限问题，执行如下命令可以暂时在开发环境中解决这个问题：

```bash
sudo ln -s /etc/apparmor.d/usr.sbin.mysqld /etc/apparmor.d/disable/
sudo apparmor_parser -R /etc/apparmor.d/usr.sbin.mysqld
```

## 知识点

- 使用 Deployment 升级 Pod

## 参考答案

在 `/home/shiyanlou` 目录下新建 `mysql-deployment.yaml` 文件，并写入如下内容：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql-deployment
spec:
  selector:
    matchLabels:
      app: mysql
  replicas: 3
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
      - name: database
        image: mysql:5.7
        ports:
        - containerPort: 3306
        env:
        - name: MYSQL_ROOT_PASSWORD
          value: "123456"
```

执行创建：

```bash
$ kubectl create -f mysql-deployment.yaml --record
deployment.apps/mysql-deployment created
```

查看 Deployment、RS、Pods：

```bash
$ kubectl get deployment
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
mysql-deployment   3/3     3            3           9s

$ kubectl get rs
NAME                          DESIRED   CURRENT   READY   AGE
mysql-deployment-5897447f6c   3         3         3       14s

$ kubectl get pods
NAME                                READY   STATUS    RESTARTS   AGE
mysql-deployment-5897447f6c-26l49   1/1     Running   0          20s
mysql-deployment-5897447f6c-jllkd   1/1     Running   0          20s
mysql-deployment-5897447f6c-vh46l   1/1     Running   0          20s
```

执行升级，将 mysql:5.7 的镜像升级为 mysql:8.0 的镜像：

```bash
$ kubectl set image deployment/mysql-deployment database=mysql:8.0
deployment.extensions/mysql-deployment image updated
```
