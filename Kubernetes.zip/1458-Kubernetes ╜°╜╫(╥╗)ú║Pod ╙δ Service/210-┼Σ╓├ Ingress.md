# 挑战：配置 Ingress

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

在 kubernetes 集群中，默认提供了 web 界面即：kubernetes-dashboard。集群启动以后可以通过 `http://127.0.0.1:32768/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy` 地址访问界面。

本次挑战我们将实现通过域名 `https://dashboard.kube.com` 访问 dashboard。最终的效果如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191119-1574149148029/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191119-1574149160577/wm)

## 目标

- 实现通过域名 `https://dashboard.kube.com` 访问 dashboard
- 为 Ingress 配置 TLS

## 提示语

- Service、Secret 以及 Ingress 必须在同一个命名空间（namespace）下，在这里即 `kube-system` 命名空间
- 通过 `kubectl get svc -n kube-system` 查看 kubernetes-dashboard 服务监听的端口
- 访问 dashboard 需要配置为 HTTPS 访问，所以要创建自签名的密钥和 SSL 证书文件
- dashboard 在集群内部也是采用的 HTTPS 协议，所以在 Ingress 配置中需要定义 `metadata.annotations` 下的 `nginx.ingress.kubernetes.io/backend-protocol="HTTPS"`，可以参考 [backend-protocol](https://kubernetes.github.io/ingress-nginx/user-guide/nginx-configuration/annotations/#backend-protocol)

## 参考答案

查看 kubernetes-dashboard 的相关信息：

```bash
$ kubectl get all -n kube-system
NAME                                        READY   STATUS    RESTARTS   AGE
...
pod/kubernetes-dashboard-5ff478f859-kkvmf   1/1     Running   0          77m


NAME                           TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)                  AGE
...
service/kubernetes-dashboard   ClusterIP   10.96.231.6   <none>        443/TCP                  93d

NAME                                   READY   UP-TO-DATE   AVAILABLE   AGE
...
deployment.apps/kubernetes-dashboard   1/1     1            1           93d

NAME                                              DESIRED   CURRENT   READY   AGE
...
replicaset.apps/kubernetes-dashboard-5ff478f859   1         1         1       93d
```

可以看到 kubernetes-dashboard service 的端口号为 443。

首先生成自签名证书：

```bash
# 指定域名为 dashboard.kube.com
$ openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout kube-dashboard.key -out kube-dashboard.crt -subj "/CN=dashboard.kube.com"
Generating a 2048 bit RSA private key
..............................................+++
........................................+++
writing new private key to 'kube-dashboard.key'
-----
```

然后创建 Secret 资源对象：

```bash
$ kubectl create secret tls kube-dasboard-secret --key kube-dashboard.key --cert kube-dashboard.crt -n kube-system
secret/kube-dashboard-secret created
```

在 `/home/shiyanlou` 目录下新建 `kube-dashboard-ingress.yaml` 文件，并向其中写入如下内容：

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-kube-dashboard
  annotations:
    nginx.ingress.kubernetes.io/backend-protocol: "HTTPS" # Ingress Controller 将客户端的请求转发给 dashboard 服务时使用 HTTPS 协议，如果这里不指定默认为 HTTP 协议，这样的话会报错
spec:
  tls:
  - hosts:
    - dashboard.kube.com
    secretName: kube-dashboard-secret # HTTPS 证书 Secret
  rules:
  - host: dashboard.kube.com # 域名
    http:
      paths:
      - path: /
        backend:
          serviceName: kubernetes-dashboard # 服务名为 kubernetes-dashboard
          servicePort: 443 # 服务端口号为 443
```

执行创建：

```bash
$ kubectl create -f kube-dashboard-ingress.yaml -n kube-system
ingress.extensions/ingress-kube-dashboard created
$ kubectl get ingress -n kube-system
NAME                     HOSTS                ADDRESS         PORTS     AGE
ingress-kube-dashboard   dashboard.kube.com   10.96.174.174   80, 443   34s
```

在本机添加域名解析，执行命令 `sudo vim /etc/hosts` 并在文件末尾添加如下内容：

```text
10.192.0.2  dashboard.kube.com
10.192.0.3  dashboard.kube.com
10.192.0.4  dashboard.kube.com
```

最后就可以在浏览器访问地址 `https://dashboard.kube.com` 啦。
