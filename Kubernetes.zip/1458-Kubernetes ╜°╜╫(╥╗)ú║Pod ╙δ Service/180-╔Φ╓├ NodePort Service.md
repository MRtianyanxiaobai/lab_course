# 挑战：设置 NodePort Service

> 注意：由于挑战环境限制，无法验证挑战结果，大家只需按照要求完成挑战即可，无须提交挑战结果。

## 介绍

本次挑战要求使用 Deployment 创建 2 个 tomcat 副本，指定 tomcat 容器运行端口为 8080；然后创建一个 NodePort 类型的 Service，要求 ClusterIP 开放 80 端口、Pod 开放 8080 端口、每个 Node 上开放 30001 端口。最后在浏览器上通过 `10.192.0.2:30001`、`10.192.0.3:30001`、`10.192.0.4:30001` 中的任意一个地址都可以成功访问 tomcat 首页。

## 目标

- 通过 Deployment 成功运行 2 个 tomcat 副本
- 成功创建 NodePort Service
- 通过 nodeIP:nodePort 成功访问 tomcat 首页

## 提示语

- 在 Deployment 中通过 `spec.template.spec.containers.ports.containerPort` 可以指定容器端口
- 在 Service 中通过 `spec.ports` 字段可以分别设置各个需要指定的容器端口

## 知识点

- 使用 Deployment 创建 Pod 副本
- 设置 NodePort 类型的 Service

## 参考答案

在 `/home/shiyanlou` 目录下新建 `tomcat-deployment.yaml`，并向其中写入如下内容：

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tomcat
spec:
  selector:
    matchLabels:
      app: tomcat
  replicas: 2
  template:
    metadata:
      labels:
        app: tomcat
    spec:
      containers:
      - name: tomcat
        image: tomcat
        ports:
        - containerPort: 8080
```

执行创建：

```bash
$ kubectl create -f tomcat-deployment.yaml
deployment.apps/tomcat created
```

在 `/home/shiyanlou` 目录下新建 `tomcat-svc.yaml` 文件，并向其中写入如下内容：

```bash
apiVersion: v1
kind: Service
metadata:
  name: tomcat-svc
spec:
  type: NodePort
  ports:
  - port: 80 # 设置 ClusterIP 对应的端口为 80
    targetPort: 8080 # Pod 开放的端口为 8080
    nodePort: 30001 # 设置在 Node 上开放的端口为 30001
  selector:
    app: tomcat
```

执行创建：

```bash
$ kubectl create -f tomcat-svc.yaml
service/tomcat-svc created
# 创建 NodePort 类型的服务成功
$ kubectl get svc
NAME         TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)        AGE
tomcat-svc   NodePort    10.98.46.27   <none>        80:30001/TCP   22m
```

可以先试着访问一下：

```bash
$ curl 10.192.0.2:30001
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Apache Tomcat/8.5.47</title>
        <link href="favicon.ico" rel="icon" type="image/x-icon" />
        <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="tomcat.css" rel="stylesheet" type="text/css" />
    </head>
...
```
