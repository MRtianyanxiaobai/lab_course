---
show: step
version: 1.0
---

# Flannel 网络插件

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Flannel 网络插件。

Flannel 网络插件是 CoreOS 开发的一个项目，也可能是最直接、最受欢迎的 CNI 插件。它是容器网络编排系统最成熟的项目之一，主要用于更好地支持容器间和主机间的网络。大家在接触 CNI 网络的时候，通常都会使用 Flannel 网络插件进行入门。

####  实验知识点

- Flannel 简介
- 使用 Flannel 搭建集群环境

####  推荐阅读

- [flannel](https://github.com/coreos/flannel)
- [Kubernetes: Flannel networking](https://blog.laputa.io/kubernetes-flannel-networking-6a1cb1f8ec7c)
- [理解 Kubernetes 网络之 Flannel 网络](https://tonybai.com/2017/01/17/understanding-flannel-network-for-kubernetes/)

## 2. Flannel 简介

与其它的网络插件相比，Flannel 更容易安装和配置。通常它被打包为名为 `flanneld` 的二进制文件，并且默认集成在 kubernetes 集群部署工具中。Flannel 通过 API 直接使用集群中的 etcd 数据库，所以可以不需要提供专门的数据存储。

Flannel 主要的工作原理为：给每个 Node 上的 Docker 容器分配互相不冲突的 IP 地址，在这些 IP 地址之间建立一个覆盖网络（Overlay Network），通过覆盖网络直接将数据包传递到目标容器中。

Flannel 的工作原理图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191218-1576661395265/wm)

从图中可以看到，在每个 Node 节点上都运行着一个 `flanneld` 进程，这个进程会创建名为 `flannel.1` 的网桥，这个网桥一边连接着 docker0 网络接口，另一边连接着 Node 节点上的 eth0 网络接口。

`flanneld` 进程也需要与集群中的 etcd 数据库连接，通过 etcd 管理可分配的 IP 地址段资源（这样就实现不同 Node 上的 Pod 分配的 IP 地址不冲突），监控 etcd 中每个 Pod 的实际地址，并在内存中建立 Pod 节点路由表（Routing Table），将 docker0 的数据包包装起来，通过物理网络的连接将数据包投递到目标 `flanneld`，这样就完成了 Pod 之间的通信。

Flannel 底层通信协议的可选技术包括：UDP、VxLan、AWS VPC 等，默认采用的是 UDP 传输协议，由于 UDP 协议本身是非可靠协议，如果需要应用到大流量、高并发的场景下，就还需要多次测试确保没有问题。

## 3. 使用 Flannel 搭建集群环境

由于对环境要求比较特殊，需要使用的环境为使用 Kubeadm 在阿里云 ECS 服务器上安装 Kubernetes 集群，然后在这个集群中进行操作。

在阿里云 ECS 上开启 3 个按量付费的实例，我这里创建的 3 个实例的名称、公网 IP、以及私有 IP 分别如下所示（大家新建的公网 IP 和私有 IP 会不相同的）：

```text
节点名          公网IP          私有IP
kube-master    47.96.104.38   172.16.98.157
kube-node-1    47.110.255.232 172.16.98.158
kube-node-2    47.97.170.26   172.16.98.159
```

前面的操作与实验《Calico 网络插件》“使用 Calico 搭建集群环境”相同，这里不再重复。

在 kube-master 节点上使用 `kubeadm init` 进行初始化的时候需要指定 pod 网段为 Flannel 网络插件的默认网段：

```bash
$ kubeadm init --image-repository registry.aliyuncs.com/google_containers --pod-network-cidr=10.244.0.0/16
...
Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 172.16.98.157:6443 --token tft0hq.sc9atdcoguh6ar3b \
    --discovery-token-ca-cert-hash sha256:a9ca5cdb822725a51143b98b2870da2d4dda65309da3d7087914997b9adae41d
```

这里的网段可以通过 [kube-flannel.yml](https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml) 文件中的相关定义找到：

```yaml
  net-conf.json: |
    {
      "Network": "10.244.0.0/16",
      "Backend": {
        "Type": "vxlan"
      }
    }
```

安装 Flannel 网络插件：

```bash
$ kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
podsecuritypolicy.policy/psp.flannel.unprivileged created
clusterrole.rbac.authorization.k8s.io/flannel created
clusterrolebinding.rbac.authorization.k8s.io/flannel created
serviceaccount/flannel created
configmap/kube-flannel-cfg created
daemonset.apps/kube-flannel-ds-amd64 created
daemonset.apps/kube-flannel-ds-arm64 created
daemonset.apps/kube-flannel-ds-arm created
daemonset.apps/kube-flannel-ds-ppc64le created
daemonset.apps/kube-flannel-ds-s390x created
```

然后在 kube-node-1 和 kube-node-2 节点上执行前面的 `kubeadm join` 命令加入集群。

最后在 kube-master 节点上查看节点状态如下：

```bash
$ kubectl get nodes
NAME          STATUS   ROLES    AGE   VERSION
kube-master   Ready    master   10m   v1.17.0
kube-node-1   Ready    <none>   78s   v1.17.0
kube-node-2   Ready    <none>   77s   v1.17.0
```

查看在 kube-system 命名空间下的所有 Pod：

```bash
$ kubectl get pods -n kube-system -o wide
NAME                                  READY   STATUS    RESTARTS   AGE     IP              NODE          NOMINATED NODE   READINESS GATES
coredns-9d85f5447-27dp6               1/1     Running   0          12m     10.244.0.2      kube-master   <none>           <none>
coredns-9d85f5447-ckpt4               1/1     Running   0          12m     10.244.0.3      kube-master   <none>           <none>
etcd-kube-master                      1/1     Running   0          12m     172.16.98.157   kube-master   <none>           <none>
...
kube-flannel-ds-amd64-46vs5           1/1     Running   0          3m30s   172.16.98.159   kube-node-2   <none>           <none>
kube-flannel-ds-amd64-s4tvx           1/1     Running   0          6m48s   172.16.98.157   kube-master   <none>           <none>
kube-flannel-ds-amd64-v4sm5           1/1     Running   0          3m31s   172.16.98.158   kube-node-1   <none>           <none>
...
```

可以看到 `kube-flannel-ds-amd64-xxxxx` Pod 分别运行在三个 Node 节点上。

现在分别查看 3 个节点的 IP 地址：

```bash
root@kube-master:~# ip addr
...
4: flannel.1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UNKNOWN group default
    link/ether 0e:ce:47:64:dd:88 brd ff:ff:ff:ff:ff:ff
    inet 10.244.0.0/32 scope global flannel.1
       valid_lft forever preferred_lft forever
```

```bash
root@kube-node-1:~# ip addr
...
4: flannel.1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UNKNOWN group default
    link/ether c6:e1:c3:4b:d0:6e brd ff:ff:ff:ff:ff:ff
    inet 10.244.1.0/32 scope global flannel.1
       valid_lft forever preferred_lft forever
```

```bash
root@kube-node-2:~# ip addr
...
4: flannel.1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UNKNOWN group default
    link/ether 3e:a1:4a:98:17:e9 brd ff:ff:ff:ff:ff:ff
    inet 10.244.2.0/32 scope global flannel.1
       valid_lft forever preferred_lft forever
```

可以看到 flannel 网桥的 IP 地址段在 10.244.0.0/16 范围内。

## 4. 实验总结

本次实验我们向大家介绍了如下知识点：

- Flannel 简介
- 使用 Flannel 搭建集群环境

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
