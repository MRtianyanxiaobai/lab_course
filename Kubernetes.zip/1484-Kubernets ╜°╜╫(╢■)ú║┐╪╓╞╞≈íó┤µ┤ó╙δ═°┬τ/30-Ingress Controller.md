---
show: step
version: 1.0
---

# Ingress Controller

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Ingress Controller。集群中必须要有 Ingress Controller，配置的 Ingrss 资源对象才能够生效。前面介绍的其它控制器都是作为 `kube-controller-manager` 二进制文件的一部分运行（即：集群启动这些控制器就自动运行了），Ingress Controller 是作为插件集成在 Kubernetes 集群中，大家可以选择部署最适合自己集群的 Ingress Controller。

####  实验知识点

- Ingress Controller 简介
- NGINX Ingress Controller
- Kong Ingress
- Traefik
- Istio Ingress

####  推荐阅读

- [Comparing Ingress controllers for Kubernetes](https://medium.com/flant-com/comparing-ingress-controllers-for-kubernetes-9b397483b46b)
- [Differences Between nginxinc/kubernetes-ingress and kubernetes/ingress-nginx Ingress Controllers](https://github.com/nginxinc/kubernetes-ingress/blob/master/docs/nginx-ingress-controllers.md)

## 2. Ingress Controller 简介

在前面介绍 Service 时讲解过，Ingress 可以为集群提供外部客户端的 HTTP/HTTPS 访问功能，它需要 IngressController 搭配 Ingress 资源对象共同实现。

现在 Ingress 控制器有多种方案可以实现，下面简单的列出来供大家参考：

- [Kubernetes Ingress Controller](https://github.com/kubernetes/ingress-nginx)：官方推荐的控制器，成熟、易于使用、可以满足大多数情况。
- [HAProxy Ingress](github.com/jcmoraisjr/haproxy-ingress)：提供“软”配置更新、基于 DNS 的服务发现和通过 API 进行动态配置，还支持完全自定义配置文件模板。
- [Ambassador](github.com/datawire/ambassador)：是 kubernetes 原生 API 微服务网关，可以与其他服务网（比如 Istio）一起使用。
- [Voyager](github.com/appscode/voyager)：是一个通用的解决方案，核心优势是在 4 层和 7 层上的流量负载均衡。
- [Contour](github.com/heptio/contour)：可以通过 CRD 管理 Ingress 资源，并提供了一组扩展的负载均衡算法。
...

由于篇幅限制，以上列出的控制器在这里都不会详细介绍，如果大家有兴趣的话可以自行探索。在本实验中会介绍：

- NGINX Ingress Controller
- Kong Ingress
- Traefik
- Istio Ingress

相信在学习了上述 4 种控制器后，大家也可以按照同样的方式了解其它的装饰器。

## 3. NGINX Ingress Controller

[NGINX Ingress Controller](https://github.com/nginxinc/kubernetes-ingress) 是采用 Go 语言实现的一款 Controller 插件，它是由 Nginx 公司开发的产品 [NGINX Ingress Controller for Kubernetes](https://www.nginx.com/products/nginx/kubernetes-ingress-controller/)，分别有两个版本：NGINX 社区版和 NGINX Plus 商业版。

NGINX Ingress Controller 具有高稳定性、持续向后兼容性、且没有第三方模块。社区版与官方的 Kubernetes Ingress Controller 相比较而言保证了更快的响应速度，如果大家想要了解更多的区别可以参考文档 [Differences Between nginxinc/kubernetes-ingress and kubernetes/ingress-nginx Ingress Controllers](https://github.com/nginxinc/kubernetes-ingress/blob/master/docs/nginx-ingress-controllers.md)。而 NGINX Plus 商业版相比于免费版本而言实现了更多的附加功能，比如：实时监控、主动健康检查、Session 保持等。

总体而言，NGINX Ingress 主要的优势在于对 TCP/UDP 流量的全面支持，但是缺乏流量的分配功能。如果项目对于服务的可靠性和功能实现有较高要求的话，可以选择 NGINX Plus 商业版。

下面介绍免费版的安装方式。由于需要部署多个 YAML 文件，所以在环境中将所需的文件全部打包为 zip 压缩包，大家使用命令执行下载即可，如果想要安装最新版，可以参考 [Installing the Ingress Controller](https://github.com/nginxinc/kubernetes-ingress/blob/master/docs/installation.md)。

首先下载所需的文件：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1457/nginx-ingress-controller.zip
unzip nginx-ingress-controller.zip
```

解压缩文件以后可以看到目录下有两个文件夹：deployments（用于部署的文件） 和 examples（用于测试的例子）。

执行创建：

```bash
$ cd nginx-ingress-controller
# 为 IngressController 创建 nginx-ingress 命令空间和服务账户
$ kubectl create -f deployments/ns-and-sa.yaml
namespace/nginx-ingress created
serviceaccount/nginx-ingress created
# 对于没有定义 ingress 规则的请求，服务默认返回 404 Not Found 页面，出于测试目的，这里使用自签名的证书和密钥生成了 default-server-secret，大家也可以使用自己的密钥
$ kubectl create -f deployments/default-server-secret.yaml
secret/default-server-secret created
# 创建 ConfigMap 可以自定义 nginx 的配置（大家可以按需编辑这个文件）
$ kubectl create -f deployments/nginx-config.yaml
configmap/nginx-config created
# 在集群中启动 RBAC，创建集群角色并绑定到服务账户
$ kubectl create -f deployments/rbac.yaml
clusterrole.rbac.authorization.k8s.io/nginx-ingress created
clusterrolebinding.rbac.authorization.k8s.io/nginx-ingress created
# 使用 DaemonSet 在每个 Node 节点部署一个 IngressController，在 spec.template.spec 中设置 hostNetwork=true，将容器的端口映射到节点上，这样就可以通过 NodeIP:ContainerPort 直接访问 Ingress
$ kubectl create -f deployments/nginx-ingress.yaml
daemonset.apps/nginx-ingress created
# 为 IngressController 创建 NodePort 类型的服务
$ kubectl create -f deployments/nodeport.yaml
service/nginx-ingress created
```

查看最终创建的资源对象：

```bash
$ kubectl get all -n nginx-ingress
NAME                      READY   STATUS    RESTARTS   AGE
pod/nginx-ingress-8l4w7   1/1     Running   0          7m52s
pod/nginx-ingress-twkrp   1/1     Running   0          7m52s


NAME                    TYPE       CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE
service/nginx-ingress   NodePort   10.109.177.103   <none>        80:32055/TCP,443:30914/TCP   13s

NAME                           DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
daemonset.apps/nginx-ingress   2         2         2       2            2           <none>          7m52s
```

现在运行例子，对 NGINX Ingress Controller 进行测试。

```bash
# 将 Ingress 的 NodeIP 地址保存到 IC_IP 环境变量中
$ export IC_IP=10.192.0.3
# 将 Ingress 的 HTTPS 环境变量端口保存到 IC_HTTPS_PORT 环境变量中
$ export IC_HTTPS_PORT=443
# 创建 coffee 和 tea 的 deployment 和 service
$ kubectl create -f examples/cafe.yaml
deployment.apps/coffee created
service/coffee-svc created
deployment.apps/tea created
service/tea-svc created
# 使用 SSL 证书和密钥创建 cafe-secret
$ kubectl create -f examples/cafe-secret.yaml
secret/cafe-secret created
# 创建 Ingress 规则，当访问 https://cafe.example.com:443/tea 时由后端 tea-svc 提供服务，访问 https://cafe.example.com:443/coffee 由后端 coffee-svc 提供服务
$ kubectl create -f examples/cafe-ingress.yaml
ingress.extensions/cafe-ingress created
```

例子部署完成，执行测试：

```bash
# 通过 curl 访问服务，--resolve 参数设置请求头，--insecure 参数用于关闭自签名证书的验证
# 先访问 coffee service
$ curl --resolve cafe.example.com:$IC_HTTPS_PORT:$IC_IP https://cafe.example.com:$IC_HTTPS_PORT/coffee --insecure
Server address: 10.244.3.4:80
Server name: coffee-6f758cc7cc-6c2m7
Date: 21/Nov/2019:06:17:58 +0000
URI: /coffee
Request ID: f2981ce15bf95c1cf4d74ee2bffadf8a

# 然后访问 tea service
$ curl --resolve cafe.example.com:$IC_HTTPS_PORT:$IC_IP https://cafe.example.com:$IC_HTTPS_PORT/tea --insecure
Server address: 10.244.2.6:80
Server name: tea-b88549687-vmqm6
Date: 21/Nov/2019:06:20:09 +0000
URI: /tea
Request ID: 8126fc00fe35ea2f01e8f328d1a60742
```

这样就完成了 NGINX Ingress Controller 部署以及简单的测试。

在 NGINX Plus 商业版中还提供了 Dashboard 页面可以更加清楚直观的看到各项检测数据：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191121-1574317792500/wm)

## 4. Kong Ingress

**注意：推荐大家新开一个默认环境，进行本部分的操作**

[Kong Ingress](github.com/Kong/kubernetes-ingress-controller) 是由 Kong lnc 开发，它也有两个版本：免费版和商业版。Kong Ingress 是基于 Nginx 构建，在其基础上增加了扩展其功能的 Lua 模块。

作为一款成熟的 IngressController，它的主要优点是在 Ingress 中可以配置大量的插件（拥有最丰富的插件集），用于扩展日志记录、分析、跟踪等功能，管理进出的流量，直接在入口层保护、监控和扩展服务。

Kong Ingress Controller 在 Kubernetes 集群内通过创建的 Ingress 资源对象配置 Kong。

Kong Ingress Controller 依然由两部分组成：

- `Kong`：核心代理，处理所有的流量。
- `Controller`：控制器，将配置从 kubernetes 同步到 Kong

以下是工作原理图：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574390634934/wm)

在 kubernetes 集群中可以以内存模式（DB-less）运行 Kong，因为所有的配置信息都存储在 Kubernetes control-plane 中。这样就不需要担心与数据库相关的各种问题。

下面在环境中安装部署并运行一个简单的例子进行测试。由于相关的文件比较多，将它们全部打包为 kong-ingress-controller.zip 压缩包，大家执行下载即可。如果想要自己尝试安装最新版本的，可以参考 [Deploying Kong for Kubernetes](https://github.com/Kong/kubernetes-ingress-controller/tree/master/docs/deployment)。

首先下载资源文件：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1457/kong-ingress-controller.zip
unzip kong-ingress-controller.zip
```

在文件夹中 all-in-one-dbless.yaml 就是用于相关资源对象创建的。

执行 Kong Ingress Controller 的部署：

```bash
$ cd kong-ingress-controller
# 注意：这里将文件中 Service 中的 LoadBalancer 改为了 NodePort，方便本地访问测试
$ kubectl create -f all-in-one-dbless.yaml
namespace/kong created
customresourcedefinition.apiextensions.k8s.io/kongconsumers.configuration.konghq.com created
customresourcedefinition.apiextensions.k8s.io/kongcredentials.configuration.konghq.com created
customresourcedefinition.apiextensions.k8s.io/kongingresses.configuration.konghq.com created
customresourcedefinition.apiextensions.k8s.io/kongplugins.configuration.konghq.com created
serviceaccount/kong-serviceaccount created
clusterrole.rbac.authorization.k8s.io/kong-ingress-clusterrole created
clusterrolebinding.rbac.authorization.k8s.io/kong-ingress-clusterrole-nisa-binding created
configmap/kong-server-blocks created
service/kong-proxy created
service/kong-validation-webhook created
deployment.apps/ingress-kong created
```

查看创建的资源对象：

```bash
# 注意 service/kong-proxy
$ kubectl get all -n kong
NAME                                READY   STATUS    RESTARTS   AGE
pod/ingress-kong-654fc57f6c-xm2z6   2/2     Running   2          42s


NAME                              TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)                      AGE
service/kong-proxy                NodePort    10.101.58.126   <none>        80:30186/TCP,443:32188/TCP   42s
service/kong-validation-webhook   ClusterIP   10.99.216.102   <none>        443/TCP                      42s


NAME                           READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/ingress-kong   1/1     1            1           42s

NAME                                      DESIRED   CURRENT   READY   AGE
replicaset.apps/ingress-kong-654fc57f6c   1         1         1       42s
```

测试与 Kong 的连接，检查部署是否正确：

```bash
# kube-node-1 的 IP 地址
$ export PROXY_IP=10.192.0.3
# 来自于 Deployment 定义中 proxy 的 containerPort 为 8000
$ export PROXY_PORT=8000
# 向 Kong 发送请求，返回 HTTP 404 Not Found，说明部署正确
$ curl -i $PROXY_IP:$PROXY_PORT
HTTP/1.1 404 Not Found
Date: Thu, 21 Nov 2019 09:52:43 GMT
Content-Type: application/json; charset=utf-8
Connection: keep-alive
Content-Length: 48
Server: kong/1.3.0

{"message":"no Route matched with those values"}
```

部署例子测试，安装一个 echo-server 应用程序用于测试，这个应用程序只返回来自 HTTP 请求相关的 pod 和详细信息：

```bash
$ cd kong-ingress-controller
$ kubectl create -f k8s-echo-server.yaml
service/echo created
deployment.apps/echo created

$ kubectl get pods,svc
NAME                       READY   STATUS    RESTARTS   AGE
pod/echo-89d9d98cc-4r8nn   1/1     Running   0          5m37s
pod/echo-89d9d98cc-jnqm2   1/1     Running   0          5m37s
pod/echo-89d9d98cc-trwwc   1/1     Running   0          5m37s
pod/echo-89d9d98cc-twqmd   1/1     Running   0          5m37s

NAME                 TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)           AGE
service/echo         ClusterIP   10.102.188.170   <none>        8080/TCP,80/TCP   5m37s
service/kubernetes   ClusterIP   10.96.0.1        <none>        443/TCP           95d
```

创建一个 Ingress 规则来代理之前创建的 echo-server 服务：

```bash
# 这里没有创建域名，所有对 NodeIP:ContainerPort/foo 的访问请求都会被转发到后端 echo:80 服务上
$ kubectl create -f ingress.yaml
ingress.extensions/demo created
$ kubectl get ingress
NAME                      HOSTS   ADDRESS      PORTS   AGE
ingress.extensions/demo   *       10.192.0.3   80      64s

# 进行测试，看到类似如下的返回就说明 Ingress 规则配置正确
$ curl -i $PROXY_IP:$PROXY_PORT/foo
HTTP/1.1 200 OK
Content-Type: text/plain; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive
Date: Thu, 21 Nov 2019 10:05:58 GMT
Server: echoserver
X-Kong-Upstream-Latency: 1
X-Kong-Proxy-Latency: 1
Via: kong/1.3.0



Hostname: echo-89d9d98cc-jnqm2

Pod Information:
	node name:	kube-node-1
	pod name:	echo-89d9d98cc-jnqm2
	pod namespace:	default
	pod IP:	10.244.2.5

Server values:
	server_version=nginx: 1.12.2 - lua: 10010

Request Information:
	client_address=10.244.2.1
	method=GET
	real path=/
	query=
	request_version=1.1
	request_scheme=http
	request_uri=http://10.192.0.3:8080/

Request Headers:
	accept=*/*  
	connection=keep-alive  
	host=10.192.0.3:8000  
	user-agent=curl/7.47.0  
	x-forwarded-for=10.192.0.1  
	x-forwarded-host=10.192.0.3  
	x-forwarded-port=8000  
	x-forwarded-proto=http  
	x-real-ip=10.192.0.1  

Request Body:
	-no body in request-
```

上面提高过 Kong Ingress Controller 优点在于可以配置插件，现在我们来配置一款限制速率的服务插件。服务级别的插件是指：当来自客户端的任何请求被发送给 kubernetes 集群中特定的某个后端服务时，无论入口 url 是什么，Kong 都会执行这个插件。

使用服务插件：

```bash
# 创建 KongPlugin 资源对象
$ kubectl create -f kong-plugin.yaml
kongplugin.configuration.konghq.com/rl-by-ip created
# 修改 echo 服务配置，添加 annotations 注解说明需要应用 rl-by-ip 插件
$ kubectl patch svc echo \
  -p '{"metadata":{"annotations":{"plugins.konghq.com": "rl-by-ip\n"}}}'
service/echo patched
```

配置完成后，任何发送到 echo 服务的请求都会受到 kong 强制执行的速率限制的保护：

```bash
$ curl -I $PROXY_IP:$PROXY_PORT/foo
HTTP/1.1 200 OK
Content-Type: text/plain; charset=UTF-8
Connection: keep-alive
Date: Thu, 21 Nov 2019 10:22:14 GMT
Server: echoserver
X-RateLimit-Limit-minute: 5
X-RateLimit-Remaining-minute: 4
X-Kong-Upstream-Latency: 1
X-Kong-Proxy-Latency: 1
Via: kong/1.3.0
```

所以最终形成的配置如下所示：

```text
# 来自客户端对于 /foo 的请求，先经过 Kong rate-limit 插件的处理，然后再转发给后端的 echo server
HTTP requests with /foo -> Kong enforces rate-limit -> echo server
```

如果想要了解 Kong 更多的插件，可以查看 [Kong Hub](https://docs.konghq.com/hub/)。

## 5. Traefik

**注意：推荐大家新开一个默认环境，进行本部分的操作**

[Traefik](github.com/containous/traefik) 是一款开源的反向代理与负载均衡工具，它可以与大多数的微服务系统直接整合，实现自动化动态配置。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574411229837/wm)

与 Kubernetes Ingress Controller 相比，Traefik 本身就能够实时与 ApiServer 交互，获取后端 Service、Pod 的变化，自动更新配置并热加载。因此，Traefik 会更加快速、方便，支持更多特性使得反向代理和负载均衡更直接、高效。

下面我们在环境中进行配置并使用一个简单的 nginx 例子进行测试，由于需要使用较多文件，这里全部打包为 traefik-ingress-controller.zip 压缩包，如果大家想要获取最新的安装文件，可以参考 [Kubernetes Ingress Controller](https://docs.traefik.io/v1.7/user-guide/kubernetes/#deploy-traefik-using-a-deployment-or-daemonset)。

下载所需的文件并解压缩：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1457/traefik-ingress-controller.zip
unzip traefik-ingress-controller.zip
```

执行创建：

```bash
cd traefik-ingress-controller
# rbac 绑定
$ kubectl create -f traefik-rbac.yaml
clusterrole.rbac.authorization.k8s.io/traefik-ingress-controller created
clusterrolebinding.rbac.authorization.k8s.io/traefik-ingress-controller created
# 部署 traefik
$ kubectl create -f traefik-deployment.yaml
serviceaccount/traefik-ingress-controller created
deployment.extensions/traefik-ingress-controller created
service/traefik-ingress-service created
```

检查资源对象是否创建成功：

```bash
$ kubectl get pods -n kube-system -l k8s-app=traefik-ingress-lb
NAME                                             READY   STATUS    RESTARTS   AGE
pod/traefik-ingress-controller-86d49b4b4-2hljn   1/1     Running   0          109s
pod/traefik-ingress-controller-86d49b4b4-qdh7q   1/1     Running   0          109s

$ kubectl get svc -n kube-system
NAME                      TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)                       AGE
...
traefik-ingress-service   NodePort    10.105.232.178   <none>        80:30424/TCP,8080:32335/TCP   4m56s

# 80 端口是用于 http 访问
$ curl 10.192.0.3:80
404 page not found
# 8080 端口是用于 Admin 管理
$ curl 10.192.0.3:8080
<a href="/dashboard/">Found</a>.
```

在浏览器访问地址 `10.192.0.3：8080`，跳转到 dashboard 页面，效果如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574409748845/wm)

部署一个 nginx 例子进行测试，其中 ingress 规则中设置域名为 `traefik.kube.com`：

```bash
$ kubectl create -f nginx.yaml
service/nginx-svc created
deployment.apps/ngx-pod created
ingress.extensions/ngx-ing created
```

刷新 dashboard 页面，效果如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574409904320/wm)

执行 `sudo vim /etc/hosts`，向其中添加域名解析：

```text
10.192.0.3  traefik.kube.com
```

在浏览器访问 `traefik.kube.com`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574410018906/wm)

还可以看到 dashboard 的健康检查：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574410539279/wm)

## 6. Istio Ingress

**注意：推荐大家新开一个默认环境，进行本部分的操作**

[Istio](https://istio.io/) 是由 Google、IBM 和 Lyft 联合开源的微服务管理、保护和监控框架。是一个连接(Connect)、安全加固(Secure)、控制(Control)和观察(Observe)服务的开放平台。Istio 被称为 Service Mesh 架构。而[Istio Ingress](https://istio.io/docs/tasks/traffic-management/ingress/)是用于控制 Istio 服务网的入口流量。

Istio 分为两个平面：数据平面和控制平面。

- 数据平面：由一组 sidecar 的代理（Envoy）组成。这些代理调节和控制微服务之间的所有网络通信，并且与控制平面的 Mixer 通讯，接收调度策略。
- 控制平面：通过管理和配置代理（Envoy）来管理流量。控制平面配置 Mixers 来实施路由策略并收集检测到的监控数据。

下面是 Istio 的架构图：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191124-1574582390188/wm)

下面我们来简单看一看 Istio 在环境中的安装以及测试：

首先下载发行版，这里为了方便，将文件打包上传到了服务器，大家下载后即可使用。

```bash
$ wget https://labfile.oss.aliyuncs.com/courses/1457/istio-1.4.0-linux.tar.gz
$ tar -zxvf istio-1.4.0-linux.tar.gz
$ cd istio-1.4.0
# install/kubernetes 目录下存放着 kubernetes 安装 YAML 文件，samples 目录下存放着简单的 APP 应用，bin 目录下存放着二进制命令行工具 istioctl
# 添加路径
$ export PATH=$PWD/bin:$PATH
```

然后安装 Istio:

```bash
# 安装 demo 文件
$ istioctl manifest apply --set profile=demo
# 在 istio-system 命名空间下查看所有的服务，由于我们这里是 dind 集群不支持外部负载均衡器，LoadBalancer 方式实现不了
$ kubectl get svc -n istio-system
NAME                     TYPE           CLUSTER-IP       EXTERNAL-IP   PORT(S)                                                                                                                      AGE
grafana                  ClusterIP      10.97.163.155    <none>        3000/TCP                                                                                                                     40s
istio-citadel            ClusterIP      10.101.171.239   <none>        8060/TCP,15014/TCP                                                                                                           42s
istio-egressgateway      ClusterIP      10.108.0.203     <none>        80/TCP,443/TCP,15443/TCP                                                                                                     40s
istio-galley             ClusterIP      10.111.223.242   <none>        443/TCP,15014/TCP,9901/TCP,15019/TCP                                                                                         42s
istio-ingressgateway     LoadBalancer   10.99.74.79      <pending>     15020:30448/TCP,80:32077/TCP,443:30736/TCP,15029:30527/TCP,15030:30651/TCP,15031:31680/TCP,15032:31667/TCP,15443:30158/TCP   40s
istio-pilot              ClusterIP      10.105.151.48    <none>        15010/TCP,15011/TCP,8080/TCP,15014/TCP                                                                                       40s
istio-policy             ClusterIP      10.98.24.182     <none>        9091/TCP,15004/TCP,15014/TCP                                                                                                 42s
istio-sidecar-injector   ClusterIP      10.96.152.245    <none>        443/TCP                                                                                                                      41s
istio-telemetry          ClusterIP      10.96.20.147     <none>        9091/TCP,15004/TCP,15014/TCP,42422/TCP                                                                                       39s
jaeger-agent             ClusterIP      None             <none>        5775/UDP,6831/UDP,6832/UDP                                                                                                   47s
jaeger-collector         ClusterIP      10.99.31.75      <none>        14267/TCP,14268/TCP,14250/TCP                                                                                                46s
jaeger-query             ClusterIP      10.97.173.207    <none>        16686/TCP                                                                                                                    45s
kiali                    ClusterIP      10.103.160.169   <none>        20001/TCP                                                                                                                    42s
prometheus               ClusterIP      10.100.150.33    <none>        9090/TCP                                                                                                                     43s
tracing                  ClusterIP      10.99.155.251    <none>        9411/TCP                                                                                                                     43s
zipkin                   ClusterIP      10.97.147.226    <none>        9411/TCP                                                                                                                     41s
# 查看 istio-system 命名空间下的所有 pod
$ kubectl get pods -n istio-system
NAME                                      READY   STATUS    RESTARTS   AGE
grafana-6c8f45499-94cbd                   1/1     Running   0          3m19s
istio-citadel-784d7df6b6-krvlg            1/1     Running   0          3m25s
istio-egressgateway-6d9bb5b7fd-f786m      1/1     Running   0          3m25s
istio-galley-7c4f46cb88-8l7w5             1/1     Running   0          3m23s
istio-ingressgateway-79f779dbd-v76r9      1/1     Running   0          3m25s
istio-pilot-7dbbc6d47c-rjvnt              1/1     Running   0          3m23s
istio-policy-76cf7d86c-blgsh              1/1     Running   5          3m25s
istio-sidecar-injector-74cd6dcd84-l94m4   1/1     Running   0          3m22s
istio-telemetry-7b969c885c-mbkvr          1/1     Running   3          3m24s
istio-tracing-78548677bc-crhkk            1/1     Running   0          3m26s
kiali-fb5f485fb-lswvq                     1/1     Running   0          3m22s
prometheus-685585888b-rq7fl               1/1     Running   0          3m24s
```

在 Istio 服务网中，使用不同的配置模型（Istio Gateway）指定公开在集群外的服务，接下来我们进行配置：

```bash
$ cd istio-1.4.0
# 注入 sidecar，并部署 httpbin 服务
$ kubectl apply -f <(istioctl kube-inject -f samples/httpbin/httpbin.yaml)
serviceaccount/httpbin created
service/httpbin created
deployment.apps/httpbin created
# 设置入口 host 环境变量（这里通过 node 节点的 IP 地址访问）
$ export INGRESS_HOST=$(kubectl get po -l istio=ingressgateway -n istio-system -o jsonpath='{.items[0].status.hostIP}')
# 设置端口 port 环境变量（这里通过 node 节点的 port 访问）
$ export INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].nodePort}')
```

接下来配置 Ingress（需要的配置文件已经打包，大家下载即可）：

```bash
$ cd ~
$ wget https://labfile.oss.aliyuncs.com/courses/1457/istio-ingress-controller.zip
$ unzip istio-ingress-controller.zip
$ cd istio-ingress-controller
# 创建一个 Istio Gateway 名为 httpbin-gateway，并指定 host 为 httpbin.example.com
$ kubectl create -f httpbin-gateway.yaml
gateway.networking.istio.io/httpbin-gateway created
# 为 httpbin-gateway 配置两个路由：/status 和 /delay
$ kubectl create -f httpbin-virtual-service.yaml
virtualservice.networking.istio.io/httpbin created
```

Gateway 只允许通过已经在 httpbin-gateway 配置了的路由的请求通过，而其他的请求都会返回 404 Not Found。

下面进行测试：

```bash
# -H 设置 HTTP 请求头，请求 /status 路由，成功返回响应 200 OK
$ curl -I -HHost:httpbin.example.com http://$INGRESS_HOST:$INGRESS_PORT/status/200
HTTP/1.1 200 OK
server: istio-envoy
date: Fri, 22 Nov 2019 10:24:51 GMT
content-type: text/html; charset=utf-8
access-control-allow-origin: *
access-control-allow-credentials: true
content-length: 0
x-envoy-upstream-service-time: 3
# 请求 /headers 路由，未配置，返回 404 Not Found
$ curl -I -HHost:httpbin.example.com http://$INGRESS_HOST:$INGRESS_PORT/headers
HTTP/1.1 404 Not Found
date: Fri, 22 Nov 2019 10:25:25 GMT
server: istio-envoy
transfer-encoding: chunked
```

这里是指定了 host 的，也可以配置无请求头，将 host 使用 * 代替：

```bash
$ kubectl apply -f - <<EOF
apiVersion: networking.istio.io/v1alpha3
kind: Gateway
metadata:
  name: httpbin-gateway
spec:
  selector:
    istio: ingressgateway # use Istio default gateway implementation
  servers:
  - port:
      number: 80
      name: http
      protocol: HTTP
    hosts:
    - "*"
---
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
  name: httpbin
spec:
  hosts:
  - "*"
  gateways:
  - httpbin-gateway
  http:
  - match:
    - uri:
        prefix: /headers
    route:
    - destination:
        port:
          number: 8000
        host: httpbin
EOF
```

查看主机和端口：

```bash
$ echo $INGRESS_HOST
10.192.0.4
$ echo $INGRESS_PORT
32077
```

然后在浏览器中访问地址 `10.192.0.4:32077/headers`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191122-1574419057629/wm)

或者也可以使用 curl：

```bash
$ curl http://$INGRESS_HOST:$INGRESS_PORT/headers
{
  "headers": {
    "Accept": "*/*",
    "Content-Length": "0",
    "Host": "10.192.0.4:32077",
    "User-Agent": "curl/7.47.0",
    "X-B3-Parentspanid": "b676d396c632c06e",
    "X-B3-Sampled": "1",
    "X-B3-Spanid": "b85683ca8663d809",
    "X-B3-Traceid": "0f7ff571ac085622b676d396c632c06e",
    "X-Envoy-Internal": "true"
  }
}
```

可以说 Istio 是一个几乎可以执行所有操作的大型处理器，它的核心优势就是最大程度的控制、可扩展性、安全性和透明性。这也意味着这是一个复杂的解决方案，需要更多的经验才能很好的配置、运行和操作 Istio。

## 7. 实验总结

本次实验我们向大家介绍了如下知识点：

- IngressController 简介
- NGINX Ingress Controller
- Kong Ingress
- Traefik
- Istio Ingress

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
