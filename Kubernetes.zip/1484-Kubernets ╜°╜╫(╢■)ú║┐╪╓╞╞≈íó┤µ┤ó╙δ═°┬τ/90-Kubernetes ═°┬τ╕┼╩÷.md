---
show: step
version: 1.0
---

# Kubernetes 网络概述

## 1.实验介绍

####  实验内容

本次实验主要讲解 Kubernetes 的网络部分。网络是 Kubernetes 集群非常核心的组成部分，kubernetes 本身并没有实现对于网络的设置，只是通过提供一套标准的网络接口规则开放给社区进行具体的实现。我们首先讲解 kubernetes 网络模型以及网络实现的具体方法，后续将会慢慢介绍 kubernetes 各种不同类型网络插件的实现原理和使用方法供大家参考扩展。

####  实验知识点

- Kubernetes 网络模型
- Kubernetes 网络实现之“容器之间的通信”
- Kubernetes 网络实现之“Pod 之间的通信”

####  推荐阅读

- [Cluster Networking](https://kubernetes.io/docs/concepts/cluster-administration/networking/)

## 2. Kubernetes 网络模型

#### IP-per-Pod 模型

基础原则：每个 Pod 都拥有一个独立的 IP 地址，并假定所有 Pod 都在一个可以直接连通的、扁平的网络空间中。不管这些 Pod 是否运行在同一个 Node 节点上，都要求它们之间直接通过对方的 IP 就可以进行访问。

设计原因：用户不需要额外考虑如何建立 Pod 之间的连接，也不需要考虑如何将容器端口映射到主机端口等问题。

在 kubernetes 集群中，`IP 是以 Pod 为单位进行分配的，在 Pod 内部的所有容器共享一个网络命名空间（即：IP 地址、网络设备、配置等）`。因此，为每个 Pod 都设置一个 IP 地址的这种模式被称为 `IP-per-Pod` 模型。

`IP-per-Pod` 模型假设 Pod 之间访问时使用的是对方 Pod 的实际地址，所以一个 Pod 内部的应用程序看到的自己的 IP 地址和端口与集群内其他 Pod 看到的是相同的，即：IP 地址和端口在 Pod 内外部都保持一致，不使用 NAT 进行转换。它们都是 Pod 实际分配的 IP 地址（从 docker0 上分配）。

`IP-per-Pod` 模型的另一层含义是：同一个 Pod 内的不同容器共享同一个网络命名空间，容器之间通过 localhost 来连接对方的端口。这样可以减少 Pod 内容器之间的隔离性，更加简单高效地共享资源、互相通信。

因此，`IP-per-Pod` 模型是一个简单、兼容性良好的模型。无论是从网络端口分配、域名解析、服务发现，还是负载均衡、应用配置和迁移等方面来看，采用这种模型以后，Pod 都可以被视为一台独立的虚拟机。

kubernetes 集群中对网络的要求如下：

- 所有容器之间无需 NAT（网络地址转换）就可以直接互相访问通信；
- 所有 Node 和所有容器之间无需 NAT（网络地址转换）就可以直接互相访问通信；
- 容器自己看到的 IP 与其它容器看到的是一样的。

## 3. Kubernetes 网络实现

Kubernetes 的网络实现总共可以划分为 4 个层级：

- 容器和容器之间的网络
- Pod 和 Pod 之间的网络
- Pod 和 Service 之间的网络
- Internet 与 Service 之间的网络

最后两个层级在前面的训练营中已经讲解过，也就是 Service 部分的内容（`ClusterIP Service`、`NodePort Service`、`LoadBalancer Service`、`ExternalName Service` 以及 `Ingress`）。如果不清楚的同学可以查看训练营 [《Kubernetes 进阶（一）：Pod 与 Service》](https://www.shiyanlou.com/courses/1458)。

接下来的部分主要讲解前面两个层级的内容。

###  容器和容器之间的网络

在同一个 Pod 中的容器共享相同的网络命名空间，容器之间通过 localhost 访问端口。

容器和容器之间的网络通信图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191212-1576135923087/wm)

表示的是在一个 Node 上运行着一个 Pod 实例，在 Pod 中运行着容器 1 和容器 2。容器 1 和容器 2 共享相同的网络命名空间，打开的端口不会产生冲突。

通过设置 Docker 的 `--net=container`，指定新创建的 Docker 容器与已经存在的容器共享相同的网络命名空间，而不是和宿主机共享。即：新创建的 Docker 容器不会创建自己的网卡、配置 IP 等，而是与指定的容器共享 IP、端口范围。这个指定的容器就是 Pause 容器，每次在 Pod 上执行创建容器时，首先都会创建一个 Pause 容器（这个容器的唯一任务就是保留并持有一个网络命名空间 `netns`），然后再创建其它满足要求的容器，其它容器就会加入到 Pause 容器的网络命名空间中。这些容器之间的关系如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191212-1576137215237/wm)

###  Pod 和 Pod 之间的网络

在 kubernetes 集群中，每个 Pod 都有一个真实的全局 IP 地址，Pod 之间直接通过对方的 IP 地址就可以实现访问。但是我们知道 Pod 可能分布于不同的 Node 上，因此这里的情况也可以分为两类：

- 同一个 Node 内 Pod 之间的通信
- 不同 Node 上 Pod 之间的通信

#### 同一个 Node 内 Pod 之间的通信

同一个 Node 内 Pod 之间的通信图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191212-1576138723994/wm)

Pod1 和 Pod2 都是通过 Veth 连接到同一个 docker0 网桥上的，Pod1 的 IP1 地址、Pod2 的 IP2 地址都是从 docker0 网段上动态获取的，它们和网桥上的 IP3 地址处于同一个网段。

这中间使用 Linux 虚拟以太网设备，使用由两个（或是多个）虚拟接口组成的 Veth 将不同的网络命名空间连接起来。这些虚拟接口分布在多个网络命名空间（即：多个 Pod 上），Veth 的一端连接到 root 网络命名空间（即：Node 上），另一端连接到 Pod 的网络命名空间上。

在 Pod1 和 Pod2 的 Linux 协议栈中，默认路由为 docker0 的地址，所以所有非本地地址的网络数据，会被默认发送到 docker0 网桥上，由 docker0 网桥进行中转。

就是通过 docker0 网桥以及相同的地址段，从而实现了同一个 Node 内不同 Pod 之间的通信。

#### 不同 Node 上 Pod 之间的通信

不同 Node 上 Pod 之间的通信图示如下：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191212-1576140362792/wm)

Pod1 的 IP 地址是 IP1，Pod2 的 IP 地址是 IP2，Node 1 的 IP 地址为是 IP3，Node2 的 IP 地址是 IP4。想要实现 Pod 1 访问 Pod2，就将数据通过 Node1 的 eth0 发送，通过寻址找到 Node2 的 ech0 接收。所以整个过程就是从：`IP1 -> IP3 -> IP4 -> IP2`。

通过前面的介绍我们知道，Pod 的地址和 docker0 处于相同网段，但是 docker0 网段与所在 Node 节点的网卡是两个完全不同的 IP 网段。不同 Node 节点之间的通信只能通过物理网卡进行实现，因此肯定要实现通过主机进行 IP 寻址。

kubernetes 集群中的 etcd 数据库会记录所有正在运行的 Pod 的 IP 地址信息，方便 Pod 之间进行通信时能够及时获取到对方 Pod 的地址。这就要求 Pod 的 IP 地址一定不能有冲突。

因此，想要在不同 Node 上进行 Pod 之间的通信必须满足以下两点要求：

- 集群统一为 Pod 进行 IP 地址分配，保证不冲突；
- 将 Pod 的 IP 与 Node 的 IP 进行关联，使得即使不在相同节点 Pod 之间也可以互相访问。

对于 kubernetes 本身并没有实现网络规划的具体逻辑，只是制定了一套 CNI（Container Network Interface）接口规范，然后开放给社区来实现各种网络插件。大家可以根据自己的生产环境特点，使用不同的开源网络插件完成对于网络的部署。

## 4. 实验总结

本次实验我们向大家介绍了如下知识点：

- Kubernetes 网络模型
- Kubernetes 网络实现之“容器之间的通信”
- Kubernetes 网络实现之“Pod 之间的通信”

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
