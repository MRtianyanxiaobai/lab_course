---
show: step
version: 1.0
---

# Calico 使用

## 1.实验介绍

####  实验内容

本次实验将会为大家介绍 Calico 的使用。在前面的实验中，我们已经了解到在 kubernetes 中只是规定了 CNI 网络模型，当我们自己搭建集群的时候往往使用社区开源的网络插件。所以接下来的内容将会向大家介绍在社区中比较常用的几种网络插件的实现原理及具体使用方法，供大家拓展。

####  实验知识点

- Calico 简介
- 使用 Calico 搭建集群环境
- 测试搭建的集群

####  推荐阅读

- [calico](https://github.com/projectcalico/calico)
- [projectcalico](https://www.projectcalico.org/)

## 2. Calico 简介

Calico 是一个基于 BGP 的纯三层网络方案，可以和 kubernetes、AWS、OpenStack 等云平台良好的集成。Calico 在所有节点通过 Linux Kernel 实现了高效的 vRounter 进行数据转发。每个 vRouter 通过 BGP1 协议把在本节点上运行的容器的路由信息向整个 Calico 网络广播，并自动设置到达其他节点的路由转发规则。

Calico 保证所有容器之间的数据流量都是通过 IP 路由的方式完成互联互通的。Calico 节点组网时可以直接利用数据中心的网络结构（L2/L3），不需要额外的 NAT、隧道或者 Overlay Network，没有额外的封包解包，能够节约 CPU 运算，提高网络效率。

Calico 的 IP 池有两种模式：

- `IPIP`模式：将各 Node 的路由之间做一个 tunnel，再把两个网络连接起来的模式。启用 IPIP 模式，Calico 会在每个 Node 上创建一个名为 `tunl0` 的虚拟网络接口。
- `BGP`模式：直接使用物理机作为虚拟路由器（vRouter），不会额外创建 tunnel。

当 Calico 在小规模集群中部署时可以直接互联，在大规模集群中部署时需要通过额外的 BGP route reflector 进行实现。

Calico 的架构图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191217-1576569014176/wm)

Calico 的主要组件有：

- `Felix`：Calico Agent，运行在每个 Node 上，负责为容器设置网络资源（包括：IP 地址、路由规则、iptables 规则等），保证跨主机容器网络互通。
- `etcd`：后端存储网络信息。
- `BGP Client`：负责把 Felix 在各 Node 上设置的路由信息通过 BGP 协议广播到 Calico 网络。
- `Route Reflector`：大规模部署时，作为 BGP Client 的中心连接点，完成分级路由分发。

更多关于组件的详细介绍，大家可以参考：[Calico architecture](https://docs.projectcalico.org/v3.10/reference/architecture/)。

## 3. 使用 Calico 搭建集群环境

由于对环境要求比较特殊，需要使用的环境为使用 Kubeadm 在阿里云 ECS 服务器上安装 Kubernetes 集群，然后在这个集群中进行操作。

在阿里云 ECS 上开启 3 个按量付费的实例，我这里创建的 3 个实例的名称、公网 IP、以及私有 IP 分别如下所示（大家新建的公网 IP 和私有 IP 会不相同的）：

```text
节点名          公网IP          私有IP
kube-master    47.99.132.60   172.16.98.154
kube-node-1    47.111.0.30    172.16.98.155
kube-node-2    47.110.243.83  172.16.98.156
```

为了方便后面轻松分辨各个不同的节点，首先修改节点名，设置所有节点主机名：

```bash
# 在 kube-master 节点执行
hostnamectl --static set-hostname  kube-master
# 在 kube-node-1 节点执行
hostnamectl --static set-hostname  kube-node-1
# 在 kube-node-2 节点执行
hostnamectl --static set-hostname  kube-node-2
```

所有节点的 主机名/IP 加入 hosts 解析，编辑所有节点的 /etc/hosts 文件，都加入以下内容：(注意：将文件中类似于 `172.16.98.144   iZbp187zqzhr7zxedv9l37Z iZbp187zqzhr7zxedv9l37Z` 部分注释掉)

```bash
172.16.98.154 kube-master
172.16.98.155 kube-node-1
172.16.98.156 kube-node-2
```

这里的步骤可以参考[《Kubernetes 基础：入门与安装配置》](https://www.shiyanlou.com/courses/1457) 中的《实验 7：Kubeadm 安装》。按照《实验 7：Kubeadm 安装》完成 `2.2 安装 ALL-In-One 的 Kubernetes 集群` 中的第 1-4 个步骤，由于这里需要将网络插件换为 Calico，接下来的操作步骤如下所示。

通过参数 `--pod-network-cidr` 设置 Calico 的网段，在 kube-master 节点上执行如下命令：

```bash
$ kubeadm init --image-repository registry.aliyuncs.com/google_containers --pod-network-cidr=192.168.0.0/16
...
Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
  https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 172.16.98.154:6443 --token x35y37.ra1kjf1l93lp443z \
    --discovery-token-ca-cert-hash sha256:b57c5cdd911bf8027fd1056e98e6a224ba0cebb77b0ad31c54d92e9fe05a299a
```

复制 kubectl 相关配置文件：

```bash
$ mkdir -p $HOME/.kube
$ cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
$ chown $(id -u):$(id -g) $HOME/.kube/config
```

安装网络插件 Calico:

```bash
$ kubectl apply -f https://docs.projectcalico.org/v3.10/manifests/calico.yaml
configmap/calico-config created
customresourcedefinition.apiextensions.k8s.io/felixconfigurations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamblocks.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/blockaffinities.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamhandles.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ipamconfigs.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/bgppeers.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/bgpconfigurations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/ippools.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/hostendpoints.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/clusterinformations.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/globalnetworkpolicies.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/globalnetworksets.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/networkpolicies.crd.projectcalico.org created
customresourcedefinition.apiextensions.k8s.io/networksets.crd.projectcalico.org created
clusterrole.rbac.authorization.k8s.io/calico-kube-controllers created
clusterrolebinding.rbac.authorization.k8s.io/calico-kube-controllers created
clusterrole.rbac.authorization.k8s.io/calico-node created
clusterrolebinding.rbac.authorization.k8s.io/calico-node created
daemonset.apps/calico-node created
serviceaccount/calico-node created
deployment.apps/calico-kube-controllers created
serviceaccount/calico-kube-controllers created
```

接下来将 Node 节点加入集群。在 kube-node-1 和 kube-node-2 节点分别执行上一步骤输出的 `kubeadm join` 命令：

```bash
$ kubeadm join 172.16.98.154:6443 --token x35y37.ra1kjf1l93lp443z \
>     --discovery-token-ca-cert-hash sha256:b57c5cdd911bf8027fd1056e98e6a224ba0cebb77b0ad31c54d92e9fe05a299a
W1217 17:07:02.622837    1507 join.go:346] [preflight] WARNING: JoinControlPane.controlPlane settings will be ignored when control-plane flag is not set.
[preflight] Running pre-flight checks
        [WARNING IsDockerSystemdCheck]: detected "cgroupfs" as the Docker cgroup driver. The recommended driver is "systemd". Please follow the guide at https://kubernetes.io/docs/setup/cri/
[preflight] Reading configuration from the cluster...
[preflight] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -oyaml'
[kubelet-start] Downloading configuration for the kubelet from the "kubelet-config-1.17" ConfigMap in the kube-system namespace
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[kubelet-start] Writing kubelet environment file with flags to file "/var/lib/kubelet/kubeadm-flags.env"
[kubelet-start] Starting the kubelet
[kubelet-start] Waiting for the kubelet to perform the TLS Bootstrap...

This node has joined the cluster:
* Certificate signing request was sent to apiserver and a response was received.
* The Kubelet was informed of the new secure connection details.

Run 'kubectl get nodes' on the control-plane to see this node join the cluster.
```

检查 Node 是否成功加入集群。在 kube-master 节点执行如下命令：

```bash
$ kubectl get nodes
NAME          STATUS   ROLES    AGE   VERSION
kube-master   Ready    master   23m   v1.17.0
kube-node-1   Ready    <none>   11m   v1.17.0
kube-node-2   Ready    <none>   54s   v1.17.0
```

可以看到 3 个节点的状态都变为了 Ready。查看 Pod 的情况：

```bash
$ kubectl get pods -n kube-system -o wide
NAME                                       READY   STATUS    RESTARTS   AGE     IP                NODE          NOMINATED NODE   READINESS GATES
calico-kube-controllers-74c9747c46-bj7vs   1/1     Running   0          28m     192.168.221.195   kube-master   <none>           <none>
calico-node-99654                          1/1     Running   0          18m     172.16.98.155     kube-node-1   <none>           <none>
calico-node-dv9lx                          1/1     Running   0          28m     172.16.98.154     kube-master   <none>           <none>
calico-node-zl8v7                          1/1     Running   0          7m51s   172.16.98.156     kube-node-2   <none>           <none>
coredns-9d85f5447-7bspj                    1/1     Running   0          30m     192.168.221.193   kube-master   <none>           <none>
coredns-9d85f5447-pdds7                    1/1     Running   0          30m     192.168.221.194   kube-master   <none>           <none>
etcd-kube-master                           1/1     Running   0          29m     172.16.98.154     kube-master   <none>           <none>
kube-apiserver-kube-master                 1/1     Running   0          29m     172.16.98.154     kube-master   <none>           <none>
kube-controller-manager-kube-master        1/1     Running   0          29m     172.16.98.154     kube-master   <none>           <none>
kube-proxy-2q75p                           1/1     Running   0          18m     172.16.98.155     kube-node-1   <none>           <none>
kube-proxy-7jgg4                           1/1     Running   0          7m51s   172.16.98.156     kube-node-2   <none>           <none>
kube-proxy-pzp9g                           1/1     Running   0          30m     172.16.98.154     kube-master   <none>           <none>
kube-scheduler-kube-master                 1/1     Running   0          29m     172.16.98.154     kube-master   <none>           <none>
```

可以看到在每个节点都有一个 Calico Agent，在这里体现为有 3 个 `calico-node-xxxxx` Pod 分别分布在 3 个不同的节点上，同时 `calico-kube-controllers-xxx-xxx` Pod 在 kube-master 节点上用于设置集群中的网络策略（Network Policy）。

按照 CNI 网络模型的要求，存放 CNI 网络插件配置信息的文件夹路径为 `/etc/cni/net.d`，存放 CNI 网络插件可执行文件的文件夹路径为 `/opt/cni/bin`，我们分别来看这两个目录下存在哪些文件：

```bash
$ cd /etc/cni/net.d
# 10-calico.conflist 文件中是 CNI 配置文件内容，calico-kubeconfig 文件中是 Calico 所需的 kubeconfig 配置信息
$ ls
10-calico.conflist  calico-kubeconfig
$ cd /opt/cni/bin
# 二进制文件 calico 和 calico-ipam，就是被 kubelet 调用的
$ ls
bandwidth  calico       dhcp     host-device  ipvlan    macvlan  ptp     tuning
bridge     calico-ipam  flannel  host-local   loopback  portmap  sample  vlan
```

这里可以关注一下 `10-calico.conflist` 文件中的内容，定义的是 CNI 网络配置插件：

```yaml
{
  "name": "k8s-pod-network", # 名称
  "cniVersion": "0.3.1", # CNI 版本号
  "plugins": [ # 插件信息，这里定义了两个插件，第一个名为 calico，第二个名为 portmap。多网络插件会按照配置列表中的顺序依次执行，在这里就是会将经过 calico 网络插件处理的结果再传递给 portmap 网络插件继续处理。
    {
      "type": "calico", # calico 网络插件
      "log_level": "info",
      "datastore_type": "kubernetes", # 使用 kubernetes 集群的存储
      "nodename": "kube-master",
      "mtu": 1440,
      "ipam": {
          "type": "calico-ipam" # 使用 calico-ipam 插件
      },
      "policy": {
          "type": "k8s"
      },
      "kubernetes": {
          "kubeconfig": "/etc/cni/net.d/calico-kubeconfig" # kubeconfig 文件路径
      }
    },
    {
      "type": "portmap", # portmap 网络插件
      "snat": true,
      "capabilities": {"portMappings": true}
    }
  ]
}
```

配置了多个网络插件，当删除的时候以逆序的方式执行删除操作，在这里就是先删除 portmap 的配置信息，然后再删除 calico 的配置信息。

接下来让我们看看两个 Node 节点的网络配置。

calico-node 在创建的时候设置了 IP 地址池，node 节点子网的 IP 地址就是从地址池中分配的，大家可以查看 `calico.yaml` 文件中的相关定义：

```yaml
            # Enable IPIP
            - name: CALICO_IPV4POOL_IPIP
              value: "Always"
            # Set MTU for tunnel device used if ipip is enabled
            - name: FELIX_IPINIPMTU
              valueFrom:
                configMapKeyRef:
                  name: calico-config
                  key: veth_mtu
            # The default IPv4 pool to create on startup if none exists. Pod IPs will be
            # chosen from this range. Changing this value after installation will have
            # no effect. This should fall within `--cluster-cidr`.
            - name: CALICO_IPV4POOL_CIDR
              value: "192.168.0.0/16"
```

可以看到这里默认启动了 IPIP 模式，所以 node 节点子网应该存在名为 `tunl0` 的网络接口。

在 kube-node-1 节点上查看网络接口信息：

```bash
$ ip addr show
...
# 可以看到这里出现了 `tunl0` 网络接口，网络地址为：`192.168.135.128/32`
4: tunl0@NONE: <NOARP,UP,LOWER_UP> mtu 1440 qdisc noqueue state UNKNOWN group default qlen 1
    link/ipip 0.0.0.0 brd 0.0.0.0
    inet 192.168.135.128/32 brd 192.168.135.128 scope global tunl0
       valid_lft forever preferred_lft forever
```

在 kube-node-2 节点上查看网络接口信息：

```bash
$ ip addr show
...
# 可以看到这里出现了 `tunl0` 网络接口，网络地址为：`192.168.169.128/32`
4: tunl0@NONE: <NOARP,UP,LOWER_UP> mtu 1440 qdisc noqueue state UNKNOWN group default qlen 1
    link/ipip 0.0.0.0 brd 0.0.0.0
    inet 192.168.169.128/32 brd 192.168.169.128 scope global tunl0
       valid_lft forever preferred_lft forever
```

接下来查看 kube-node-1 节点的路由表：

```bash
$ ip route
...
# 可以看到一条到 kube-node-2 节点的私网 192.168.169.128 的路由转发规则
192.168.169.128/26 via 172.16.98.156 dev tunl0  proto bird onlink
...
```

同理查看 kube-node-2 节点的路由表：

```bash
$ ip route
...
# 可以看到一条到 kube-node-1 节点的私网 192.168.135.128 的路由转发规则
192.168.135.128/26 via 172.16.98.155 dev tunl0  proto bird onlink
...
```

从上面的结果可以看到，Calico 完成了 Node 间容器网络的设置。当有新的 Pod 调度到这个节点，kubelet 就会通过 CNI 接口调用 Calico 网络插件完成网络的设置，包括 IP 地址、路由规则、iptables 规则等。

## 4. 测试搭建的集群

最后我们创建测试 Pod，验证跨主机容器网络是否能够成功连通。

在 kube-master 上执行如下命令：

```bash
$ kubectl run nginx --image=nginx --replicas=2
deployment.apps/nginx created
$ kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE   IP                NODE          NOMINATED NODE   READINESS GATES
nginx-6db489d4b7-jwhj2   1/1     Running   0          23s   192.168.135.131   kube-node-1   <none>           <none>
nginx-6db489d4b7-lsrlg   1/1     Running   0          23s   192.168.169.130   kube-node-2   <none>           <none>
```

可以看到在 kube-node-1 节点的 nginx Pod 的 IP 地址为 `192.168.135.xxx`，在 kube-node-2 节点的 nginx Pod 的 IP 地址为 `192.168.169.xxx`。

```bash
# nginx-6db489d4b7-jwhj2 所在的节点为 kube-node-1
$ kubectl exec -it nginx-6db489d4b7-jwhj2 /bin/bash
root@nginx-6db489d4b7-jwhj2:/# apt-get update
root@nginx-6db489d4b7-jwhj2:/# apt-get install -y iputils-ping

# 测试与 kube-node-2 节点上的 nginx-6db489d4b7-lsrlg Pod 的网络连通性
root@nginx-6db489d4b7-jwhj2:/# ping 192.168.169.130
PING 192.168.169.130 (192.168.169.130) 56(84) bytes of data.
64 bytes from 192.168.169.130: icmp_seq=1 ttl=62 time=0.347 ms
64 bytes from 192.168.169.130: icmp_seq=2 ttl=62 time=0.326 ms
64 bytes from 192.168.169.130: icmp_seq=3 ttl=62 time=0.304 ms
64 bytes from 192.168.169.130: icmp_seq=4 ttl=62 time=0.307 ms
64 bytes from 192.168.169.130: icmp_seq=5 ttl=62 time=0.312 ms
^C
--- 192.168.169.130 ping statistics ---
5 packets transmitted, 5 received, 0% packet loss, time 1000ms
rtt min/avg/max/mdev = 0.304/0.319/0.347/0.019 ms

# 测试与 kube-node-1 节点物理机内网 IP 地址 172.16.98.155 的连通性
root@nginx-6db489d4b7-jwhj2:/# ping 172.16.98.155
PING 172.16.98.156 (172.16.98.156) 56(84) bytes of data.
64 bytes from 172.16.98.156: icmp_seq=1 ttl=63 time=0.280 ms
64 bytes from 172.16.98.156: icmp_seq=2 ttl=63 time=0.238 ms
64 bytes from 172.16.98.156: icmp_seq=3 ttl=63 time=0.240 ms
64 bytes from 172.16.98.156: icmp_seq=4 ttl=63 time=0.254 ms
^C
--- 172.16.98.156 ping statistics ---
4 packets transmitted, 4 received, 0% packet loss, time 1001ms
rtt min/avg/max/mdev = 0.238/0.253/0.280/0.016 ms
```

这样就可以说明跨主机容器间、容器和宿主机之间的网络都能互联互通了。

现在查看 kube-node-2 节点的网络接口和路由表，可以看到 Calico 新建了一个网络接口 `cali33b48a5d041@if4`，并设置了一条路由规则：

```bash
root@kube-node-2:~# ip addr show
...
6: cali33b48a5d041@if4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1440 qdisc noqueue state UP group default
    link/ether ee:ee:ee:ee:ee:ee brd ff:ff:ff:ff:ff:ff link-netnsid 0

root@kube-node-2:~# ip route
...
192.168.169.130 dev cali33b48a5d041  scope link
...
```

另外还可以执行 `iptables -L` 命令查看为网络接口 `cali33b48a5d041@if4` 设置的一系列 iptables 规则，这里就不再列出。

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Calico 简介
- 使用 Calico 搭建集群环境
- 测试搭建的集群

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
