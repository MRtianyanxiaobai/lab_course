---
show: step
version: 1.0
---

# Kubernetes 日志采集

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Kubernetes 日志采集。

####  实验知识点

- Kubernetes 日志简介
- 在 Pod 中处理日志（pod-level-logging）
- 在 Node 中处理日志（node-level-logging）
- 处理整个集群的日志（cluster-level-logging）
- 在每个 Node 节点上运行一个 agent 收集日志
- 在每个 Pod 中运行 sidecar 容器收集日志
- 直接在应用程序中将日志信息推送到采集后端

## 2. Kubernetes 日志简介

应用和系统日志可以帮助我们了解在一个集群内部到底发生了什么。当调试问题以及监控集群活动的时候日志是非常有帮助的信息。对于容器应用，默认情况下是将日志信息输出到 stdout 和 stderr 中，同时会将日志信息输出到宿主机上的一个 JSON 文件中，通过命令 `docker logs` 或是 `kubelet logs` 就可以查看到对应的日志信息。

但是只使用这种基本的日志输出是没有办法记录完整的日志信息，比如容器奔溃、Pod 驱逐、Node 挂掉等情况出现时，日志信息也就随之消失了。所以我们希望日志可以独立于容器、Pod、Node 节点的生命周期，也就是完全独立于 Kubernetes 系统，这种方式被称为 `cluster-level-logging`。在 Kubernetes 系统的没有提供现成的解决方案，我们可以借由现在社区已经成熟的一些方案来实现单独的日志存储、分析、查询功能。

## 3. 在 Pod 中处理日志（pod-level-logging）

Pod 是 kubernetes 系统最基本的资源对象，所以查看 Pod 的日志是在集群中查看日志最基本的方式，通过 `kubelet logs` 命令就可以快速查看一个容器的日志信息。

这里我们可以部署一个简单的 Pod，这个 Pod 会每隔一秒钟输出当前的时间到 stdout 中。在 `/home/shiyanlou` 目录下新建 `counter.yaml` 文件，并向其中写入如下内容：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: counter
spec:
  containers:
  - name: count
    image: busybox
    args: [/bin/sh, -c,
            'i=0; while true; do echo "$i: $(date)"; i=$((i+1)); sleep 1; done']
```

执行创建：

```bash
$ kubectl create -f counter.yaml
pod/counter created
```

使用 `kubelet logs` 命令就可以查看日志信息，如下所示：

```bash
$ kubectl logs counter
0: Mon Jan 13 05:35:21 UTC 2020
1: Mon Jan 13 05:35:22 UTC 2020
2: Mon Jan 13 05:35:23 UTC 2020
...
```

使用这种方式的好处在于当 Pod 数量很少时，直接通过命令就可以快速获取到日志信息。缺点在于当 Pod 删除时，对应的日志信息也会全部被删除。

## 4. 在 Node 中处理日志（node-level-logging）

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200113-1578894861655/wm)

容器输出到 `stdout` 和 `stderr` 中的内容会被容器引擎重定向到其它地方。比如：容器引擎会重定向这两个数据流以 JSON 格式写入到 Node 本地的日志文件中。

比如前面的 counter Pod 在 Node 节点上的日志存储位置为 `/var/log/containers`。可以进行查看：

```bash
# 查看 counter Pod 所在节点
$ kubectl get pods -o wide
NAME      READY   STATUS    RESTARTS   AGE   IP           NODE          NOMINATED NODE   READINESS GATES
counter   1/1     Running   0          11m   10.244.3.3   kube-node-2   <none>           <none>
# 进入 kube-node-2 节点
$ docker exec -it kube-node-2 bash
# 进入对应日志目录
root@kube-node-2:/# cd /var/log/containers/
# 查看是否有对应的日志文件
root@kube-node-2:/var/log/containers# ls
counter_default_count-c92cdfda8e6fbfb5019a278b5c16785760843d0295a8bde02a79f4453c4fdcf6.log
kube-proxy-bslzl_kube-system_kube-proxy-87a52f6815cb80fbaf91494c7908e7fbf2a62671e66bd0f68e1a7e55a202d2d6.log
kubernetes-dashboard-5ff478f859-h6sk2_kube-system_kubernetes-dashboard-12160db0454632cf4913cd20cfcd8f52256f3e3477596463c23ce0c20ec49b23.log
# 查看日志文件的内容
root@kube-node-2:/var/log/containers# tail counter_default_count-c92cdfda8e6fbfb5019a278b5c16785760843d0295a8bde02a79f4453c4fdcf6.log
{"log":"749: Mon Jan 13 06:16:17 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:17.696364282Z"}
{"log":"750: Mon Jan 13 06:16:18 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:18.697924096Z"}
{"log":"751: Mon Jan 13 06:16:19 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:19.698977481Z"}
{"log":"752: Mon Jan 13 06:16:20 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:20.700554195Z"}
{"log":"753: Mon Jan 13 06:16:21 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:21.701378418Z"}
{"log":"754: Mon Jan 13 06:16:22 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:22.70338563Z"}
{"log":"755: Mon Jan 13 06:16:23 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:23.704484601Z"}
{"log":"756: Mon Jan 13 06:16:24 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:24.705954491Z"}
{"log":"757: Mon Jan 13 06:16:25 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:25.706748402Z"}
{"log":"758: Mon Jan 13 06:16:26 UTC 2020\n","stream":"stdout","time":"2020-01-13T06:16:26.71174716Z"}
```

需要注意的是，由于持续向 JSON 文件中写入日志，时间一长这个文件将会变得非常大，这个时候可以考虑日志轮换。在部署的时候设置脚本将日志数据切分到多个文件中，可以一天执行一次或当数据增长到某个固定大小（比如 10M）时执行。

当运行 `kubelet logs` 命令时，在 Node 节点上的 kubelet 会处理请求、直接从日志文件中读取内容并返回响应。如果是执行了轮换，就会读取最新日志文件中的数据。

Node 级别的日志相比于 Pod 级别的日志更加具有可持续性。如果一个 Pod 被重启，它之前的日志会被保留在 Node 上；但是如果 Pod 被驱逐，它之前的所有日志数据在 Node 上将被删除。

## 5. 处理整个集群的日志（cluster-level-logging）

在实际应用中，我们更加倾向于搭建 Cluster 集群级别的日志系统，Pod 级别和 Node 级别的日志可以帮助获取日志数据。

cluster-level-logging 将日志的收集与集群中其它资源对象的生命周期（比如容器、Pod、Node）进行了分离，这样的好处在于无论什么情况下，比如容器挂掉、Pod 删除、Node 宕机等，都不会丢失原有的日志数据。

但是 kubernetes 集群本身并没有实现 cluster-level-logging，我们需要自己搭建。通常情况下有如下三种方式：

- 在每个 Node 节点上运行一个 agent 收集日志
- 在每个 Pod 中运行 sidecar 容器收集日志
- 直接在应用程序中将日志信息推送到采集后端

这三种方式的适用场景有些不同，下面一一进行介绍。

###  在每个 Node 节点上运行一个 agent 收集日志

“在每个节点上运行一个 agent 收集日志”的原理图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200113-1578898842382/wm)

这里的关键点在于每个节点上都运行了一个 logging-agent 容器，这个容器可以读取 Node 节点上的日志文件目录，然后将日志信息转发给存储后端。所以 logging-agent 容器一般以 DaemonSet 的方式进行部署。

这种方式是 kubernetes 日志收集系统最常用的一种，经常采用的技术栈为 EFK（Elasticsearch + Fluentd + Kibana），其中 Fluentd 就是运行在每个节点上的 Agent，然后将收集到的日志转发给后端存储 Elasticsearch。

使用这种方式收集日志的好处在于：只需要在每个节点上运行一个代理容器，不需要对节点上的其它容器进行修改，耦合度低。

但是这种方式要求应用程序的日志只能输出到 stdout 和 stderr 中，对于自定义日志输出路径的应用是不适用的。

###  在每个 Pod 中运行 sidecar 容器收集日志

在每个 Pod 中运行一个 sidecar 容器收集日志的这种方式就是为了弥补上一种方式的不足，即：不能自定义日志输出路径。

运行 sidecar 容器收集日志在实际应用场景下又分为两种具体的方式：

- sidecar 容器把日志文件重新输出到 stdout/stderr 中
- sidecar 容器直接把日志文件发送到远端存储中

#### .1 sidecar 容器把日志文件重新输出到 stdout/stderr 中

它的原理图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200113-1578900736818/wm)

大家可以看到图中，在 my-pod 中运行了两个容器分别是 app-container 和 streaming container。app-container 容器自定义了日志文件输出路径；streaming container 容器的作用就是一个简单的代理，首先从 app-container 容器的自定义日志文件路径中获取日志数据，然后再输出到 stdout 和 stderr 中；最后使用前面介绍的方式，在 Node 上运行代理容器收集整个节点的日志数据。

比如下面这个例子，在一个 Pod 中运行了一个容器，这个容器会以不同的形式分别向 /var/log/1.log 和 /var/log/2.log 文件中写入数据。在 `/home/shiyanlou` 目录下新建 `counter-pod.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: counter-pod
spec:
  containers:
  - name: count
    image: busybox
    args:
    - /bin/sh
    - -c
    - >
      i=0;
      while true;
      do
        echo "$i: $(date)" >> /var/log/1.log;
        echo "$(date) INFO $i" >> /var/log/2.log;
        i=$((i+1));
        sleep 1;
      done
    volumeMounts:
    - name: varlog
      mountPath: /var/log
  volumes:
  - name: varlog
    emptyDir: {}
```

执行创建：

```bash
$ kubectl create -f counter-pod.yaml
pod/counter-pod created
```

尝试直接查看日志：

```bash
$ kubectl logs counter-pod
```

并没有日志输出。

在这种情况下如果想要获取 counter-pod 的日志，可以在 Pod 中再部署两个 sidecar 容器，分别读取 /var/log/1.log 和 /var/log/2.log 文件并输出到 stdout 和 stderr 中。在 `/home/shiyanlou` 目录下新建 `counter-pod-streaming-sidecar.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: counter-pod-streaming-sidecar
spec:
  containers:
  - name: count
    image: busybox
    args:
    - /bin/sh
    - -c
    - >
      i=0;
      while true;
      do
        echo "$i: $(date)" >> /var/log/1.log;
        echo "$(date) INFO $i" >> /var/log/2.log;
        i=$((i+1));
        sleep 1;
      done
    volumeMounts:
    - name: varlog
      mountPath: /var/log
  - name: count-log-1
    image: busybox
    args: [/bin/sh, -c, 'tail -n+1 -f /var/log/1.log']
    volumeMounts:
    - name: varlog
      mountPath: /var/log
  - name: count-log-2
    image: busybox
    args: [/bin/sh, -c, 'tail -n+1 -f /var/log/2.log']
    volumeMounts:
    - name: varlog
      mountPath: /var/log
  volumes:
  - name: varlog
    emptyDir: {}
```

执行创建：

```bash
$ kubectl create -f counter-pod-sidecar.yaml
pod/counter-pod-streaming-sidecar created
```

查看日志：

```bash
$ kubectl logs counter-pod-streaming-sidecar -c count-log-1
0: Mon Jan 13 08:15:34 UTC 2020
1: Mon Jan 13 08:15:35 UTC 2020
2: Mon Jan 13 08:15:36 UTC 2020
3: Mon Jan 13 08:15:37 UTC 2020
4: Mon Jan 13 08:15:38 UTC 2020
...
$ kubectl logs counter-pod-streaming-sidecar -c count-log-2
Mon Jan 13 08:15:34 UTC 2020 INFO 0
Mon Jan 13 08:15:35 UTC 2020 INFO 1
Mon Jan 13 08:15:36 UTC 2020 INFO 2
Mon Jan 13 08:15:37 UTC 2020 INFO 3
Mon Jan 13 08:15:38 UTC 2020 INFO 4
...
```

sidecar 和主容器之间是共享卷的，性能损耗不算大，只是会多消耗一些 CPU 和内存。但是使用这种方式，相当于在 Node 节点上存在了两份相同的日志文件，一份是应用日志重定向文件，另一份是 sidecar 在节点上的输出的日志文件，这对于磁盘浪费还是比较大。所以只在特殊情况下才使用这种方式采集日志。

#### .2 sidecar 容器直接把日志文件发送到远端存储中

它的原理图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200113-1578904140044/wm)

在图中可以看到：logging-agent 与主容器运行在同一个 Pod 中，然后直接将收集到的日志数据推送到采集后端。

比如同样是上一节中的 count 容器，可以在相同的 Pod 中再创建一个 fluentd 容器作为 sidecar，fluentd 容器采集 count 容器的日志数据（1.log 和 2.log）并写入到 /var/log/fluent/access 文件中（在实际应用中可以配置发送给 Elasticsearch）。

首先将 fluentd 的配置信息存储到 ConfigMap 中，在 `/home/shiyanlou` 目录下新建`fluentd-sidecar-config.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluentd-config
data:
  fluentd.conf: |
    <source>
      type tail
      format none
      path /var/log/1.log
      pos_file /var/log/1.log.pos
      tag count.format1
    </source>

    <source>
      type tail
      format none
      path /var/log/2.log
      pos_file /var/log/2.log.pos
      tag count.format2
    </source>

    <match **>
      type file
      path /var/log/fluent/access
    </match>
```

执行创建：

```bash
$ kubectl create -f fluentd-sidecar-config.yaml
configmap/fluentd-config created
```

接下来创建 Pod，在 `/home/shiyanlou` 目录下新建 `counter-pod-agent-sidecar.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: counter-pod-agent-sidecar
spec:
  containers:
  - name: count
    image: busybox
    args:
    - /bin/sh
    - -c
    - >
      i=0;
      while true;
      do
        echo "$i: $(date)" >> /var/log/1.log;
        echo "$(date) INFO $i" >> /var/log/2.log;
        i=$((i+1));
        sleep 1;
      done
    volumeMounts:
    - name: varlog
      mountPath: /var/log
  - name: count-agent
    image: registry-vpc.cn-hangzhou.aliyuncs.com/chenshi-kubernetes/fluentd-gcp:1.30
    env:
    - name: FLUENTD_ARGS
      value: -c /etc/fluentd-config/fluentd.conf
    volumeMounts:
    - name: varlog
      mountPath: /var/log
    - name: config-volume
      mountPath: /etc/fluentd-config
  volumes:
  - name: varlog
    emptyDir: {}
  - name: config-volume
    configMap:
      name: fluentd-config
```

执行创建：

```bash
$ kubectl create -f counter-pod-agent-sidecar.yaml
pod/counter-pod-agent-sidecar created
$ kubectl get pods
NAME                        READY   STATUS    RESTARTS   AGE
counter-pod-agent-sidecar   2/2     Running   0          52s
```

现在来查看 count-agent 容器是否成功读取到日志数据：

```bash
$ kubectl exec -it counter-pod-agent-sidecar sh
Defaulting container name to count.
Use 'kubectl describe pod/counter-pod-agent-sidecar -n default' to see all of the containers in this pod.
/ # cd /var/log
/var/log # ls
1.log      1.log.pos  2.log      2.log.pos  fluent     journal
/var/log # cd fluent/
/var/log/fluent # ls
access.20200113.b59c02ae703da9883
/var/log/fluent # tail access.20200113.b59c02ae703da9883
2020-01-13T10:14:49+00:00	count.format1	{"message":"276: Mon Jan 13 10:14:49 UTC 2020"}
2020-01-13T10:14:49+00:00	count.format2	{"message":"Mon Jan 13 10:14:49 UTC 2020 INFO 276"}
2020-01-13T10:14:50+00:00	count.format1	{"message":"277: Mon Jan 13 10:14:50 UTC 2020"}
2020-01-13T10:14:50+00:00	count.format2	{"message":"Mon Jan 13 10:14:50 UTC 2020 INFO 277"}
2020-01-13T10:14:51+00:00	count.format1	{"message":"278: Mon Jan 13 10:14:51 UTC 2020"}
2020-01-13T10:14:51+00:00	count.format2	{"message":"Mon Jan 13 10:14:51 UTC 2020 INFO 278"}
2020-01-13T10:14:52+00:00	count.format1	{"message":"279: Mon Jan 13 10:14:52 UTC 2020"}
2020-01-13T10:14:52+00:00	count.format2	{"message":"Mon Jan 13 10:14:52 UTC 2020 INFO 279"}
2020-01-13T10:14:53+00:00	count.format1	{"message":"280: Mon Jan 13 10:14:53 UTC 2020"}
2020-01-13T10:14:53+00:00	count.format2	{"message":"Mon Jan 13 10:14:53 UTC 2020 INFO 280"}
```

使用这种方式对于容器应用就是强耦合，在部署的时候就需要手动进行设置；同时也会造成巨大的资源消耗；而且也无法再使用 `kubelet logs` 命令查看目标容器的日志信息。

###  直接在应用程序中将日志信息推送到采集后端

它的原理图如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200113-1578912549529/wm)

也可以直接在应用程序中设置将日志信息推送到日志后端，但是这个需要修改代码，集群层面无需操作。

综合分析上述三种类型的日志采集方式，我们最推荐的还是使用第一种方式“在每个节点上运行一个 agent 收集日志”。

## 6. 实验总结

本次实验我们向大家介绍了如下知识点：

- Kubernetes 日志简介
- 在 Pod 中处理日志（pod-level-logging）
- 在 Node 中处理日志（node-level-logging）
- 处理整个集群的日志（cluster-level-logging）
- 在每个 Node 节点上运行一个 agent 收集日志
- 在每个 Pod 中运行 sidecar 容器收集日志
- 直接在应用程序中将日志信息推送到采集后端

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
