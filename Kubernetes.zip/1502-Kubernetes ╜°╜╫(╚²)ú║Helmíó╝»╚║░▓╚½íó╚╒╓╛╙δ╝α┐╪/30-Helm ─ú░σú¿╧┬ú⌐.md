---
show: step
version: 1.0
---

# Helm 模板（下）

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Helm 模板（下），实验内容是在上一个实验的基础上继续讲解模板的语法。

####  实验知识点

- 变量
- 命名模板
- 在模板中访问文件
- 忽略不需要的文件和文件夹
- notes 文件
- 子 chart 和全局值

####  推荐阅读

- [Go path 包](https://golang.org/pkg/path/)

## 2. 变量

在 Helm 中，使用变量的场合不是会特别多，但是如果使用的好，就可以帮助我们让代码更加简单易读。这里以 `with` 和 `range` 举例。

在前面 `with` 例子中，我们曾提到过如果想要访问父范围，需要写在限定范围之外，如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  {{- with .Values.favorite }}
  drink: {{ .drink | default "tea" | quote }}
  food: {{ .food | upper | quote }}
  {{- end }}
  release: {{ .Release.Name }}
```

如果我们想要把 `release` 写在 `with` 块内部应该怎么办呢？这个时候变量就可以用上场啦。可以将限定范围赋值给在不考虑当前范围的情况下能够直接访问的变量。

变量表示的是对另一个对象的命名引用，命名方式为 `$name`，赋值操作符为 `:=`。所以我们可以将 `Release.Name` 赋值给变量 `relname`，然后在 `with` 块中引用这个变量即可。

将 configmap.yaml 文件的内容修改为如下：

```yaml
...
data:
  myvalue: "Hello World"
  {{- $relname := .Release.Name -}}  # 这个变量在整个模板中都起作用
  {{- with .Values.favorite }}
  drink: {{ .drink | default "tea" | quote }}
  food: {{ .food | upper | quote }}
  release: {{ $relname }}
  {{- end }}
```

渲染模板，结果如下所示：

```yaml
...
metadata:
  name: test-configmap
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "PIZZA"
  release: test
```

变量在 `range` 循环中也特别有用，可以用来同时捕获索引和值。

将 configmap.yaml 文件的内容修改为如下：

```yaml
...
data:
  myvalue: "Hello World"
  {{- range $key, $val := .Values.favorite }} # 在 range 循环中使用 $key 和 $val 两个变量分别接收列表循环的索引及其对应的值，$key 和 $val 只在 range 块中起作用，下放同理。
  {{ $key }}: {{ $val | quote }}
  {{- end }}
  toppings: |- # 这里的索引就是整数值（从 0 开始）
    {{- range $index, $topping := .Values.pizzaToppings }}
      {{ $index }}: {{ $topping | title | quote }}
    {{- end }}
```

模板渲染后的结果为：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "pizza"
  toppings: |-
      0: "Mushrooms"
      1: "Cheese"
      2: "Peppers"
      3: "Onions"
```

变量既可以是全局变量，也可以是某个块内部的变量，这取决于在什么位置定义它。但是在 Helm 中，有一个全局变量 `$`（这个变量一直指向的都是根上下文）。比如下面这个例子：

```yaml
{{- range .Values.tlsSecrets}} # 在这个 range 块中，作用域为 .Values.tlsSecrets
apiVersion: v1
kind: Secret
metadata:
  name: {{.name}}
  labels:
    app.kubernetes.io/name: {{template "fullname" $}}
    # 在 .Values.tlsSecrets 作用域中不能直接引用其它父作用域的值，即不能使用 .Chart.Name，但是可以使用 $.Chart.Name
    helm.sh/chart: "{{$.Chart.Name}}-{{ $.Chart.Version }}"
    app.kubernetes.io/instance: "{{$.Release.Name}}"
    app.kubernetes.io/managed-by: "{{$.Release.Service}}"
type: kubernetes.io/tls
data:
  tls.crt: {{.certificate}}
  tls.key: {{.key}}
---
{{- end}}
```

## 3. 命名模板

有时在一个模板文件中，有些数据/结构会被反复使用，这时可以考虑在文件中定义多个命名模板，然后在需要的时候直接引用已经定义好的命名模板即可。

`命名模板`又被称为`子模板`，是限定在一个文件内部的模板，并且起一个名字。

对于声明和使用命名的模板，提供了如下 3 种语法：

- `define`：在模板中声明一个新的命名的模板。
- `template`：导入（使用）一个命名模板。
- `block`：声明一个特殊的可填写的模板区域。

给模板起名需要注意：模板名称是全局的。如果有两个相同名称的模板，那么后加载的那个模板才会真正起作用。如何有效避免命名冲突呢？可以通过给每个模板都添加 Chart 名称，类似于 `{{ define "mychart.labels" }}`。

这里需要提一下关于 templates 目录下的文件命名，除了 `NOTES.txt` 文件和以下划线 `_` 开头的文件，其它文件都会被当做资源清单文件。以下划线开头的文件可以被 Chart 其它模块调用，可以把公共模块放到该文件下，也就是默认的 `_helpers.tpl` 文件。

#### 用 define 和 template 声明和使用模板

使用 `define` 可以在模板文件中创建一个命名模板，语法为：

```yaml
{{ define "MY.NAME" }}
  # body of template here
{{ end }}
```

比如我们可以定义一个模板封装 kubernetes 标签块。将这个模板嵌套进现有的 ConfigMap 中，并使用 `template` 关键字引用这个模板：

```yaml
# define 定义模板封装标签块，命名方式为 `Chart名称.模块名`，避免模板出现命名重复
{{- define "mychart.labels" }}
  labels:
    generator: helm
    date: {{ now | htmlDate }}
{{- end }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
  # template 引用前面定义好的模板
  {{- template "mychart.labels" }}
data:
  myvalue: "Hello World"
  {{- range $key, $val := .Values.favorite }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
```

当模板引擎读取这个文件时，它将会存储对于 `mychart.labels` 的引用直到使用 `template` 调用这个模板，然后它会在 template 所在行渲染这个模板。最终模板渲染的结果如下所示：

```yaml
...
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
  labels:
    generator: helm
    date: 2020-01-20
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "pizza"
```

当然，我们也可以把这些定义的模板放到 `templates/_helpers.tpl` 文件中，现在就将 `mychart.labels` 模板移入文件中：

```yaml
{{/* Generate basic labels */}}  # 文档块，描述这个模板的作用
{{- define "mychart.labels" }}
  labels:
    generator: helm
    date: {{ now | htmlDate }}
{{- end }}
```

#### 设置模板的范围

对于命名的模板，它在被 template 调用时需要传入一个作用域。

比如我们想要在 `mychart.labels` 模板中也打印出 Chart 的名称和版本号，正确的模板定义方法为如下所示：

```yaml
{{/* Generate basic labels */}}
{{- define "mychart.labels" }}
  labels:
    generator: helm
    date: {{ now | htmlDate }}
    chart: {{ .Chart.Name }}      # 获取 Chart 的名称
    version: {{ .Chart.Version }} # 获取 Chart 的版本号
{{- end }}
```

然后在 configmap.yaml 文件中引用模板：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
  # 在模板调用的末尾传入 .，表示当前最顶层作用范围
  {{- template "mychart.labels" . }}
```

执行渲染：

```yaml
...
metadata:
  name: test-configmap
  labels:
    generator: helm
    date: 2020-01-20
    chart: mychart
    version: 0.1.0
```

#### include 函数

现在我们定义一个简单的模板，放到 `_helpers.tpl` 文件中，如下所示（纯键值对形式，没有格式）：

```yaml
{{- define "mychart.app" -}}
app_name: {{ .Chart.Name }}
app_version: "{{ .Chart.Version }}"
{{- end -}}
```

然后将 `mychart.app` 模板分别插入到 `labels` 部分和 `data` 部分：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
  labels:
    {{ template "mychart.app" . }}
data:
  myvalue: "Hello World"
  {{- range $key, $val := .Values.favorite }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
{{ template "mychart.app" . }}
```

这样查看渲染模板其实会直接报错，因为会出现格式问题（主要是空格问题）。这时就需要使用 `include` 函数，它的主要作用是将模板的内容导入到当前管道中，然后在需要控制空格的地方使用 `indent` 管道函数进行控制。将上面的 ConfigMap 修改为如下所示：（在 `labels` 部分限制 4 个空格，在 `data` 部分限制 2 个空格）

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
  labels:
{{ include "mychart.app" . | indent 4 }}
data:
  myvalue: "Hello World"
  {{- range $key, $val := .Values.favorite }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
{{ include "mychart.app" . | indent 2 }}
```

现在渲染模板结果如下所示：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
  labels:
    app_name: mychart  # 正确的缩进
    app_version: "0.1.0"
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "pizza"
  app_name: mychart   # 正确的缩进
  app_version: "0.1.0"
```

## 4. 在模板中访问文件

在上一节中我们介绍了向一个模板导入另一个模板的方法。但是有的时候我们需要导入一个 File 文件而不是模板，也就是说不通过模板渲染器发送内容。

可以通过 `.Files` 对象访问文件，但是需要注意几点：

- 可以向 Helm Chart 添加额外的文件，这些文件也会被绑定发送给 kubernetes。但是由于 kubernetes 的存储限制，Chart 必须小于 1M。
- 出于安全考虑，有些文件不能通过 `.Files` 对象访问：
    - 在 `templates/` 目录下的文件不能被访问；
    - 使用 `.helmignore` 排除的文件不能被访问；
- Chart 并不保留 UNIX 模式信息，所以文件级别的权限不会影响 `.Files` 对象的访问。

#### 基础例子

我们编写一个模板，读取三个文件的内容到 ConfigMap 中。直接在 `mychart/` 目录下新建三个文件：

第一个文件 `config1.toml`：

```yaml
message = Hello from config 1
```

第二个文件 `config2.toml`：

```yaml
message = This is config 2
```

第一个文件 `config3.toml`：

```yaml
message = Goodbye from config 3
```

使用 `range` 函数遍历这三个文件，并将文件中的内容注入到 ConfigMap 中：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
data:
  {{- $files := .Files }}
  {{- range tuple "config1.toml" "config2.toml" "config3.toml" }}
  {{ . }}: |-
    {{ $files.Get . }}
  {{- end }}
```

在这里，使用 `$files` 变量存储对于 `.Files` 对象的引用，使用 `tuple` 函数创建我们循环访问的文件列表，`{{ . }}: |-` 表示打印出每个文件的名字，`{{ $files.Get . }}` 表示打印出对应文件名的内容。

渲染这个模板，结果如下所示：

```yaml
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
data:
  config1.toml: |-
    message = Hello from config 1

  config2.toml: |-
    message = This is config 2

  config3.toml: |-
    message = Goodbye from config 3
```

#### 路径助手

在处理文件的时候，有时会需要对文件路径本身执行一些标准操作。Helm 从 Go 的 [path](https://golang.org/pkg/path/) 包导入了很多函数加以使用，它们都可以使用 Go 包中的相同名称访问，但是使用时需要小写第一个字母，比如 `Base` 变成 `base`。

导入的函数有：`Base`、`Dir`、`Ext`、`IsAbs`、`Clean`。

#### Glob 模式

`Files.Glob(pattern string)` 可以批量化的提取更多符合指定 pattern 的文件。

`.Glob` 返回的是 `Files` 类型，所以在返回对象中可以调用 `Files` 的任何方法。

比如有如下的目录结构：

```text
foo/:
  foo.txt foo.yaml

bar/:
  bar.go bar.conf baz.yaml
```

利用 `.Glob` 可以使用多种方式访问上面的文件：

```yaml
{{ range $path := .Files.Glob "**.yaml" }}
{{ $path }}: |
{{ .Files.Get $path }}
{{ end }}
```

或是：

```yaml
{{ range $path, $bytes := .Files.Glob "foo/*" }}
{{ $path }}: '{{ b64enc $bytes }}'
{{ end }}
```

如果在 ConfigMaps 和 Secrets 中使用这些文件内容，可以 `AsConfig` 和 `AsSecrets` 方法，如下所示：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: conf
data:
{{ (.Files.Glob "foo/*").AsConfig | indent 2 }}
---
apiVersion: v1
kind: Secret
metadata:
  name: very-secret
type: Opaque
data:
{{ (.Files.Glob "bar/*").AsSecrets | indent 2 }}
```

如果想要对一个文件内容进行 Base64 编码，可以读取到文件内容后再传递给 `b64enc` 进行处理，比如：

```yaml
...
data:
  token: |-
    {{ .Files.Get "config1.toml" | b64enc }}
```

如果想要访问模板文件的每一行，可以使用 `Lines` 方法，比如：

```yaml
data:
  some-file.txt: {{ range .Files.Lines "foo/bar.txt" }}
    {{ . }}{{ end }}
```

但是对于 install 安装过程中提供的外部配置，依然只能使用 `helm install -f` 或是 `helm install --set` 进行加载。

## 5. 忽略不需要的文件和文件夹

`.helmignore` 文件可以明确指定不想要打包（`helm package`）进 Chart 的文件。

其中的语法支持 Unix shell 全局匹配、相对路径匹配以及使用 `!` 表示否定，每行只能填写一种模式。比如：

```yaml
# comment
.git
*/temp*
*/*/temp*
temp?
```

## 6. notes 文件

创建一个 `templates/NOTES.txt` 文件，可以在 install 安装或是 upgrade 更新完成时，打印出一些有用的信息。虽然 NOTES.txt 文件是纯文本文件，但是其中依然可以写模板语言。

比如创建一个简单的 `NOTES.txt` 文件如下所示：

```text
Thank you for installing {{ .Chart.Name }}.

Your release is named {{ .Release.Name }}.

To learn more about the release, try:

  $ helm status {{ .Release.Name }}
  $ helm get {{ .Release.Name }}
```

然后执行安装 `helm install test ./mychart`，在底部会看到如下信息：

```text
...
Thank you for installing mychart.

Your release is named test.

To learn more about the release, try:

  $ helm status test
  $ helm get test
```

## 7. 子 chart 和全局值

在前面的内容中，我们都只使用了一个 Chart，但是 Chart 是可以有依赖关系的，称为子 Chart（`subcharts`）。这些子 Chart 有它们自己的值和模板。

对于 subcharts 而言：

- 子 Chart 应该是相对独立的，它不能依赖父 Chart。
- 子 Chart 不能访问父 Chart 的值。
- 父 Chart 可以覆盖子 Chart 的值。
- Helm 可以有全局值，这个值可以被所有 Chart 访问。

#### 创建一个子 Chart

在 `mychart/` 目录下新创建一个子 Chart：

```bash
$ cd mychart/charts
$ helm create mysubchart
Creating mysubchart
$ rm -rf mysubchart/templates/*
```

#### 在子 Chart 中添加 Values 和模板

修改 `mychart/charts/mysubchart/values.yaml` 文件如下所示：

```yaml
dessert: cake
```

新建 `mychart/charts/mysubchart/templates/configmap.yaml` 文件并写入如下内容：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-cfgmap2
data:
  dessert: {{ .Values.dessert }}
```

渲染子 Chart 进行测试：

```bash
$ helm install --debug --dry-run test mychart/charts/mysubchart
...
# Source: mysubchart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-cfgmap2
data:
  dessert: cake
```

#### 覆盖子 Chart 的值

现在的层级关系是：`mychart` 是 `mysubchart` 的父 Chart，因为 `mysubchart` 在 `mychart/charts` 目录中。

由于 `mychart` 是父级，我们可以在 `mychart` 中配置覆盖 `mysubchart` 中的值。

在 `mychart/values.yaml` 文件的末尾添加如下所示的内容：

```yaml
...

mysubchart:  # 在 mysubchart 块中配置的值会直接发送给 mysubchart 包
  dessert: ice cream
```

如果执行安装 `helm install --dry-run --debug test mychart`，可以看到 `mysubchart` 的 ConfigMap 为：

```yaml
...
# Source: mychart/charts/mysubchart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-cfgmap2
data:
  dessert: ice cream
...
```

这就表示在父 Chart 中配置的值已经生效。

#### 全局 Chart 值

有时我们希望一些值在所有模板中都可以使用，这时就需要使用全局 Chart 值了。全局值是可以从 Chart 或子 Chart 中使用相同名称进行访问的值，使用 `Values.global` 就可以设置。

在 `mychart/values.yaml` 文件的末尾添加如下所示的内容：

```yaml
...

global:
  salad: caesar
```

这样在任意的模板中都可以通过 `{{.Values.global.salad}}` 访问全局值。

修改 `mychart/templates/configmap.yaml` 中的内容为如下所示：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
data:
  salad: {{ .Values.global.salad }}
```

修改 `mysubchart/templates/configmap.yaml` 中的内容为如下所示：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-cfgmap2
data:
  dessert: {{ .Values.dessert }}
  salad: {{ .Values.global.salad }}
```

运行 install，输出如下：

```bash
...
# Source: mychart/charts/mysubchart/templates/configmap.yaml
...
  dessert: ice cream
  salad: caesar
---
# Source: mychart/templates/configmap.yaml
...
data:
  salad: caesar
...
```

## 8. 实验总结

本次实验我们向大家介绍了如下知识点：

- 变量
- 命名模板
- 在模板中访问文件
- 忽略不需要的文件和文件夹
- notes 文件
- 子 chart 和全局值

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。

