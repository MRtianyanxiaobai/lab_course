---
show: step
version: 1.0
---

# Prometheus + Grafana + Alertmanager 搭建集群监控系统

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍使用 Prometheus + Grafana + Alertmanager 搭建集群监控系统。

####  实验知识点

- Prometheus 简介
- Prometheus 和 Grafana 简单上手
- 安装 Prometheus 和 Grafana
- 创建监控集群
- 测试--访问 Grafana 服务
- 测试--访问 Grafana 服务
- 测试--访问 Alertmanager 服务

####  推荐阅读

- [Prometheus](https://prometheus.io/docs/introduction/overview/)
- [Grafana](https://grafana.com/docs/grafana/latest/guides/getting_started/)
- [kubernetes-mixin](https://github.com/kubernetes-monitoring/kubernetes-mixin)
- [Alertmanager cinfiguration](https://prometheus.io/docs/alerting/configuration/)
- [How to setup Grafana for high availability](https://grafana.com/docs/grafana/latest/tutorials/ha_setup/)
- [addon-resizer](https://github.com/kubernetes/autoscaler/tree/master/addon-resizer)

## 2. Prometheus 简介

Prometheus 是一个开源监控系统，它前身是 [SoundCloud](http://soundcloud.com/) 的告警工具。自 2012 年开始，许多公司和组织陆续开始使用它。目前 Prometheus 已经独立为一个开源项目，不属于任何公司。Prometheus 在 2016 年继 [Kurberntes](http://kubernetes.io/) 之后，加入了 [云原生基金会](https://cncf.io/)（CNCF，Cloud Native Computing Foundation）。

#### 主要特性

- 多维度数据模型
- 灵活的查询语言
- 不依赖任何分布式存储
- 常见方式是通过拉取方式采集数据
- 也可通过中间网关支持推送方式采集数据
- 通过服务发现或者静态配置来发现监控目标
- 支持多种图形界面展示方式

#### 架构

下面这张图描述了 Prometheus 的整体架构，以及其生态中的一些常用组件。

![此处输入图片的描述](https://doc.shiyanlou.com/document-uid606277labid5950timestamp1530862369613.png/wm)

Prometheus Server 采用拉取方式从监控目标直接拉取数据，或者通过中间网关间接地拉取监控目标推送给网关的数据。它在本地存储抓取的数据，通过一定规则进行清理和整理数据，然后把得到的结果存储起来。各种 Web UI 使用 PromQL 查询语言来从 Server 里获取数据。当 Server 监测到有异常时会推送告警给 Alertmanager，Alertmanager 负责去通知相关人。

###  Prometheus 核心概念

下面我们将会学习 Prometheus 核心概念。

###  数据模型

Prometheus 从根本上存储的所有数据都是时间序列数据（Time Serie Data，简称时序数据）。时序数据是具有时间戳的数据流，该数据流属于某个度量指标（Metric）和该度量指标下的多个标签（Label）。除了提供存储功能，Prometheus 还可以利用查询表达式来执行非常灵活和复杂的查询。

#### .1 度量指标和标签

每个时间序列（Time Serie，简称时序）由度量指标和一组标签键值对唯一确定。

度量指标名称描述了被监控系统的某个测量特征（比如 http_requests_total 表示 http 请求总数）。度量指标名称由 ASCII 字母、数字、下划线和冒号组成，须匹配正则表达式 `[a-zA-Z_:][a-zA-Z0-9_:]*`。

标签开启了 Prometheus 的多维数据模型。对于同一个度量指标，不同标签值组合会形成特定维度的时序。Prometheus 的查询语言可以通过度量指标和标签对时序数据进行过滤和聚合。改变任何度量指标上的任何标签值，都会形成新的时序。标签名称可以包含 ASCII 字母、数字和下划线，须匹配正则表达式 `[a-zA-Z_][a-zA-Z0-9_]*`，带有 _ 下划线的标签名称保留为内部使用。标签值可以包含任意 Unicode 字符，包括中文。

#### .2. 采样值（Sample）

时序数据其实就是一系列采样值。每个采样值包括：

- 一个 64 位的浮点数值
- 一个精确到毫秒的时间戳

#### .3. 注解（Notation）

一个注解由一个度量指标和一组标签键值对构成。形式如下：

```text
[metric name]{[label name]=[label value], ...}
```

例如，度量指标为 api_http_requests_total，标签为 method="POST"、handler="/messages" 的注解表示如下：

```text
api_http_requests_total{method="POST", handler="/messages"}
```

###  度量指标类型

Prometheus 里的度量指标有以下几种类型。

#### .1 计数器（Counter）

计数器是一种累计型的度量指标，它是一个只能递增的数值。计数器主要用于统计类似于服务请求数、任务完成数和错误出现次数这样的数据。

#### .2 计量器（Gauge）

计量器表示一个既可以增加, 又可以减少的度量指标值。计量器主要用于测量类似于温度、内存使用量这样的瞬时数据。

#### .3 直方图（Histogram）

直方图对采样值（通常是请求持续时间或者响应大小这样的数据）按桶进行统计，每个桶代表一个采样值区间。有以下几种方式来产生直方图（假设度量指标为 \<basename>）：

- 按桶计数，相当于 `<basename>_bucket{le="<upper inclusive bound>"}`，也就是采样值小于等于指定上限值的次数
- 采样值总和，相当于 `<basename>_sum`，也就是当前采样值集合里所有采样值的总和
- 采样值总数，相当于 `<basename>_count` ，也就是当前采样值集合里所有采样值的总数，等同于把所有采样值放到一个桶里来计数 `<basename>_bucket{le="+Inf"}`

#### .4 汇总（Summary）

类似于直方图，汇总也对观察结果进行统计。它除了可以统计采样值总和和总数，还能够按分位数统计。有以下几种方式来产生汇总（假设度量指标为 \<basename>）：

- φ 分位值，相当于 `<basename>{quantile="<φ>"}`，也就是该采样值排在当前采样值集合的第 `<basename>_count * φ` 位
- 采样值总和，相当于 `<basename>_sum`
- 采样值总数，相当于 `<basename>_count`

###  任务（Job）和实例（Instance）

在 Prometheus 里，可以从中抓取采样值的端点称为实例，为了扩展服务性能而复制出来的多个这样的服务实例就形成了一个任务。

例如下面的 api-server 任务有四个等同的实例：

```text
job: api-server
instance 1: 1.2.3.4:5670
instance 2: 1.2.3.4:5671
instance 3: 5.6.7.8:5670
instance 4: 5.6.7.8:5671
```

Prometheus 抓取完采样值后，会自动给采样值打上以下标签：

- job: 所属任务。
- instance: 所属实例

另外每次抓取时，Prometheus 还会自动在以下时序里插入采样值：

- `up{job="[job-name]", instance="instance-id"}`：采样值为 1 表示实例健康，否则为不健康
- `scrape_duration_seconds{job="[job-name]", instance="[instance-id]"}`：采样值为本次抓取消耗时间
- `scrape_samples_post_metric_relabeling{job="<job-name>", instance="<instance-id>"}`：采样值为重新打标签的采样值个数
- `scrape_samples_scraped{job="<job-name>", instance="<instance-id>"}`：采样值为本次抓取到的采样值个数

## 3. Prometheus 和 Grafana 简单上手

Grafana 是一个开源的、漂亮的数据分析和监控平台，也是时序数据分析工具的领头羊。它支持非常多的数据源，截止到目前包括 Prometheus 在内共有 40 多种。使用它可以将企业里存储在各个地方的数据汇总到一个地方来进行分析和监控。

下面我们先在环境中本地安装 Prometheus 和 Grafana，进行一个简单的上手测试。

首先在环境中安装 Prometheus：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1502/prometheus-2.15.2.linux-amd64.tar.gz
tar xvfz prometheus-2.15.2.linux-amd64.tar.gz
cd prometheus-*
# 在 prometheus.yml 文件中已经配置好监控它自己
./prometheus --config.file=prometheus.yml
```

然后在浏览器访问 `http://localhost:9090`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578626732915/wm)

任意选择一个度量指标查看它们的值：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578627127219/wm)

点击顶部导航栏上的 `Status --> Targets`，可以查看正在获取数据的端口：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578626940899/wm)

然后安装 Grafana：

```bash
wget https://labfile.oss.aliyuncs.com/courses/1502/grafana_6.5.2_amd64.deb
sudo dpkg -i grafana_6.5.2_amd64.deb
sudo service grafana-server start
```

Grafana 服务启动之后，默认会在本地 3000 端口上监听，打开 `http://localhost:3000/` 可访问其 Web 控制台。首次访问需要登录，默认的管理员账号/密码为 `admin/admin`。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578635145066/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578635360381/wm)

登录完成后会进入到 Home 页，里面显示安装已完成，接下来需要 `Add data source`。在 `Time series databases` 中选择 `Prometheus`（直接使用默认的配置即可）：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578635685868/wm)

点击左侧导航栏 `Dashboards --> Home`，然后 `New dashboard`，在创建的 Panel 中先选择 `Add Query`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578636066556/wm)

然后在 `Queries` 中进行设置，选择 Query 数据源为 Prometheus，在 Metrics 中添加 `rate(prometheus_http_requests_total[5m])`，就可以看到与 HTTP 请求统计相关的时间序列数据在上方图表中展示出来：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200110-1578636388566/wm)

这样一个简单的可视化图表就制作出来啦。

## 4. 安装 Prometheus 和 Grafana

对于 kubernetes 集群的监控而言，非常重要的就是配置监控和报警服务。监控的主要作用在于查看集群各种资源的使用率、分析并解决应用出现的各种报错。一个监控系统是由时间序列化数据库组成，通常包括时间度量数据部分和可视化部分，有时还有警报部分，用于出现某些异常及时报警。

目前流行的监控方案是使用 `Prometheus + Grafana + Alertmanager`，额外再搭配 `kube-state-metrics + node-exporter` 共同进行部署，这样不仅可以监控机器级别的资源（比如：CPU、内存使用率等），还可以自定义监控 kubernetes 各种对象的数据。

想要搭建好监控系统，需要配置各个独立的组件（包括：Prometheus metrics 和 Grafana dashboards 等），这里我们预先配置好监控警报和仪表盘（所有的配置都写入 YAML 文件中），只需要执行部署即可。本次实验中使用的存储卷是本地持久存储卷（Local PV），大家后续可以根据实际情况对文件进行修改重新部署。

首先下载本次实验所需要的全部文件：

```bash
$ wget https://labfile.oss.aliyuncs.com/courses/1502/pg.zip
$ unzip pg.zip
$ cd pg
$ ls
alertmanager-0serviceaccount.yaml   grafana-configmap.yaml                   node-exporter-0serviceaccount.yaml
alertmanager-configmap.yaml         grafana-secret.yaml                      node-exporter-ds.yaml
alertmanager-operated-service.yaml  grafana-service.yaml                     prometheus-0serviceaccount.yaml
alertmanager-service.yaml           grafana-statefulset.yaml                 prometheus-configmap.yaml
alertmanager-statefulset.yaml       kube-state-metrics-0serviceaccount.yaml  prometheus-service.yaml
dashboards-configmap.yaml           kube-state-metrics-deployment.yaml       prometheus-statefulset.yaml
grafana-0serviceaccount.yaml        kube-state-metrics-service.yaml
```

这里主要包括 5 个部件：`Prometheus`、`Alertmanager`、`Grafana`、`kube-state-metrics` 和 `node-exporter`。

下面简单说明各个 YAML 文件的作用：

#### Prometheus

Prometheus 是一个时间序列数据库和监控工具，通过轮询 metrics 端点获取采集到的公开数据，可以使用时间序列查询语言 PromQL 查询数据。在本实验中使用 StatefulSet 部署有两个副本的 Prometheus，使用本地存储卷，并使用 ConfigMap 存储 alerts、rules、jobs 的各种预配置信息。

- `prometheus-0serviceaccount.yaml`：主要创建了 prometheus 服务账户、集群角色和集群角色绑定。
- `prometheus-configmap.yaml`：使用 ConfigMap 存储的配置文件信息，包括 3 个配置文件：
    - `alerts.yaml`：由 kubernetes-mixin 提供的预先配置好的报警设置。
    - `rules.yaml`：一系列 prometheus 记录规则，包括一些经常使用到的计算表达式，并将结果保存为新的时间序列。
    - `prometheus.yaml`：prometheus 主配置文件。
- `prometheus-service.yaml`：暴露 prometheus Pod 的服务。
- `prometheus-statefulset.yaml`：采用 StatefulSet 部署 prometheus，在这里部署了 2 个副本，大家也可以根据需要进行修改。

#### Alertmanager

Alertmanager 通常和 Prometheus 搭配使用进行报警配置，主要用于处理 Prometheus 生成的警报，并进行去重、分组、最后将警报继承到 email 或 PagerDuty 中。在本实验中使用 StatefulSet 部署具有两个副本的 Alertmanager，使用本地存储卷。

- `alertmanager-0serviceaccount.yaml`：alertmanager 服务账户，主要用于给 Alertmanager Pod 身份认证。
- `alertmanager-configmap.yaml`：使用 ConfigMap 存储 minimal Alertmanager 配置文件信息。
- `alertmanager-operated-service.yaml`：Alertmanager 服务网格，主要用于路由 Alertmanager Pods 之间的请求，以形成高可用配置。
- `alertmanager-service.yaml`：Alertmanager Web 服务，方便其他服务调用。
- `alertmanager-statefulset.yaml`：采用 StatefulSet 部署 alertmanager，在这里部署了 2 个副本，大家也可以根据需要进行修改。

#### Grafana

Grafana 是一个数据可视化分析工具，可以为 Prometheus 采集到的数据构建仪表盘和图表。在本实验中采用 StatefulSet 部署一个副本的 Grafana，使用本地存储卷。

- `dashboards-configmap.yaml`：使用 ConfigMap 存储已经配置好的、使用 JSON 表示的 Grafana 监控面板。依然使用的是 kubernetes-mixin 插件。
- `grafana-0serviceaccount.yaml`：grafana 服务账户。
- `grafana-configmap.yaml`：使用 ConfigMap 存储 minimal Grafana 配置文件信息。
- `grafana-secret.yaml`：使用 Secret 存储的 Grafana 账户信息，默认账户名为 admin，密码可以自己配置。
- `grafana-service.yaml`：配置 Grafana 服务。
- `grafana-statefulset.yaml`：采用 StatefulSet 部署 Grafana，在这里部署了 1 个副本，大家也可以根据需要进行修改。

#### kube-state-metrics

kube-state-metrics 是一个附加代理组件，主要用于监听 Kubernetes API Server 并生成关于集群资源对象的相关数据（比如 Deployments、Pods 等）。这些数据在公开的 HTTP 端口提供给 Prometheus 使用。在本实验中，使用 Deployment 部署一个副本的 kube-state-metrics，并配置为动态可伸缩。

- `kube-state-metrics-0serviceaccount.yaml`：kube-state-metrics 服务账户、集群角色和集群角色绑定。
- `kube-state-metrics-deployment.yaml`：使用 Deployment 部署 kube-state-metrics，在这里部署了 1 个副本，同时使用 addon-resizer 插件部署副本为动态可伸缩的。
- `kube-state-metrics-service.yaml`：暴露 kube-state-metrics Pod 的服务。

#### node-exporter

node-exporter 也是一个附加组件，主要是运行在集群各个 Node 节点上提供关于操作系统和硬件的相关数据（比如 CPU、内存使用率等），数据提供方式与 kube-state-metrics 相同。在本实验中，使用 DaemonSet 部署 node-exporter。

除了上述提到的 kube-state-metrics 和 node-exporter 组件，Prometheus 还可以从 `kube-apiserver`、`kubelet`、`cAdvisor` 等组件中获取关于集群的相关数据。

- `node-exporter-0serviceaccount.yaml`：node-exporter 服务账户。
- `node-exporter-ds.yaml`：使用 DaemonSet 部署 node-exporter，在集群中的每个 Node 节点都会运行一个 node-exporter Pod。

#### 本地存储卷

- `local-pv.yaml`：为 Prometheus、Alertmanager 和 Grafana 在每个节点都配置了本地存储卷。这个卷是根据实验环境具体设置的，大家如果需要使用到其它环境可以直接修改存储卷配置即可。

###  创建监控集群

在我们的配置文件中预先留了 3 个变量给大家用于自定义，这 3 个变量是实例名称、命名空间和 Grafana 的密码，先在环境中设置这 3 个变量的值：

```bash
# 设置实例名称，这个名称将被添加到所有监控对象名称开头
$ export APP_INSTANCE_NAME=shiyanlou-cluster-monitoring
# 设置使用的命名空间，这里使用 default
$ export NAMESPACE=default
# 自定义 Grafana 的密码，这里我用 123456 替代 your_grafana_password，并使用 base64 进行编码
$ export GRAFANA_GENERATED_PASSWORD="$(echo -n 'your_grafana_password' | base64)"
```

使用 awk 和 envsubst 将 pg 文件夹下所有包含 `APP_INSTANCE_NAME`、`NAMESPACE`、`GRAFANA_GENERATED_PASSWORD` 环境变量的文件进行替换。替换完成以后将所有文件内容保存到 `shiyanlou-cluster-monitoring_manifest.yaml` 文件中：

```bash
awk 'FNR==1 {print "---"}{print}' pg/* \
 | envsubst '$APP_INSTANCE_NAME $NAMESPACE $GRAFANA_GENERATED_PASSWORD' \
 > "${APP_INSTANCE_NAME}_manifest.yaml"
```

替换成功后，现在就可以执行创建：

```bash
$ kubectl apply -f "${APP_INSTANCE_NAME}_manifest.yaml" --namespace "${NAMESPACE}"
storageclass.storage.k8s.io/local-storage-grafana created
persistentvolume/local-pv-grafana-1 created
persistentvolume/local-pv-grafana-2 created
storageclass.storage.k8s.io/local-storage-prometheus created
persistentvolume/local-pv-prometheus-1 created
persistentvolume/local-pv-prometheus-2 created
serviceaccount/alertmanager created
configmap/shiyanlou-cluster-monitoring-alertmanager-config created
service/shiyanlou-cluster-monitoring-alertmanager created
service/shiyanlou-cluster-monitoring-alertmanager unchanged
statefulset.apps/shiyanlou-cluster-monitoring-alertmanager created
configmap/shiyanlou-cluster-monitoring-dashboards created
serviceaccount/grafana created
configmap/shiyanlou-cluster-monitoring-grafana-ini created
configmap/shiyanlou-cluster-monitoring-grafana-datasources created
configmap/shiyanlou-cluster-monitoring-grafana-dashboardproviders created
secret/shiyanlou-cluster-monitoring-grafana created
service/shiyanlou-cluster-monitoring-grafana created
statefulset.apps/shiyanlou-cluster-monitoring-grafana created
serviceaccount/kube-state-metrics created
clusterrole.rbac.authorization.k8s.io/kube-state-metrics created
clusterrolebinding.rbac.authorization.k8s.io/kube-state-metrics created
deployment.apps/shiyanlou-cluster-monitoring-kube-state-metrics created
service/shiyanlou-cluster-monitoring-kube-state-metrics created
serviceaccount/node-exporter created
daemonset.apps/shiyanlou-cluster-monitoring-node-exporter created
serviceaccount/prometheus created
clusterrole.rbac.authorization.k8s.io/prometheus created
clusterrolebinding.rbac.authorization.k8s.io/prometheus created
configmap/shiyanlou-cluster-monitoring-prometheus-config created
service/shiyanlou-cluster-monitoring-prometheus created
statefulset.apps/shiyanlou-cluster-monitoring-prometheus created
```

首先查看关于存储相关的资源对象：

```bash
# 查看 storageclass
$ kubectl get storageclass
NAME                         PROVISIONER                    RECLAIMPOLICY   VOLUMEBINDINGMODE      ALLOWVOLUMEEXPANSION   AGE
local-storage-alertmanager   kubernetes.io/no-provisioner   Delete          WaitForFirstConsumer   false                  18s
local-storage-grafana        kubernetes.io/no-provisioner   Delete          WaitForFirstConsumer   false                  18s
local-storage-prometheus     kubernetes.io/no-provisioner   Delete          WaitForFirstConsumer   false                  18s
# 查看 PV
$ kubectl get pv
NAME                      CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM   STORAGECLASS                 REASON   AGE
local-pv-alertmanager-1   5Gi        RWO            Retain           Available           local-storage-alertmanager            84s
local-pv-alertmanager-2   5Gi        RWO            Retain           Available           local-storage-alertmanager            84s
local-pv-grafana-1        5Gi        RWO            Retain           Available           local-storage-grafana                 84s
local-pv-grafana-2        5Gi        RWO            Retain           Available           local-storage-grafana                 84s
local-pv-prometheus-1     20Gi       RWO            Retain           Available           local-storage-prometheus              84s
local-pv-prometheus-2     20Gi       RWO            Retain           Available           local-storage-prometheus              84s
```

查看所有资源对象是否创建成功：

```bash
$ kubectl get all
NAME                                                                  READY   STATUS    RESTARTS   AGE
pod/shiyanlou-cluster-monitoring-alertmanager-0                       1/1     Running   0          2m22s
pod/shiyanlou-cluster-monitoring-alertmanager-1                       1/1     Running   0          63s
pod/shiyanlou-cluster-monitoring-grafana-0                            1/1     Running   0          2m21s
pod/shiyanlou-cluster-monitoring-kube-state-metrics-6f69f76cbb25ffr   2/2     Running   0          2m21s
pod/shiyanlou-cluster-monitoring-node-exporter-clnww                  1/1     Running   0          2m21s
pod/shiyanlou-cluster-monitoring-node-exporter-vqn6x                  1/1     Running   0          2m21s
pod/shiyanlou-cluster-monitoring-prometheus-0                         1/1     Running   0          2m21s
pod/shiyanlou-cluster-monitoring-prometheus-1                         1/1     Running   0          2m20s


NAME                                                         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)             AGE
service/kubernetes                                           ClusterIP   10.96.0.1        <none>        443/TCP             143d
service/shiyanlou-cluster-monitoring-alertmanager            ClusterIP   10.111.168.124   <none>        9093/TCP            2m22s
service/shiyanlou-cluster-monitoring-alertmanager-operated   ClusterIP   None             <none>        6783/TCP,9093/TCP   2m22s
service/shiyanlou-cluster-monitoring-grafana                 ClusterIP   10.102.9.170     <none>        80/TCP              2m22s
service/shiyanlou-cluster-monitoring-kube-state-metrics      ClusterIP   10.101.15.99     <none>        8080/TCP,8081/TCP   2m21s
service/shiyanlou-cluster-monitoring-prometheus              ClusterIP   10.98.71.137     <none>        9090/TCP            2m21s

NAME                                                        DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
daemonset.apps/shiyanlou-cluster-monitoring-node-exporter   2         2         2       2            2           <none>          2m21s

NAME                                                              READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/shiyanlou-cluster-monitoring-kube-state-metrics   1/1     1            1           2m21s

NAME                                                                         DESIRED   CURRENT   READY   AGE
replicaset.apps/shiyanlou-cluster-monitoring-kube-state-metrics-6f69f76cbb   1         1         1       2m21s

NAME                                                         READY   AGE
statefulset.apps/shiyanlou-cluster-monitoring-alertmanager   2/2     2m22s
statefulset.apps/shiyanlou-cluster-monitoring-grafana        1/1     2m22s
statefulset.apps/shiyanlou-cluster-monitoring-prometheus     2/2     2m21s
```

到这里就创建好了所有需要的资源对象。接下来就是可以访问对应的端口查看是否能够正常运行。

###  测试--访问 Grafana 服务

访问 Grafana 服务可以创建负载均衡器，我们这里只是测试，直接本地端口转发即可。

使用 port-forward 将对于本地 3000 端口的访问转发给 Grafana Pod：

```bash
$ kubectl port-forward shiyanlou-cluster-monitoring-grafana-0 3000
Forwarding from 127.0.0.1:3000 -> 3000
```

在浏览器访问 `http://localhost:3000`：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578469261905/wm)

登录的用户名为 admin，密码为前面设置的密码，在这里就是 123456。

登录后的主页面如下图所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578469390850/wm)

点击左侧边栏的 `Dashboards -> Manage`，可以看到如下的管理界面，这里列出的条目是我们在 `dashboards-configmap.yaml` 文件中定义的配置项：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578469803833/wm)

这些 Dashboards 界面是使用 `kubernetes-mixin` 插件产生的，这个插件可以产生一系列标准化的集群监控界面和 Prometheus 报警设置。

点击 `Kubernetes/Nodes` Dashboard，可以看到对于一个具体的 Node（这里是 kube-node-1），可视化了该节点的 CPU、内存、硬盘、网络出入量等指标：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578470341428/wm)

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578470395202/wm)

比如我们可以再看查看关于集群整个资源的使用，选择 `Kubernetes/Compute Resources/Cluster` Dashboard：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578471149908/wm)

如果大家想要了解更多关于 Grafana 的使用，可以参考 [Getting started](https://grafana.com/docs/grafana/latest/guides/getting_started/)。

###  访问 Prometheus 服务

依然采用端口转发的形式进行访问，将访问本地 9090 端口的请求转发给 Prometheus Pod：

```bash
$ kubectl port-forward shiyanlou-cluster-monitoring-prometheus-0 9090
Forwarding from 127.0.0.1:9090 -> 9090
```

现在对于本地 9090 端口的访问成功转发到了 Prometheus Pod。在浏览器上访问 `http://localhost:9090` 界面如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578472055747/wm)

可以使用 PromQL 查看存储在数据库中的时间序列数据，大家可以参考 [QUERYING PROMETHEUS](https://prometheus.io/docs/prometheus/latest/querying/basics/)。

在 Expression 字段中，填写 `kubelet_node_name` 然后点击 Execute 可以查看已经配置 prometheus 的 Node 信息：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578473095453/wm)

在顶部导航栏依次点击 `Status -> Targets` 查看配置的监控对象：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578473443888/wm)

###  测试--访问 Alertmanager 服务

现在我们来查看 Alertmanager，依然使用端口转发的方式，将本地的 9093 端口转发到 Alertmanager Pod：

```bash
$ kubectl port-forward shiyanlou-cluster-monitoring-alertmanager-0 9093
Forwarding from 127.0.0.1:9093 -> 9093
```

这样本地的 9093 端口成功转发到了 Alertmanager Pod，在浏览器上访问 `http://localhost:9093` 可以看到 Alertmanager Alerts 页面如下所示：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200108-1578476207530/wm)

大家可以在这个页面配置报警，更多的配置选项可以参考 [ALERTMANAGER](https://prometheus.io/docs/alerting/alertmanager/)。

这样一个基本的集群监控系统就搭建好啦，大家可以自行尝试更多的操作。

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Prometheus 简介
- Prometheus 和 Grafana 简单上手
- 安装 Prometheus 和 Grafana
- 创建监控集群
- 测试--访问 Grafana 服务
- 测试--访问 Grafana 服务
- 测试--访问 Alertmanager 服务

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
