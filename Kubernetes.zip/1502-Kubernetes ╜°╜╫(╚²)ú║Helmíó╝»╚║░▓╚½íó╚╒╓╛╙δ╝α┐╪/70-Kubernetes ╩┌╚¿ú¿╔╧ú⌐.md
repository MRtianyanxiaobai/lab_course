---
show: step
version: 1.0
---

# Kubernetes 授权

## 1.实验介绍

####  实验内容

本次实验主要向大家介绍 kubernetes 授权。授权是指授予不同的账户不同的访问权限。通过 API Server 的启动参数 `--authorization-mode` 进行设置。

####  实验知识点

- Kubernetes 授权简介
- RBAC 授权模式

####  推荐阅读

- [Authorization Overview](https://kubernetes.io/docs/reference/access-authn-authz/authorization/)
- [Using RBAC Authorization](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)

## 2. Kubernetes 授权简介

在 Kubernetes 早期的版本中，如果你通过某种方式从集群中的一个 Pod 获得了 token，就可以在集群中使用这个 token 执行任何操作。所以从 Kubernetes1.8.0 版本开始，为了提高集群的安全性，RBAC 授权插件在集群上是默认开启的，RBAC 会阻止未授权的账户查看和修改集群状态。只有授权 ServiceAccount 额外的权限才有查看和修改的能力。

在 kubernetes 集群中也可以配置多个授权插件，只要其中一个授权插件验证通过，就算是通过了集群的授权。具体流程如下：

API Server 接收请求，读取请求数据中的多种属性，生成一个访问策略对象，对于没有的属性设置为默认值。然后将访问策略对象与授权插件中的所有访问策略对象进行逐条匹配，只要有一个策略对象匹配成功，那么该请求就通过了授权，否则就会终止调用流程并返回客户端错误码。

访问策略对象包含的属性有：

- `user、group、extra`
- `API、请求方法（get、post、update、patch、delete）、请求路径（/api）`
- `请求资源和子资源`
- `Namespace`
- `API Group`

目前 API Server 支持的授权策略如下：

- `AlwaysDeny`：拒绝所有请求，一般用于测试。
- `AlwaysAllow`：允许接收所有请求，当集群不需要授权时，采用这个策略。
- `ABAC`：Attribute-Based Access Control，基于属性的访问控制，使用账户配置的授权规则对账户请求进行匹配和控制。
- `Webhook`：调用外部 REST 服务对账户进行授权。
- `RBAC`：Role-Based Access Control，基于角色的访问控制。
- `Node`：对 kubelet 发出的请求进行访问控制。

其中，Node 和 RBAC 是默认开启的策略。

## 3. RBAC 授权模式

RBAC 授权模式是 kubernetes 系统最常用的、默认的授权模式，这里我们将会对 RBAC 进行详细讲解。

使用 RBAC 授权模式的好处在于：

- 覆盖很完整，包括集群中的资源和非资源权限；
- 使用 4 个 API 对象就可以完成对于 RBAC 授权模式的定义；
- 调整了授权模式以后，不需要重新启动 API Server。

###  RBAC 授权插件

Kubernetes API 服务器使用授权插件检查是否允许账户请求的动作执行，API 服务器接口设置为 RESTful 风格，账户通过向服务器发送 HTTP 请求来执行动作，在请求中会包含认证凭证来进行认证（比如：认证 token、账户名和密码或者客户端证书）。

RESTful 风格是什么样的呢？简单解释一下：RESTful 风格的 URL 构成是`请求动作+资源路径`，客户端发送 GET、POST、PUT、DELETE 和其他类型的 HTTP 请求到特定的路径，这些路径表示的是特定的 REST 资源（也有一些不代表资源的 URL 路径）。

比如这里举一个例子：

Kubernetes 的一些常用请求动作：

- 获取 Pod(get pod)：动词 get 映射到 HTTP 方法上为 GET，名词 pod 为 Kubernetes 上的资源
- 创建服务(create service)：动词 create 映射到 HTTP 方法上为 POST，名词 service 为 Kubernetes 上的资源
- 更新密钥(update secret)：动词 update 映射到 HTTP 方法上为 PUT，名词 secret 为 Kubernetes 上的资源

下面的表格展示的是认证动词和 HTTP 方法之间的映射关系：

| HTTP 方法 | 单一资源的动词 | 集合的动词 |
| -------- | ----------- | ---------- |
| GET、HEAD | get(watch 用于监听) | list(watch) |
| POST     | create | n/a |
| PUT      | update | n/a |
| PATCH    | patch  | n/a |
| DELETE   | delete | deletecollection |

RBAC 授权插件将账户角色作为决定账户是否能够执行操作的关键因素。账户（`一个 UserAccount`、`一个 ServiceAccount`、`一组 UserAccount`、或`一组 ServiceAccount`）需要与一个（或多个）角色关联才有权限执行对应的操作，每个角色被允许在特定的资源上执行特定的动作。如果账户没有某个角色，那么也就没有该角色所对应的动作权限。

通过创建 4 种特定的 Kubernetes 资源就可以完成使用 RBAC 插件进行管理授权，这 4 种资源又可以被分为两组：

- `Role`(角色）和 `ClusterRole`(集群角色)：它们确定了在资源上可以执行哪些动词。
- `RoleBinding`(角色绑定) 和 `ClusterRoleBinding`(集群角色绑定)：将角色绑定到特定的 UserAccounts、组或 ServiceAccounts 上。

简单的说，角色确定了可以执行哪些操作，而角色绑定确定了谁可以执行这些操作。

角色和角色绑定是`命名空间`的资源，集群角色和集群角色绑定是`集群级别`的资源。

###  Role 和 RoleBinding

首先要确保 RBAC 授权插件在集群中已经开启，并且是唯一配置生效的授权插件。

本次实验中我们在两个不同的命名空间运行具有相同名称的 Pod，每个 Pod 中运行一个基于 kubectl-proxy 镜像生成的容器，可以直接在容器中使用 `kubectl exec` 运行 `curl` 命令，代理会负责验证 HTTPS，进而可以观察 API 服务器的安全授权。

执行如下命令创建命名空间 foo 和 bar，并创建 Pod：

```bash
$ kubectl create namespace foo
namespace/foo created
$ kubectl run test --image=luksa/kubectl-proxy -n foo
deployment.apps/test created
$ kubectl create namespace bar
namespace/bar created
$ kubectl run test --image=luksa/kubectl-proxy -n bar
deployment.apps/test created
```

在一个终端中执行如下命令，在 foo 命名空间中运行 pod 中的 shell，然后验证 RBAC 是否有效的阻止了 pod 读取集群状态：

```bash
$ kubectl get pod -n foo
NAME                   READY     STATUS    RESTARTS   AGE
test-7f4f854d7-xbr8q   1/1       Running   0          59s

$ kubectl exec test-7f4f854d7-xbr8q -n foo -it sh
/ # curl localhost:8001/api/v1/namespaces/foo/services
{
  "kind": "Status",
  "apiVersion": "v1",
  "metadata": {

  },
  "status": "Failure",
  "message": "services is forbidden: User \"system:serviceaccount:foo:default\" cannot list services in the namespace \"foo\"",
  "reason": "Forbidden",
  "details": {
    "kind": "services"
  },
  "code": 403
}
```

然后新开一个终端执行如下命令，在 bar 命名空间中运行 pod 中的 shell：

```bash
$ kubectl get pod -n bar
NAME                   READY     STATUS    RESTARTS   AGE
test-7f4f854d7-zkl2j   1/1       Running   0          29s

$ kubectl exec test-7f4f854d7-zkl2j -n bar -it sh
/ # curl localhost:8001/api/v1/namespaces/foo/services
{
  "kind": "Status",
  "apiVersion": "v1",
  "metadata": {

  },
  "status": "Failure",
  "message": "services is forbidden: User \"system:serviceaccount:bar:default\" cannot list services in the namespace \"foo\"",
  "reason": "Forbidden",
  "details": {
    "kind": "services"
  },
  "code": 403
}
```

kubectl proxy 进程监听的地址为：`localhost:8001`，这个进程会接收请求并把请求发送给 API 服务器，并且以该命名空间中默认使用的 ServiceAccount 进行身份认证。根据响应结果可以看出权限验证失败了，RBAC 插件已生效，因为 ServiceAccount 默认是不能列出或是修改任何资源的。

Role 资源定义了哪些操作可以在哪些资源上执行，我们定义一个 Role，它允许账户获取并列出 foo 命名空间中的服务。

在 `/home/shiyanlou` 目录下新建 `service-reader.yaml` 文件并向其中写入如下代码：

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: foo
  name: service-reader
rules:
- apiGroups: [""]
  verbs: ["get", "list"]
  resources: ["services"]
```

在上面的这个代码中，namespace 表示的是 Role 所在的命名空间；因为获取的是 service，它是 apiGroup 中的核心资源，它是没有 apiGroup 名的，所以这里 apiGroups 为空；`verbs: ["get", "list"]` 表示的是通过名字获取(get) 独立的 Service 并且列出(list) 所有允许的服务；`resources: ["services"]` 表示需要获取的资源，注意资源都必须使用复数形式。

现在在 foo 命名空间中创建角色：

```bash
$ kubectl create -f service-reader.yaml -n foo
role.rbac.authorization.k8s.io/service-reader created
```

当然也可以使用 `kubectl create role` 命令创建 service-reader 角色，现在来创建 bar 命名空间中的角色：

```bash
$ kubectl create role service-reader --verb=get --verb=list --resource=service -n bar
role.rbac.authorization.k8s.io/service-reader created
```

接下来我们将角色绑定到 ServiceAccount 上，RoleBinding 资源就可以实现将角色绑定到主体上。

执行如下命令将角色绑定到 default ServiceAccount 上：

```bash
$ kubectl create rolebinding test --role=service-reader --serviceaccount=foo:default -n foo
rolebinding.rbac.authorization.k8s.io/test created
```

如果要绑定角色到一个账户上，可以使用 `--user` 参数指定账户名；如果要绑定到组，可以使用 `--group` 参数。

可以看到绑定已经成功，现在我们再尝试一次在 foo 命名空间中获取 pod 中的 service：

```bash
$ kubectl exec test-7f4f854d7-xbr8q -n foo -it sh
/ # curl localhost:8001/api/v1/namespaces/foo/services
{
  "kind": "ServiceList",
  "apiVersion": "v1",
  "metadata": {
    "selfLink": "/api/v1/namespaces/foo/services",
    "resourceVersion": "2886"
  },
  "items": []
}
```

现在 default ServiceAccount 就通过了 RBAC 授权插件的检查并能够成功获取数据了。

由于我们没有对 bar 命名空间执行任何绑定操作，所以这个命名空间依然是不能查看自己命名空间的 services 服务列表，那就更没有权限查看 foo 命名空间的服务列表。现在修改 foo 命名空间的 RoleBinding 并添加 bar 命名空间中的 default ServiceAccount。

执行如下命令：

```bash
$ kubectl edit rolebinding test -n foo
```

然后在列出的 subjects 下增加如下 3 行：

```yaml
subjects:
...
- kind: ServiceAccount
  name: default
  namespace: bar
```

现在尝试在 bar 命名空间下的容器中运行如下命令，查看是否能够列出 foo 命名空间中的服务：

```bash
$ kubectl exec test-7f4f854d7-zkl2j -n bar -it sh
/ # curl localhost:8001/api/v1/namespaces/bar/services
{
  "kind": "Status",
  "apiVersion": "v1",
  "metadata": {

  },
  "status": "Failure", # 由于 RoleBinding 的设置，依然不能查看 bar 命名空间下的服务列表
  "message": "services is forbidden: User \"system:serviceaccount:bar:default\" cannot list resource \"services\" in API group \"\" in the namespace \"bar\"",
  "reason": "Forbidden",
  "details": {
    "kind": "services"
  },
  "code": 403
}
/ # curl localhost:8001/api/v1/namespaces/foo/services
{
  "kind": "ServiceList",
  "apiVersion": "v1",
  "metadata": {      # 但是可以查看 foo 命名空间下的服务列表
    "selfLink": "/api/v1/namespaces/foo/services",
    "resourceVersion": "3111"
  },
  "items": []
}/
```

可以看到操作执行成功。

那么截止目前，我们的 RBAC 资源状态如下：

在 foo 命名空间中有一个 RoleBinding，它引用了相同命名空间下的 service-reader 角色，并且绑定了 foo 和 bar 命名空间中的 default ServiceAccount。

###  ClusterRole 和 ClusterRoleBinding

前面我们提到过 Role 和 RoleBinding 都是命名空间的资源，但是有一些特定的资源是不在命名空间中的，比如：Node、Namespace 等，API 服务器对外也暴露了一些不表示资源的 URL 路径，比如：`/healthz` 等，这个时候就需要 ClusterRole 了。

ClusterRole 是一种集群级别的资源，它允许访问没有命名空间的资源以及非资源型的 URL，也可以作为单个命名空间内部绑定的公共角色，这样可以避免在每个命名空间中定义相同的角色。

可以使用如下命令创建一个名为 `pv-reader` 的 ClusterRole：

```bash
$ kubectl create clusterrole pv-reader --verb=get,list --resource=persistentvolumes
clusterrole.rbac.authorization.k8s.io/pv-reader created
```

首先在 foo 命名空间下验证是否可以列出 PersistentVolume：

```bash
$ kubectl exec test-7f4f854d7-xbr8q -n foo -it sh
/ # curl localhost:8001/api/v1/persistentvolumes
{
  "kind": "Status",
  "apiVersion": "v1",
  "metadata": {

  },
  "status": "Failure",
  "message": "persistentvolumes is forbidden: User \"system:serviceaccount:foo:default\" cannot list persistentvolumes at the cluster scope",
  "reason": "Forbidden",
  "details": {
    "kind": "persistentvolumes"
  },
  "code": 403
}/
```

可以看到是不允许列出的，接下来我们创建 ClusterRoleBinding：

```bash
$ kubectl create clusterrolebinding pv-test --clusterrole=pv-reader --serviceaccount=foo:default
clusterrolebinding.rbac.authorization.k8s.io/pv-test created
```

现在我们再来查看是否拥有权限：

```bash
$ kubectl exec test-7f4f854d7-xbr8q -n foo -it sh
/ # curl localhost:8001/api/v1/persistentvolumes
{
  "kind": "PersistentVolumeList",
  "apiVersion": "v1",
  "metadata": {
    "selfLink": "/api/v1/persistentvolumes",
    "resourceVersion": "3499"
  },
  "items": []
}/
```

#### 允许访问非资源型的 URL

在 API 服务器中也包含一些非资源型的 URL，访问这些 URL 也是需要经过授权的，在预定义的集群角色和集群角色绑定中，有一组名为 `system:discover` 的 ClusterRole 及同名的 ClusterRoleBinding 可以帮助我们自动完成这些授权过程，这里我们就只是简单的了解一下它们。

使用如下命令可以查看 `system:discover` ClusterRole：

```bash
$ kubectl get clusterrole system:discovery -o yaml

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    rbac.authorization.kubernetes.io/autoupdate: "true"
  creationTimestamp: 2019-07-28T00:57:48Z
  labels:
    kubernetes.io/bootstrapping: rbac-defaults
  name: system:discovery
  resourceVersion: "37"
  selfLink: /apis/rbac.authorization.k8s.io/v1/clusterroles/system%3Adiscovery
  uid: b7bbdf45-b0d2-11e9-b1f3-96b98326dbb0
rules:
- nonResourceURLs:
  - /api
  - /api/*
  - /apis
  - /apis/*
  - /healthz
  - /openapi
  - /openapi/*
  - /version
  - /version/
  verbs:
  - get
```

从详情中可以看出：ClusterRole 引用的是 URL 路径而非资源，同时对于这些 URL 只允许使用 GET 方法。

接下来执行如下命令再来查看一下 `system:discover` ClusterRoleBinding：

```bash
$ kubectl get clusterrolebinding system:discovery -o yaml

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  annotations:
    rbac.authorization.kubernetes.io/autoupdate: "true"
  creationTimestamp: 2019-07-28T00:57:48Z
  labels:
    kubernetes.io/bootstrapping: rbac-defaults
  name: system:discovery
  resourceVersion: "89"
  selfLink: /apis/rbac.authorization.k8s.io/v1/clusterrolebindings/system%3Adiscovery
  uid: b7e9f611-b0d2-11e9-b1f3-96b98326dbb0
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: system:discovery
subjects:
- apiGroup: rbac.authorization.k8s.io
  kind: Group
  name: system:authenticated
```

从结果中可以看出 `system:discover` ClusterRoleBinding 绑定到了 `system:authenticated` 组，凡是通过认证的账户都可以访问列在 `system:discover` ClusterRole 中的 URL。

###  了解默认的 ClusterRole 和 ClusterRoleBinding

Kubernetes 集群中也提供了一组默认的 ClusterRole 和 ClusterRoleBinding，每次 API 服务启动的时候都会更新它们，执行如下命令可以查看默认的集群角色和绑定：

```bash
$ kubectl get clusterroles

NAME                                                                   AGE
admin                                                                  8d
cluster-admin                                                          8d
edit                                                                   8d
pv-reader                                                              8m
system:aggregate-to-admin                                              8d
system:aggregate-to-edit                                               8d
system:aggregate-to-view                                               8d
system:auth-delegator                                                  8d
system:aws-cloud-provider                                              8d
system:basic-user                                                      8d
system:certificates.k8s.io:certificatesigningrequests:nodeclient       8d
system:certificates.k8s.io:certificatesigningrequests:selfnodeclient   8d
system:controller:attachdetach-controller                              8d
system:controller:certificate-controller                               8d
system:controller:clusterrole-aggregation-controller                   8d
system:controller:cronjob-controller                                   8d
system:controller:daemon-set-controller                                8d
system:controller:deployment-controller                                8d
system:controller:disruption-controller                                8d
system:controller:endpoint-controller                                  8d
system:controller:generic-garbage-collector                            8d
system:controller:horizontal-pod-autoscaler                            8d
system:controller:job-controller                                       8d
system:controller:namespace-controller                                 8d
system:controller:node-controller                                      8d
system:controller:persistent-volume-binder                             8d
system:controller:pod-garbage-collector                                8d
system:controller:pv-protection-controller                             8d
system:controller:pvc-protection-controller                            8d
system:controller:replicaset-controller                                8d
system:controller:replication-controller                               8d
system:controller:resourcequota-controller                             8d
system:controller:route-controller                                     8d
system:controller:service-account-controller                           8d
system:controller:service-controller                                   8d
system:controller:statefulset-controller                               8d
system:controller:ttl-controller                                       8d
system:coredns                                                         8d
system:csi-external-attacher                                           8d
system:csi-external-provisioner                                        8d
system:discovery                                                       8d
system:heapster                                                        8d
system:kube-aggregator                                                 8d
system:kube-controller-manager                                         8d
system:kube-dns                                                        8d
system:kube-scheduler                                                  8d
system:kubelet-api-admin                                               8d
system:node                                                            8d
system:node-bootstrapper                                               8d
system:node-problem-detector                                           8d
system:node-proxier                                                    8d
system:persistent-volume-provisioner                                   8d
system:volume-scheduler                                                8d
view                                                                   8d
```

```bash
$ kubectl get clusterrolebindings

NAME                                                   AGE
add-on-cluster-admin                                   8d
cluster-admin                                          8d
kubeadm:kubelet-bootstrap                              8d
kubeadm:node-autoapprove-bootstrap                     8d
kubeadm:node-autoapprove-certificate-rotation          8d
kubeadm:node-proxier                                   8d
pv-test                                                6m
system:aws-cloud-provider                              8d
system:basic-user                                      8d
system:controller:attachdetach-controller              8d
system:controller:certificate-controller               8d
system:controller:clusterrole-aggregation-controller   8d
system:controller:cronjob-controller                   8d
system:controller:daemon-set-controller                8d
system:controller:deployment-controller                8d
system:controller:disruption-controller                8d
system:controller:endpoint-controller                  8d
system:controller:generic-garbage-collector            8d
system:controller:horizontal-pod-autoscaler            8d
system:controller:job-controller                       8d
system:controller:namespace-controller                 8d
system:controller:node-controller                      8d
system:controller:persistent-volume-binder             8d
system:controller:pod-garbage-collector                8d
system:controller:pv-protection-controller             8d
system:controller:pvc-protection-controller            8d
system:controller:replicaset-controller                8d
system:controller:replication-controller               8d
system:controller:resourcequota-controller             8d
system:controller:route-controller                     8d
system:controller:service-account-controller           8d
system:controller:service-controller                   8d
system:controller:statefulset-controller               8d
system:controller:ttl-controller                       8d
system:coredns                                         8d
system:discovery                                       8d
system:kube-controller-manager                         8d
system:kube-dns                                        8d
system:kube-scheduler                                  8d
system:node                                            8d
system:node-proxier                                    8d
system:volume-scheduler                                8d
```

其中，`admin`、`cluster-admin`、`edit` 和 `view` ClusterRole 是最重要的角色，它们应该绑定到账户自定义 pod 中的 ServiceAccount 上。

1. `admin ClusterRole` 可以赋予一个命名空间全部的控制权。有这个 ClusterRole 的主体可以读取和修改命名空间中的任何资源，除了 ResourceQuota 和命名空间资源本身。
2. `cluster-admin ClusterRole` 可以赋予集群完全控制权限。如果想要修改 `admin ClusterRole` 无法读取的资源，就可以创建一个指向 cluster-admin ClusterRole 的 RoleBinding，这样的话 RoleBinding 中包含的账户就可以完全控制创建 RoleBinding 所在命名空间上的方方面面。
3. `edit ClusterRole` 允许修改一个命名空间中的资源、以及读取和修改 Secret。但是不允许查看或修改 Role 和 RoleBinding。
4. `view ClusterRole` 允许读取一个命名空间中的大多数资源，除了 Role、RoleBinding 和 Secret。
5. 其它默认的 ClusterRole，这些集群角色以 `system:` 为前缀，主要用于各种 Kubernetes 组件中，这些集群角色都有一个对应的 ClusterRoleBinding，它会绑定到集群组件用来身份认证的账户上。

最后，我们总结一下关于 `Role`、`ClusterRole`、`Rolebinding`、`ClusterRoleBinding` 在访问不同的资源类型时，应该如何组合使用，具体如下表所示：

| 访问的资源 | 使用的角色类型 | 使用的绑定类型 |
| -------- | ------------ | ----------- |
| 集群级别的资源(Nodes、PersistentVolumes 等) | ClusterRole | ClusterRoleBinding |
| 非资源型 URL(/api、/healthz 等) | ClusterRole | ClusterRoleBinding |
| 在任何命名空间中的资源(和跨所有命名空间的资源) | ClusterRole | ClusterRoleBinding |
| 在具体命名空间中的资源(在多个命名空间中重用这个相同的 ClusterRole) | ClusterRole | RoleBinding |
| 在具体命名空间中的资源(Role 必须在每个命名空间中定义好) | Role | RoleBinding |

## 7. 实验总结

本次实验我们向大家介绍了如下知识点：

- Kubernetes 授权简介
- RBAC 授权模式

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
