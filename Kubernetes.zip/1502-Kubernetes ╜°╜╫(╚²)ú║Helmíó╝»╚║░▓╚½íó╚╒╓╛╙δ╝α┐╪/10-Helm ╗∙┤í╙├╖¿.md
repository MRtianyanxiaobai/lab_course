---
show: step
version: 1.0
---

# Helm 基础用法

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Helm。对于简单的应用直接创建 YAML 文件，然后就可以在 Kubernetes 中进行部署了。但是如果涉及到复杂的应用，需要配置项特别多的时候，直接通过 YAML 文件创建并不是特别好的办法，因此 Kubernetes 提供了包管理工具--Helm。

####  实验知识点

- Helm 简介
- 安装 Helm
- Helm 的常用命令

####  推荐阅读

- [Helm](https://helm.sh/)
- [Helm Hub](https://hub.helm.sh/)

## 2. Helm 简介

Helm 是 Kubernetes 应用包管理工具，主要用于对需要在 Kubernetes 上部署的复杂应用进行定义、安装和更新。通过 Chart 的方式对应用软件进行描述、可以方便地创建、版本化、共享和发布复杂的应用软件，有点儿类似于 `Ubuntu` 系统中的 apt 和 `CentOS` 系统中的 yum。

Helm 主要涉及到 3 个概念：

- `Chart`：一个 Helm 包，其中包含运行一个应用所需要的工具和资源定义、Kubernetes 集群中的服务定义等。概念上类似于 APT 中的 dpkg。
- `Repository`：用于存放和共享 Chart 的仓库。
- `Release`：在集群中运行的一个 Chart 实例。在同一个集群上，一个 Chart 可以被安装多次，每次安装都会生成新的、独立的 Release 名称。

这 3 个概念合并在一起理解，使用 Helm 的主要方式就是：在仓库中查找需要的 Chart，然后将 Chart 以 Release 的形式安装在 Kubernetes 集群中。

#### 安装 Helm

Helm 的安装非常简单，直接下载已经编译好的二进制文件进行安装即可，版本相关的数据是直接存储在 kubernetes 集群中。

现在我们在环境中执行安装：（这里我们将 helm 资源文件放在了服务器上，大家也可以通过 [github](https://github.com/helm/helm/releases) 下载自己想要的版本）

```bash
$ wget https://labfile.oss.aliyuncs.com/courses/1457/helm-v3.0.2-linux-amd64.tar.gz
$ tar -zxvf helm-v3.0.2-linux-amd64.tar.gz
$ sudo cp linux-amd64/helm /usr/local/bin/helm
# 安装成功，查看 Helm 的版本
$ helm version
version.BuildInfo{Version:"v3.0.2", GitCommit:"19e47ee3283ae98139d98460de796c1be1e3975f", GitTreeState:"clean", GoVersion:"go1.13.5"}
# 添加一个 Chart 仓库，由于国内无法访问 Helm 默认的 Chart 仓库，这里改为阿里云 Chart 镜像仓库
$ helm repo add stable https://kubernetes.oss-cn-hangzhou.aliyuncs.com/charts
"stable" has been added to your repositories
# 查看在 stable 仓库中可以安装的 charts 列表
$ helm search repo stable
NAME                            CHART VERSION APP VERSION   DESCRIPTION
stable/acs-engine-autoscaler    2.1.3         2.1.1         Scales worker nodes within agent pools
stable/aerospike                0.1.7         v3.14.1.2     A Helm chart for Aerospike in Kubernetes
stable/anchore-engine           0.1.3         0.1.6         Anchore container analysis and policy evaluatio...
...
```

下面我们安装应用 MySQL 应用，进行测试。

```bash
# 更新仓库信息，获取 charts 的最新列表
$ helm repo update
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "stable" chart repository
Update Complete. Happy Helming!

# 从 stable 仓库中安装 MySQL，--generate-name 参数表示由系统自动生成 MySQL 的名称
$ helm install stable/mysql --generate-name
NAME: mysql-1576744749
LAST DEPLOYED: Thu Dec 19 16:39:09 2019
NAMESPACE: default
STATUS: deployed
REVISION: 1
TEST SUITE: None
NOTES:
MySQL can be accessed via port 3306 on the following DNS name from within your cluster:
mysql-1576744749-mysql.default.svc.cluster.local

To get your root password run:

    MYSQL_ROOT_PASSWORD=$(kubectl get secret --namespace default mysql-1576744749-mysql -o jsonpath="{.data.mysql-root-password}" | base64 --decode; echo)

To connect to your database:

1. Run an Ubuntu pod that you can use as a client:

    kubectl run -i --tty ubuntu --image=ubuntu:16.04 --restart=Never -- bash -il
...

# 查看 MySQL chart 的相关信息
$ helm show chart stable/mysql
apiVersion: v1
description: Fast, reliable, scalable, and easy to use open-source relational database
  system.
home: https://www.mysql.com/
icon: https://www.mysql.com/common/logos/logo-mysql-170x115.png
keywords:
- mysql
- database
- sql
maintainers:
- email: viglesias@google.com
  name: Vic Iglesias
name: mysql
sources:
- https://github.com/kubernetes/charts
- https://github.com/docker-library/mysql
version: 0.3.5
```

查看 kubernetes 集群中的 deployment 和 pods，可以看到集群中已经有 MySQL 相关的资源对象了：（由于 MySQL Pod 需要绑定持久卷，所以这里没有创建成功，作为示例可以忽略）

```bash
$ kubectl get deploy,pods
NAME                                           READY   UP-TO-DATE   AVAILABLE   AGE
deployment.extensions/mysql-1576744749-mysql   0/1     1            0           6m17s

NAME                                          READY   STATUS    RESTARTS   AGE
pod/mysql-1576744749-mysql-5959586876-wq4st   0/1     Pending   0          6m17s
```

最后，当我们不需要这个 MySQL Pod 时，可以直接通过 helm 删除：

```bash
# 查看当前环境中已经安装的 Release
$ helm ls
NAME             NAMESPACE  REVISION  UPDATED                                 STATUS     CHART       APP VERSION
mysql-1576744749  default   1         2019-12-19 16:39:09.529938258 +0800 CST  deployed  mysql-0.3.5
$ helm uninstall mysql-1576744749
release "mysql-1576744749" uninstalled
# 验证 MySQL Pod 也直接被删除了
$ kubectl get pods
No resources found.
```

如果大家想了解更多关于 helm 命令的相关使用，可以通过 `helm help` 进行查看。

## 3. Helm 的常用命令

#### helm search：搜索 helm

helm 提供了非常有用的搜索命令。它可以搜索两种不同类型的资源：

- `helm search hub`：从 [Helm Hub](https://hub.helm.sh/) 中搜索 charts，Helm Hub 中公开存放了大量不同版本、公开、可用的 charts。
- `helm search repo`：从已经添加到本地的仓库列表中搜索 charts。

执行如下命令在 Helm Hub 中搜索所有的 wordpress charts，如果不添加选择器，结果会显示所有可用的 charts：

```bash
$ helm search hub wordpress
URL                                                 CHART VERSION APP VERSION DESCRIPTION
https://hub.helm.sh/charts/bitnami/wordpress        8.0.4         5.3.2       Web publishing platform for building blogs and ...
https://hub.helm.sh/charts/presslabs/wordpress-...  v0.6.3        v0.6.3      Presslabs WordPress Operator Helm Chart
https://hub.helm.sh/charts/presslabs/wordpress-...  v0.7.4        v0.7.4      A Helm chart for deploying a WordPress site on ...
```

接下来我们添加一个本地仓库，查看其中已经有的 charts：

```bash
$ helm repo add brigade https://brigadecore.github.io/charts
"brigade" has been added to your repositories
$ helm search repo brigade
NAME                          CHART VERSION APP VERSION DESCRIPTION
brigade/brigade               1.4.2         v1.2.1      Brigade provides event-driven scripting of Kube...
brigade/brigade-github-app    0.5.0         v0.2.1      The Brigade GitHub App, an advanced gateway for...
brigade/brigade-github-oauth  0.3.0         v0.20.0     The legacy OAuth GitHub Gateway for Brigade
brigade/brigade-k8s-gateway   0.3.0                     A Helm chart for Kubernetes
brigade/brigade-project       1.0.0         v1.0.0      Create a Brigade project
brigade/kashti                0.5.0         v0.4.0      A Helm chart for Kubernetes

# search 命令还可以模糊匹配
$ helm search repo kash
NAME            CHART VERSION APP VERSION DESCRIPTION
brigade/kashti  0.5.0         v0.4.0      A Helm chart for Kubernetes
```

#### helm install：安装 helm

在前面通过搜索查找到可用包之后，可以执行 `helm install` 命令进行安装。

`helm install` 命令有两个参数：自定义 Release 的名称（如果不想要自定义名称，可以使用参数 --generate-name 让系统自动命名），以及想要安装的 charts 的名称。

比如，我们想要从 stable 仓库中安装 mariadb，并将这个 Release 命名为 happy-panda：

```bash
$ helm install happy-panda stable/mariadb
NAME: happy-panda
LAST DEPLOYED: Thu Dec 19 17:59:18 2019
NAMESPACE: default
STATUS: deployed
REVISION: 1
NOTES:
MariaDB can be accessed via port 3306 on the following DNS name from within your cluster:
happy-panda-mariadb.default.svc.cluster.local

To get the root password run:

    MARIADB_ROOT_PASSWORD=$(kubectl get secret --namespace default happy-panda-mariadb -o jsonpath="{.data.mariadb-root-password}" | base64 --decode)

To connect to your database:

1. Run a pod that you can use as a client:

    kubectl run happy-panda-mariadb-client --rm --tty -i --env MARIADB_ROOT_PASSWORD=$MARIADB_ROOT_PASSWORD --image bitnami/mariadb --command -- bash

2. Connect using the mysql cli, then provide your password:
    mysql -h happy-panda-mariadb -p$MARIADB_ROOT_PASSWORD
```

在安装的过程中，helm 会打印出相关的信息。如果后面忘记了创建的 happy-panda 的具体信息，可以使用命令 `helm status happy-panda` 再次查看。

使用 `helm install` 安装，可以有多个来源：

- Chart 仓库（比如上面提到的例子）。
- 本地的 Chart 压缩包（比如：`helm install foo foo-0.1.1.tgz`）。
- 一个 Chart 目录（比如：`helm install foo path/to/foo`）。
- 一个完整的 URL（比如：`helm install foo https://example.com/charts/foo-1.2.3.tgz`）。

#### 自定义 Chart 的配置

通过前面的方式安装，只能使用 chart 的默认配置。但是很多时候，我们希望能够按照我们的需求自定义 chart 的配置。

通过 `helm show values` 查看设置：

```bash
$ helm show values stable/mariadb
## Bitnami MariaDB image version
## ref: https://hub.docker.com/r/bitnami/mariadb/tags/
##
## Default: none
image: bitnami/mariadb:10.1.31-r1

## Specify an imagePullPolicy (Required)
## It's recommended to change this to 'Always' if the image tag is 'latest'
## ref: http://kubernetes.io/docs/user-guide/images/#updating-images
imagePullPolicy: IfNotPresent
...
```

可以在 YAML 文件中覆盖任何需要修改的设置，然后在安装的时候传递这个文件：

```bash
$ echo '{mariadbUser: user0, mariadbDatabase: user0db}' > config.yaml
$ helm install -f config.yaml stable/mariadb  --generate-name
NAME: mariadb-1576751686
LAST DEPLOYED: Thu Dec 19 18:34:46 2019
NAMESPACE: default
STATUS: deployed
REVISION: 1
NOTES:
MariaDB can be accessed via port 3306 on the following DNS name from within your cluster:
mariadb-1576751686-mariadb.default.svc.cluster.local

To get the root password run:

    MARIADB_ROOT_PASSWORD=$(kubectl get secret --namespace default mariadb-1576751686-mariadb -o jsonpath="{.data.mariadb-root-password}" | base64 --decode)

To get the password for "user0" run:
...
```

这个 Chart 会创建一个名为 `user0` 的用户，并授权 `user0` 用户对新创建的 `user0db` 数据库拥有访问权限，其它配置项就采用 Chart 的默认配置项。

在安装的过程中，有两种传递配置数据的方法：

- `--values` 或是 `-f`：使用 YAML 配置文件进行参数配置。可以同时指定多个 YAML 配置文件，类似于 `helm install stable/mariadb -f config.yaml -f config2.yaml`，在这里最后一个配置文件会优先生效。
- `--set`：直接在命令行设置参数。设置值会保存在 ConfigMap 中。也可以通过 `helm upgrade --reset-values` 重新设置值。

如果 `--values` 和 `--set` 参数同时使用，那么 `--set` 参数会具有更高优先级。

`--set` 的格式和限制：

`--set` 选项可以接收多个 name/value 键值对。

最简单的方式是 `-set name=value`，相当于 YAML 文件中的 `name: value`。

多个值之间可以用 `,` 分隔，即：`--set a=b,c=d`，等效于 YAML 文件中的：

```yaml
a: b
c: d
```

还可以支持更复杂的表达式，比如 `--set outer.inner=value`，相当于 YAML 文件中的：

```yaml
outer:
  inner: value
```

如果是列表，可以用 `{}` 来表示。比如 `--set name={a, b, c}`，相当于 YAML 文件中的：

```yaml
name:
  - a
  - b
  - c
```

如果需要设置特殊字符，可以添加反斜杠 `\` 进行转义。比如 `--set name=value1\,value2`，相当于 YAML 文件中的 `name: "value1,value2"`。也可以对 `.` 进行转义，比如 `--set nodeSelector."kubernetes\.io/role"=master`，相当于 YAML 文件中的：

```yaml
nodeSelector:
  kubernetes.io/role: master
```

尽管 `--set` 参数有这么多语法，但是表达能力依然不如 YAML 语言。所以，简单的配置可以使用 `--set` 参数，如果是复杂的配置，建议依然使用 YAML 语言。

#### helm upgrade 和 helm rollback：升级和回滚

当一个 Chart 发布新版本，或者修改 release 的配置时，可以使用 `helm upgrade` 命令。这个命令只会使用提供的更新信息进行升级。

```bash
$ echo '{mariadbUser: user1}' > panda.yaml
$ helm upgrade -f panda.yaml happy-panda stable/mariadb
Release "happy-panda" has been upgraded. Happy Helming!
NAME: happy-panda
LAST DEPLOYED: Fri Dec 20 14:29:01 2019
NAMESPACE: default
STATUS: deployed
REVISION: 2
NOTES:
MariaDB can be accessed via port 3306 on the following DNS name from within your cluster:
happy-panda-mariadb.default.svc.cluster.local

To get the root password run:

    MARIADB_ROOT_PASSWORD=$(kubectl get secret --namespace default happy-panda-mariadb -o jsonpath="{.data.mariadb-root-password}" | base64 --decode)

To get the password for "user1" run:

    MARIADB_PASSWORD=$(kubectl get secret --namespace default happy-panda-mariadb -o jsonpath="{.data.mariadb-password}" | base64 --decode)To connect to your database:

1. Run a pod that you can use as a client:

    kubectl run happy-panda-mariadb-client --rm --tty -i --env MARIADB_ROOT_PASSWORD=$MARIADB_ROOT_PASSWORD --image bitnami/mariadb --command -- bash

2. Connect using the mysql cli, then provide your password:
    mysql -h happy-panda-mariadb -p$MARIADB_ROOT_PASSWORD
```

现在来查看新设置是否生效：

```bash
$ helm get values happy-panda
USER-SUPPLIED VALUES:
mariadbUser: user1
```

如果对更新不满意，还可以回滚：

```bash
$ helm rollback happy-panda 1
Rollback was a success! Happy Helming!
```

现在就回滚到了第一个版本上。发布版本是增量修改的，每一次安装、升级、回滚，revision 数字都会递增 1。第一个版本的数字是 1。可以查看具体的变更记录：

```bash
$ helm history happy-panda
REVISION  UPDATED                   STATUS      CHART         APP VERSION DESCRIPTION
1         Fri Dec 20 14:23:41 2019  superseded  mariadb-2.1.6 10.1.31     Install complete
2         Fri Dec 20 14:29:01 2019  superseded  mariadb-2.1.6 10.1.31     Upgrade complete
3         Fri Dec 20 15:11:59 2019  deployed    mariadb-2.1.6 10.1.31     Rollback to 1
```

**install/upgrade/rollback 的相关参数**

下面介绍一些常用的参数：

- `--timeout`：等待 kubernetes 命令完成的时间，默认值为 300 秒。
- `--wait`：等待 Pod，直到其状态变为 ready，PVC 才完成绑定。Deployment 完成其最低就绪要求的 Pod 创建，并且服务有了 IP 地址，才认为 Release 创建成功。
- `--no-hooks`：这个命令会跳过 Hook 执行。

#### helm uninstall

当想要卸载一个 release 时，可以使用 `helm uninstall` 命令。

```bash
$ helm uninstall happy-panda
release "happy-panda" uninstalled
```

如果想要保留删除的记录，可以使用参数 `--keep-history`。即：`helm uninstall happy-panda --keep-history`。

#### helm repo

与仓库相关的操作有：`add`（添加）、`list`（列出）和 `remove`（删除）。

通过命令 `helm repo add` 可以添加仓库：

```bash
$ helm repo add brigade https://brigadecore.github.io/charts
"brigade" has been added to your repositories
```

通过命令 `helm repo list` 可以列出所有的仓库：

```bash
$ helm repo list
NAME    URL
stable  https://kubernetes.oss-cn-hangzhou.aliyuncs.com/charts
brigade https://brigadecore.github.io/charts
```

最后可以通过命令 `helm repo remove` 删除指定的仓库：

```bash
$ helm repo remove brigade
"brigade" has been removed from your repositories
```

#### 自定义 charts

使用 `helm create` 命令可以快速创建一个 charts 模板：

```bash
$ helm create deis-workflow
Creating deis-workflow
```

然后在当前目录下可以看到一个 `deis-workflow` 文件夹，目录结构如下所示：

```bash
$ tree deis-workflow
deis-workflow
├── Chart.yaml  # 描述 Chart 信息的 YAML 文件
├── charts      # 可选：包含该 Chart 所依赖的其它 Chart，对于依赖的 Chart 信息可以写入 Chart.yaml 文件中
├── templates   # 模板目录，与 values.yaml 文件搭配使用，生成 kubernetes 的 manifest 文件
│   ├── NOTES.txt # 文本文件，用法描述
│   ├── _helpers.tpl  # 如果模板很复杂，需要函数/其它数据结构，可以在这里定义
│   ├── deployment.yaml # deployment 的 Go 模板文件
│   ├── ingress.yaml    # ingress 的 Go 模板文件
│   ├── service.yaml    # service 的 Go 模板文件
│   ├── serviceaccount.yaml  # serviceaccount 的 Go 模板文件
│   └── tests
│       └── test-connection.yaml
└── values.yaml  # 模板的值文件，在安装时这些值会应用到 Go 模板文件生成部署文件

3 directories, 9 files
```

对于依赖的 Chart，可以写入 Chart.yaml 文件中，Helm 在执行的过程中会自动下载依赖 Charts 所需文件，并将其放入 `charts/` 目录下。

对于依赖 Chart 的配置示例如下：

```yaml
dependencies:
- name: mariadb
  version: 5.x.x
  repository: https://kubernetes-charts.storage.googleapis.com/
  condition: mariadb.enabled
  tags:
    - database
```

使用 `helm package` 命令可以将 charts 进行打包发布：

```bash
$ helm package deis-workflow
Successfully packaged chart and saved it to: /home/shiyanlou/deis-workflow-0.1.0.tgz
```

然后可以从打包的文件中直接进行应用的安装：

```bash
$ helm install deis-workflow deis-workflow-0.1.0.tgz
NAME: deis-workflow
LAST DEPLOYED: Fri Dec 20 16:33:06 2019
NAMESPACE: default
STATUS: deployed
REVISION: 1
NOTES:
1. Get the application URL by running these commands:
  export POD_NAME=$(kubectl get pods --namespace default -l "app.kubernetes.io/name=deis-workflow,app.kubernetes.io/instance=deis-workflow" -o jsonpath="{.items[0].metadata.name}")
  echo "Visit http://127.0.0.1:8080 to use your application"
  kubectl --namespace default port-forward $POD_NAME 8080:80
```

## 4. 实验总结

本次实验我们向大家介绍了如下知识点：

- Helm 简介
- 安装 Helm
- Helm 的常用命令

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
