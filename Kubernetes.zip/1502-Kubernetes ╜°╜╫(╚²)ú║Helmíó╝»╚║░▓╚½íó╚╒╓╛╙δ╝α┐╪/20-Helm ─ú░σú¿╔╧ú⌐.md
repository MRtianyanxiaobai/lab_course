---
show: step
version: 1.0
---

# Helm 模板（上）

## 1.实验介绍

####  实验内容

本次实验将会向大家介绍 Helm 模板（上）。

####  实验知识点

- Helm 模板简介
- 内置对象与 Values 文件
- 模板函数与管道
- 流程控制

####  推荐阅读

- [Go 语言模板](https://golang.org/pkg/text/template/)
- [sprig 库](https://github.com/Masterminds/sprig)

## 2. Helm 模板简介

首先，我们可以对 Helm 模板有一个简单的认识。先创建一个 Chart 并添加一个简单的模板。

在前面介绍过 Helm Charts 的基本目录结构如下所示：

```yaml
mychart/
  Chart.yaml  # Chart 的描述信息
  values.yaml # 设置模板文件的默认值，当 install 或是 upgrade 时这些值也可以被覆盖
  charts/     # 依赖的 Chart 文件
  templates/  # 存放模板文件，当创建一个 Chart 时，会将所有这些模板文件的内容发送给 kubernetes 集群
  ...
```

创建一个名为 `mychart` 的简单 Chart，然后在自定义模板：(如果大家环境中没有安装 Helm，可以安装前面介绍的方法进行安装)

```bash
$ helm create mychart
Creating mychart
```

在 `templates` 目录有两个比较特别的文件，这里说明如下：

```yaml
NOTES.txt # 作用类型于“帮助文档”，当 install 安装的时候，这个文件中的内容会被展示出来
_helpers.tpl  # 作用类似于“模板助手”，在这里定义需要在 Chart 中反复使用到的模板或是结构
```

将 `templates` 目录下的所有文件都删除掉，后续我们将自己重写这些文件：

```bash
rm -rf mychart/templates/*
```

创建一个 ConfigMap 模板，在 `mychart/templates` 目录下新建 `configmap.yaml` 文件并向其中写入如下内容：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: mychart-configmap
data:
  myvalue: "Hello World"
```

创建完这个简单的模板以后，就可以直接安装：

```bash
$ helm install full-coral ./mychart
NAME: full-coral
LAST DEPLOYED: Sat Jan 18 15:20:50 2020
NAMESPACE: default
STATUS: deployed
REVISION: 1
TEST SUITE: None
```

可以看到 ConfigMap 已经创建成功，现在来检索版本并查看加载的实际模板：

```bash
$ helm get manifest full-coral
---
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: mychart-configmap
data:
  myvalue: "Hello World"
```

现在可以使用命令 `helm uninstall full-coral` 删除这个 release 了。

接下来我们添加一个简单的模板调用。在上面的配置中，我们的 `name` 是硬编码的，这并不是一种好的方式，推荐的方式是采用模板来设置值，而不是每次都修改源文件。

Helm Chart 模板使用的是 [Go 语言模板](https://golang.org/pkg/text/template/) 编写，并添加了 [sprig 库](https://github.com/Masterminds/sprig) 中的 50 多个附件模板函数。

我们希望 Configmap 的名称是生成的 Release 的名称，现在将 `configmap.yaml` 文件的 `name` 配置修改为 `name: {{ .Release.Name }}-configmap`。

模板指令是包含在 `{{` 和 `}}` 内的。

Release 模板对象是 Helm 内置对象的一种，传递给模板的值是 namespace 对象，以 `.` 分隔每个 namespace 元素，Release 前面的小圆点 `.` 表示从顶层命名空间开始。所以综合起来关于 `.Release.Name` 的理解是：从顶层 namespace 开始，找到 Release 对象，然后在 Release 对象中查找 Name 对象。

执行安装：

```bash
$ helm install clunky-serval ./mychart
NAME: clunky-serval
LAST DEPLOYED: Sat Jan 18 15:56:59 2020
NAMESPACE: default
STATUS: deployed
REVISION: 1
TEST SUITE: None
```

查看配置信息：

```bash
$ helm get manifest clunky-serval
---
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: clunky-serval-configmap  # 可以看到 name 名称是 clunky-serval-configmap，前面的 clunky-serval 就是 release 的名称
data:
  myvalue: "Hello World"
```

当我们想要测试模板渲染的时候可以使用参数 `--debug --dry-run`，这样会返回渲染的模板、同时不会立刻执行安装操作：

```bash
$ helm install --debug --dry-run goodly-guppy ./mychart
install.go:149: [debug] Original chart version: ""
install.go:166: [debug] CHART PATH: /home/shiyanlou/mychart

NAME: goodly-guppy
LAST DEPLOYED: Sat Jan 18 16:13:06 2020
NAMESPACE: default
STATUS: pending-install
REVISION: 1
TEST SUITE: None
USER-SUPPLIED VALUES:
{}

COMPUTED VALUES:
...

HOOKS:
MANIFEST:
---
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: goodly-guppy-configmap
data:
  myvalue: "Hello World"
```

## 3. 内置对象与 Values 文件

#### 内置对象

通过模板引擎可以将对象传递到模板中，使用代码也可以传递对象（比如使用 `with`、`range` 语句时），甚至有些方法可以直接在模板中创建新对象（比如 `tuple` 函数）。

对象通常都比较简单，只有一个值，或者包含其它对象/函数。比如 `Release` 对象包含了好多对象（像 `Release.Name`），而 `Files` 对象包含一些函数。

内置对象列表如下：

- `Release`：这个对象描述了 Release 本身，它里面还包含好几个对象：
    - `Release.Name`：Release 的名称。
    - `Release.Namespace`：Release 所在的命名空间。
    - `Release.IsUpgrade`：如果当前操作是升级/回滚，它的值就设置为 `true`。
    - `Release.IsInstall`：如果当前操作是安装，它的值就设置为 `true`。
    - `Release.Revision`：Release 的修订版本号，它的值默认为 1，每当升级或回滚一次，值就增加 1。
    - `Release.Service`：Release 服务的名称，它的值始终是 Helm。
- `Values`：从 `values.yaml` 文件或是用户提供的文件传递 Values 的值，默认情况下为空。
- `Chart`：`Chart.yaml` 文件的内容，所有的 Chart 对象都会从这个文件中获取。比如在前面的例子中 `{{ .Chart.Name }}-{{ .Chart.Version }}`在模板中会被渲染为 `mychart-0.1.0`。
- `Files`：提供对 Chart 中所有非特殊文件的访问，虽然不能使用这个对象来访问模板，但是可以使用它来访问 Chart 中的其它文件。
    - `Files.Get`：按名称获取文件的函数，比如 `{{ .Files.Get config.ini }}`。
    - `Files.GetBytes`：将文件内容作为 bytes 数组而不是 string 获取到函数，对于处理图片非常有用。
    - `Files.Glob`：这个函数可以返回匹配要求的文件列表。
    - `Files.Lines`：这个函数可以按行读取文件。
    - `Files.AsSecrets`：这个函数可以将文件内容经过 Base64 加密以后的内容。
    - `Files.AsConfig`：这个函数可以将文件内容以 YAML 的形式返回。
- `Capabilities`：提供关于 kubernetes 集群支持的信息。
    - `Capabilities.APIVersions`：一组版本信息。
    - `Capabilities.APIVersions.Has $version`：提示在集群中版本（比如 `batch/v1`）或是资源（比如 `apps/v1/Deployment`）是否可用。
    - `Capabilities.KubeVersion` 或是 `Capabilities.KubeVersion.Version`：kubernetes 的版本。
    - `Capabilities.KubeVersion.Major`：kubernetes 的主版本号。
    - `Capabilities.KubeVersion.Minor`：kubernetes 的次版本号。
- `Template`：包含当前正在被执行的模板的信息。
    - `Name`：完整的当前模板的路径信息（比如 `mychart/templates/mytemplate.yaml`）。
    - `BasePath`：当前模板所在的目录信息（比如 `mychart/templates`）。

注意：内置对象的名称总是已大写字母开头。

#### Values 文件

在前面的内置对象中，我们提到过 `Values` 对象，这个对象提供对传入 Chart 的值的访问。Values 的值有 4 种来源：

- chart 包中的 values.yaml 文件
- 父 chart 包中的 values.yaml 文件
- 在 `helm install` 或是 `helm upgrade` 时通过 `-f` 参数传入的 yaml 文件，比如 `helm install -f myvals.yaml ./mychart`
- 通过 `--set` 参数单独传递值，比如 `helm install --set foo=bar ./mychart`

chart 的 values.yaml 文件提供的值可以被用户自定义的 yaml 文件所覆盖，而该文件同样可以被 `--set` 参数提供的值所覆盖。

删除 `mychart/values.yaml` 文件中的内容然后向其中写入：

```yaml
favoriteDrink: coffee
```

然后修改 `mychart/templates/configmap.yaml` 文件中的内容如下所示：

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ .Release.Name }}-configmap
data:
  myvalue: "Hello World"
  drink: {{ .Values.favoriteDrink }}  # 这里使用模板，从 Values 中获取 favoriteDrink 的值
```

渲染模板：

```bash
$ helm install --debug --dry-run test ./mychart
install.go:149: [debug] Original chart version: ""
install.go:166: [debug] CHART PATH: /home/shiyanlou/mychart

NAME: test
LAST DEPLOYED: Sat Jan 18 17:56:57 2020
NAMESPACE: default
STATUS: pending-install
REVISION: 1
TEST SUITE: None
USER-SUPPLIED VALUES:
{}

COMPUTED VALUES:
favoriteDrink: coffee

HOOKS:
MANIFEST:
---
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
data:
  myvalue: "Hello World"
  drink: coffee    # 可以看到这里 drink 的值被正确的渲染为了 coffee
```

现在使用 `--set` 参数覆盖之前设置的值，将 coffee 修改为 slurm：

```bash
$ helm install  --debug --dry-run --set favoriteDrink=slurm test ./mychart
...
USER-SUPPLIED VALUES:
favoriteDrink: slurm

COMPUTED VALUES:
favoriteDrink: slurm

HOOKS:
MANIFEST:
---
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
data:
  myvalue: "Hello World"
  drink: slurm
```

由于 `--set` 参数比默认的 `values.yaml` 文件具有更高的优先级，所以模板最终渲染出来的值为 `drink: slurm`。

Values 文件也可以包含更多具有结构化的内容，比如可以在 `values.yaml` 文件中创建 `favorite` 部分，然后再添加多个键：

```yaml
favorite:
  drink: coffee
  food: pizza
```

对应的，模板部分也需要修改：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{ .Values.favorite.drink }}
  food: {{ .Values.favorite.food }}
```

#### 删除默认 Key

如果想要从默认值中删除某个键，可以覆盖这个键的值为 `null`，在这种情况下当 Helm 合并覆盖值时会直接删除这个键。

比如，stable 版本的 Drupal Chart 可以配置 liveness 探测器，它的默认值为：

```yaml
...
livenessProbe:
  httpGet:
    path: /user/login
    port: http
  initialDelaySeconds: 120
```

如果想要覆盖 liveness 探测器的 `httpGet` 方式改为 `exec` 方式，可以使用命令：

```bash
# 需要设置 httpGet 的值为 null，然后再设置 exec 的值
helm install stable/drupal --set livenessProbe.httpGet=null --set livenessProbe.exec.command=[cat,docroot/CHANGELOG.txt]
```

最终覆盖完成的结果为：

```yaml
...
livenessProbe:
  exec:
    command:
    - cat
    - docroot/CHANGELOG.txt
  initialDelaySeconds: 120
```

## 4. 模板函数与管道

到目前为止，我们已经知道了如何把信息放入模板中。但是放入模板的这些信息都是未经修改的，有的时候我们想要转换这些信息，让它们对于我们来说更加有用。

#### 模板函数

当我们想要从 `.Values` 中读取的值成为字符串的时候可以调用 `quote` 模板函数实现，修改 `mychart/templates/configmap.yaml` 文件中的内容如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{ quote .Values.favorite.drink }}
  food: {{ quote .Values.favorite.food }}
```

模板函数的语法规则是 `函数名 参数1 参数2...`，在上面的例子中 `quote .Values.favorite.drink` 就是调用了 `quote` 函数并将后面的值作为参数传递给它。模板渲染后的结果如下所示：

```bash
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "pizza"
```

Helm 是一种 Go 模板语言，拥有超过 60 种可用函数，其中一部分是由 [Go 模板语言](https://godoc.org/text/template) 本身定义的，其它大部分都是来自于 [Spring 模板仓库](https://github.com/Masterminds/sprig)。比如上面使用到的 `quote` 函数就是 Spring 模板库提供的一种字符串函数，主要作用就是用双引号将字符串括起来。

#### 管道

模板语言的强大功能之一是它的管道概念，类似于 UNIX，管道是一个链在一起的一系列模板命令的工具，可以紧凑地表达一系列转换。换句话说，管道是按顺序完成一系列事情的一种方法，可以使用管道重写上面的例子：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{ .Values.favorite.drink | quote }}
  food: {{ .Values.favorite.food | quote }}
```

其中，`.Values.favorite.food | quote` 表示使用管道 `|` 将参数发送给函数。进一步地，使用管道可以将多个功能链接到一起，比如：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{ .Values.favorite.drink | repeat 5 | quote }} # 先重复 5 次，再加上双引号
  food: {{ .Values.favorite.food | upper | quote }}  # 先大写，然后再加上双引号
```

模板渲染后的结果如下所示：

```yaml
# Source: mychart/templates/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-configmap
data:
  myvalue: "Hello World"
  drink: "coffeecoffeecoffeecoffeecoffee"
  food: "PIZZA"
```

#### 使用 default 函数

在模板中经常使用的一个函数是 `default` 函数：`default 默认值 给的值`。这个函数可以在模板中指定默认值，避免这个值被省略。比如修改上面 configmap.yaml 文件中 drink 的表达式为如下：

```yaml
  drink: {{ .Values.favorite.drink | default "tea" | quote }}
```

如果正常运行，模板渲染后 drink 的值依然会是 coffee：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "PIZZA"
```

现在修改 `mychart/values.yaml` 文件，将其中 drink 部分注释掉：

```yaml
favorite:
  #drink: coffee
  food: pizza
```

然后重新渲染模板，得到的结果如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "tea"
  food: "PIZZA"
```

在实际应用中，所有的静态默认值都应该写到 `values.yaml` 文件中，`default` 命令比较适合使用到计算值的时候设置默认值，因为计算值不能在 `values.yaml` 文件中声明。比如：

```yaml
  drink: {{ .Values.favorite.drink | default (printf "%s-tea" (include "fullname" .)) }}
```

有的时候使用 `if` 条件判断会比 `default` 函数更加合适。

#### 运算符函数

对于模板而言，所有的运算符（比如 `eq`、`ne`、`lt`、`gt`、`and`、`or` 等）都可以被实现为可以像函数一样的调用。在管道中，运算符可以用圆括号 `()` 进行分组。

## 5. 流程控制

流程控制，使得我们可以控制模板的生成流程。Helm 模板语言提供了如下 3 种控制结构的语法：

- `if/else`：用于创建条件块。
- `with`：用于指定范围。
- `range`：提供了一个类似“for each”风格的循环。

#### if/else 条件

`if/else` 主要用于在模板中有条件的包含文本。它的基本结构如下所示：

```yaml
{{ if PIPELINE }}
  # Do something
{{ else if OTHER PIPELINE }}
  # Do something else
{{ else }}
  # Default case
{{ end }}
```

在进行条件判断的时候不仅仅只能使用 Value 值，还可以使用 PIPELINE 管道。条件判断需要根据结果为 true 还是 false 进行。当值为如下几种情况时，就表示为 false：

- 布尔类型的 false
- 数字类型的 0
- 空的字符串
- 空或者 null
- 空的集合（`map`、`slice`、`tuple`、`dict`、`array`）

在 configmap.yaml 文件中添加一个简单的条件判断：如果 drink 的值为 coffee，就在配置中添加 `mug: true`。在 configmap.yaml 文件最后一行添加条件判断：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{.Values.favorite.drink | default "tea" | quote}}
  food: {{.Values.favorite.food | upper | quote}}
  {{ if and .Values.favorite.drink (eq .Values.favorite.drink "coffee") }}mug: true{{ end }}
```

然后将 values.yaml 文件中对于 drink 的注释取消掉，最后渲染模板输出如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "PIZZA"
  mug: true
```

#### 空格控制

在前面，我们写的条件判断是一整行，这样不方便查看，可以写为如下的方式，更加符合人类可读性：

```yaml
...
data:
  myvalue: "Hello World"
  drink: {{.Values.favorite.drink | default "tea" | quote}}
  food: {{.Values.favorite.food | upper | quote}}
  {{- if and .Values.favorite.drink (eq .Values.favorite.drink "coffee") }}mug: true
  {{- end }} # 格式为 {{- xxxx }}，在左边大括号中添加了破折号，以及破折号与值的中间需要有一个空格
```

渲染模板，正常输出：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "PIZZA"
  mug: true
```

#### 使用 with 修改范围

`with` 可以控制变量的作用域。前面提到过，`.` 是对当前作用域的引用，`.Values` 表示在当前作用域中查找 Values 对象。

`with` 的语法结构如下所示：

```yaml
{{ with PIPELINE }}
  # restricted scope
{{ end }}
```

作用域范围是可以改变的。`with` 语法可以将当前作用域范围（也就是 `.`）设置为一个特定的对象。比如我们可以工作在 `.Values.favorites` 这个小作用域范围内。修改 configmap.yaml 文件内容为如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  {{- with .Values.favorite }}
  drink: {{ .drink | default "tea" | quote }}  # 使用 with 限定作用范围为 .Values.favorite，那么 drink 和 food 变量就不需要再限定了
  food: {{ .food | upper | quote }}
  {{- end }} # 在这个之后，. 复位为其先前设置的范围
```

需要注意的是，在受限范围内，就不能越过限制范围直接访问父范围了。如果想要访问父范围，可以写在限定范围之外，如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  {{- with .Values.favorite }}
  drink: {{ .drink | default "tea" | quote }}
  food: {{ .food | upper | quote }}
  {{- end }}
  release: {{ .Release.Name }}
```

#### range 循环

`range` 可以遍历集合。

向 values.yaml 文件中添加一份披萨配料列表，完整的文件内容如下所示：

```yaml
favorite:
  drink: coffee
  food: pizza
pizzaToppings:
  - mushrooms
  - cheese
  - peppers
  - onions
```

然后修改 configmap.yaml 文件，将这个列表打印出来：

```yaml
...
data:
  myvalue: "Hello World"
  {{- with .Values.favorite }}
  drink: {{ .drink | default "tea" | quote }}
  food: {{ .food | upper | quote }}
  {{- end }}
  toppings: |-
    {{- range .Values.pizzaToppings }}
    - {{ . | title | quote }}
    {{- end }}
```

注意看 `toppings` 列表，`range` 函数会循环遍历 `{{ .Values.pizzaToppings }}` 列表，所以在循环内部我们直接使用了一个 `.`（因为当前作用域就是这个循环），这个 `.` 会从列表的第一个元素一直遍历到最后一个元素，然后在遍历过程中使用了 `title` 和 `quote` 这两个函数，`title` 函数的作用是将字符串首字母变成大写，`quote` 函数的作用是给字符串加上双引号。

最后模板渲染的结果如下所示：

```yaml
...
data:
  myvalue: "Hello World"
  drink: "coffee"
  food: "PIZZA"
  toppings: |-
    - "Mushrooms"
    - "Cheese"
    - "Peppers"
    - "Onions"
```

除了列表，也可以直接在模板中遍历元组 `tuple`，比如：

```yaml
  sizes: |-
    {{- range tuple "small" "medium" "large"}}
    - {{.}}
    {{- end}}
```

模板渲染后的结果为：

```yaml
  sizes: |-
    - small
    - medium
    - large
```

`range` 也可以遍历具有键值对的集合，比如 `map` 或是 `dict`。

## 6. 实验总结

本次实验我们向大家介绍了如下知识点：

- Helm 模板简介
- 内置对象与 Values 文件
- 模板函数与管道
- 流程控制

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。

