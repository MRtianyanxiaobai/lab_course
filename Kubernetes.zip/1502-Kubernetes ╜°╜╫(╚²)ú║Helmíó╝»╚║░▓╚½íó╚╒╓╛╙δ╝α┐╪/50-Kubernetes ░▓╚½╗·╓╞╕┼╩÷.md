---
show: step
version: 1.0
---

# Kubernetes 安全机制概述

## 1.实验介绍

####  实验内容

接下来的部分，我们主要讲解 Kubernetes 的安全机制。Kubernetes 作为分布式集群的管理工具，保证集群的安全性也是一个非常重要的方面。

####  实验知识点

- Kubernetes 访问控制的三个层次

## 2. Kubernetes 访问控制的三个层次

API Server 既是集群内部各个组件通信的中介，也是外部控制的入口。所以 kubernetes 的安全机制也是围绕保护 API Server 进行设计的。

用户访问 API Server 的方式通常有三种：kubectl、客户端库、发送 REST 请求。用户账户（自然人）和 kubernetes 服务账户（Pod）都可以被授权访问 API Server。一个请求想要到达 API Server 需要经过如下三个阶段：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20191223-1577090682891/wm)

- `Authentication`：认证
- `Authorization`：授权
- `Admission Control`：准入控制

从上图也可以看出，所有的请求都会通过网关（kube-apiserver 组件）进行处理。

#### 认证（Authentication）

认证阶段的主要目的是：识别账户身份。可以支持多种认证方式：HTTP 证书（CA）认证、HTTP Token、HTTP Base、Service Account、OpenID Connect 等。当同时指定多种认证方式时，会逐个采用这些方式对请求进行认证（认证顺序是随机的），只要通过其中一种认证方式，API Server 会认为认证成功。

在 kubernetes 集群中，默认的认证方式是 HTTP 证书认证。每个用户都有客户端证书，API Server 通过 CA 验证客户端证书。

#### 授权（Authorization）

授权阶段的主要目的是：判断请求是否有对应的权限。授权方式有多种：`AlwaysDeny`，`AlwaysAllow`，`ABAC`，`RBAC`，`Webhook`，`Node` 等。

Authorization 是对资源（容器的计算、网络、存储资源等）的授权。当一个请求经过认证后，需要访问某种资源，授权插件通过访问策略比较该请求上下文的属性（包括：用户、资源、命名空间），根据授权规则判定该资源是否可以被客户端访问。

可以同时启用多种授权验证，只要通过其中一种授权，那么请求的授权就算是通过。如果所有的授权都没有通过，那么请求就会被拒绝（HTTP 状态码 403）。

在 kubernetes 集群中，默认的开启的授权方式是 `RBAC` 和 `Node`。

#### 准入控制（Admission Control）

准入控制阶段的主要目的是：判断请求的操作是否符合集群的要求。可以设置“准入控制器列表”。获得授权的请求都需要通过准入控制器的检查，如果检查不通过，请求依然会被拒绝。

Admission Control 在改变资源持久化之前（资源的创建、修改、删除）的机制。

## 3. 实验总结

本次实验我们向大家介绍了如下知识点：

- Kubernetes 访问控制的三个层次

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
