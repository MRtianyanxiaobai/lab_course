---
show: step
version: 1.0
---

# Helm Hooks 与仓库

## 1.实验介绍

####  实验内容

本节内容主要向大家介绍 Helm Hooks 与 Chart 仓库。

####  实验知识点

- Helm Hooks 简介
- 写一个 Hook
- Chart 仓库

####  推荐阅读

- [Custom Resource Definitions](https://helm.sh/docs/topics/chart_best_practices/custom_resource_definitions/)

## 2. Helm Hooks 简介

Helm 提供了 Hook 机制，可以允许 Chart 开发人员在 Release 生命周期中的某些节点进行干预。Hooks 的用途通常有：

- 加载其它 Charts 之前，在安装过程中加载 ConfigMap 或 Secret。
- 在安装新 Chart 之前，执行作业来备份数据库；然后在升级后执行第二个作业来恢复数据。
- 在删除 Release 之前运行作业用于停止服务。

Helm 的工作方式与模板一样，但是它们有特殊的注释，可以使 Helm 以不同的方式使用它们。

Helm 的基本用法是在 metadata 中以 annotations 的方式声明，示例如下：

```yaml
...
metadata:
  annotations:
    "helm.sh/hook": "pre-upgrade"
...
```

###  可用的 Hooks 值

有如下已经定义好了的 Hooks 供我们使用，列表如下：

| annotations 的值 | 描述 |
| --- | --- |
| pre-install | `预安装`。在模板渲染后，kubernetes 创建资源之前执行 |
| post-install | `安装后`。kubernetes 创建资源后执行 |
| pre-delete | `预删除`。在 kubernetes 删除任何资源之前执行删除请求 |
| post-delete | `删除后`。删除所有 release 资源后执行 |
| pre-upgrade | `升级前`。在模板渲染后，但在任何资源升级之前执行 |
| post-upgrade | `升级后`。在所有资源升级后执行 |
| pre-rollback | `预回滚`。在模板渲染后，任何资源回滚前执行 |
| post-rollback | `回滚后`。在修改所有资源后执行 |

###  生命周期

Hooks 允许开发人员在 release 生命周期的关键节点执行操作。比如，我们执行 `helm install` 安装命令时 release 的生命周期如下所示：

- 用户运行命令 `helm install foo`
- 调用 Helm 仓库的安装 API
- 经过验证后，仓库渲染 foo 模板
- 仓库加载渲染后的模板到 kubernetes 中
- 仓库返回 release 资源对象（和其他数据）到客户端
- 客户端退出

Helm 为 install 生命周期定义了两个 Hooks：`pre-install` 和 `post-install`。如果对于 foo Chart 使用这两个 Hooks，那么生命周期就变成如下所示：

- 用户运行命令 `helm install foo`
- 调用 Helm 仓库的安装 API
- 安装 `crds/` 文件夹中定义的资源对象
- 经过验证后，仓库渲染 foo 模板
- 仓库准备执行 `pre-install` hook（加载 hook 资源到 kubernetes 中）
- 仓库根据权重对 hooks 进行排序（默认权重为 0，相同权重的 hooks 会按照升序进行排序）
- 仓库首先加载最低权重的 hooks（从负到正）
- 仓库等待，直到 hook 准备就绪（除了 CRDs）
- 仓库加载渲染后的模板到 kubernetes 中。如果设置了 `--wait` 标志，仓库将等待直到所有资源都处于就绪状态，在就绪之前不会运行 `post-upgrade` hook。
- 仓库执行 `post-upgrade` hook（加载 hook 资源到 kubernetes 中）
- 仓库等待，直到 hook 准备就绪
- 仓库返回 release 资源对象（和其他数据）到客户端
- 客户端退出

等到 hook 准备就绪的特性，取决于 hook 中声明的资源对象类型，比如是 `Job` 或是 `Pod` 资源类型，Helm 将会等待直到作业完成。如果这个 hook 失败，那么 Release 的发布也是失败的。

Hook 创建的资源不作为 Release 的一部分进行跟踪或管理。当 Helm 验证 Hook 达到了就绪状态，就不会再管该 Hook 资源了。换句话说，如果使用 Hook 创建资源，无法使用 `helm uninstall` 删除资源，如果想要销毁这类资源，需要将 `helm.sh/hook-delete-policy` 注释添加到 hook 模板文件。

## 3. 写一个 Hook

Hook 的写法和普通模板是一样的，可以使用模板函数和对象，比如：`.Values`、`.Release`、`.Template`等，唯一和普通模板有区别的地方是在 `metadata` 部分包含一些特殊的注释 `annotations`。

比如我们需要在安装后 `post-install` 执行 hook 运行一个 job，向 `templates/post-install-job.yaml` 文件中写入如下内容：

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: "{{ .Release.Name }}"
  labels:
    app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
    app.kubernetes.io/instance: {{ .Release.Name | quote }}
    app.kubernetes.io/version: {{ .Chart.AppVersion }}
    helm.sh/chart: "{{ .Chart.Name }}-{{ .Chart.Version }}"
  annotations:
    # 通过添加 annotations，这个资源会被视为 hook。如果没有这行注释，这个 Job 资源只会当做 Release 的一部分。
    "helm.sh/hook": post-install  # hook 的类型
    "helm.sh/hook-weight": "-5"   # hook 的权重
    "helm.sh/hook-delete-policy": hook-succeeded   # hook 的删除方式
spec:
  template:
    metadata:
      name: "{{ .Release.Name }}"
      labels:
        app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
        app.kubernetes.io/instance: {{ .Release.Name | quote }}
        helm.sh/chart: "{{ .Chart.Name }}-{{ .Chart.Version }}"
    spec:
      restartPolicy: Never
      containers:
      - name: post-install-job
        image: "alpine:3.3"
        command: ["/bin/sleep","{{ default "10" .Values.sleepyTime }}"]
```

一个资源可以部署多个 hook，写法如下：

```yaml
  annotations:
    "helm.sh/hook": post-install,post-upgrade
```

为 hook 设置权重可以帮助确定执行顺序，权重可以是正数或是负数，但是必须是字符串。当 Helm 开始执行某个特定类型的 hook 时（比如：`pre-install` hooks、`post-install` hooks），会按升序对这些 hook 进行排序：

```yaml
  annotations:
    "helm.sh/hook-weight": "5"
```

还可以定义 hook 的删除策略：

```yaml
  annotations:
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
```

与删除策略有关的注释值有：

- `before-hook-creation`：在新 hook 创建之前删除以前的 hook。这是默认的删除策略。
- `hook-succeeded`：在 hook 成功执行后删除 hook 资源。
- `hook-failed`：如果 hook 在执行期间失败就删除该 hook 资源。

## 4. Chart 仓库

本节介绍如何创建和使用 Helm Chart repo。仓库的主要用途是存储和分享 chart 包。

####  创建 Chart 仓库

Chart 仓库是带有一个 `index.yaml` 文件和任意个打包文件并能回答 GET 请求的 HTTP 服务器。如果想要分享 Chart 包，最好是先将其上传到仓库中。

当选择托管 Chart 仓库时可以有多种选择，比如：Google 云端存储，Amazon S3 存储桶，Github Pages，或者是搭建自己的服务器。

####  Chart 仓库结构

一个 Chart 仓库由两部分组成：

- `index.yaml` 文件：包含 Chart 仓库中所有 Chart 的索引。
- Chart 包：这些打包文件通常都是在 index.yaml 文件中列出的。

比如，`https://example.com/charts` 仓库的文件结构如下所示：

```yaml
charts/
  |
  |- index.yaml
  |
  |- alpine-0.1.2.tgz
  |
  |- alpine-0.1.2.tgz.prov
```

在这个例子中，index.yaml 文件中只包含一个 Chart 的信息。即：Alpine Chart，对应的下载链接地址为 `https://example.com/charts/alpine-0.1.2.tgz`。

####  index.yaml 索引文件

index.yaml 索引文件中包含关于包的元数据。使用 `helm repo index` 命令根据包含打包文件的本地目录生成索引文件。

下面是 index.yaml 文件的一个示例：

```yaml
apiVersion: v1
entries:
  alpine:
    - created: 2016-10-06T16:23:20.499814565-06:00
      description: Deploy a basic Alpine Linux pod
      digest: 99c76e403d752c84ead610644d4b1c2f2b453a74b921f422b9dcb8a7c8b559cd
      home: https://helm.sh/helm
      name: alpine
      sources:
      - https://github.com/helm/helm
      urls:
      - https://technosophos.github.io/tscharts/alpine-0.2.0.tgz
      version: 0.2.0
    - created: 2016-10-06T16:23:20.499543808-06:00
      description: Deploy a basic Alpine Linux pod
      digest: 515c58e5f79d8b2913a10cb400ebb6fa9c77fe813287afbacf1a0b897cd78727
      home: https://helm.sh/helm
      name: alpine
      sources:
      - https://github.com/helm/helm
      urls:
      - https://technosophos.github.io/tscharts/alpine-0.1.0.tgz
      version: 0.1.0
  nginx:
    - created: 2016-10-06T16:23:20.499543808-06:00
      description: Create a basic nginx HTTP server
      digest: aaff4545f79d8b2913a10cb400ebb6fa9c77fe813287afbacf1a0b897cdffffff
      home: https://helm.sh/helm
      name: nginx
      sources:
      - https://github.com/helm/charts
      urls:
      - https://technosophos.github.io/tscharts/nginx-1.1.0.tgz
      version: 1.1.0
generated: 2016-10-06T16:23:20.499029981-06:00
```

####  托管 Chart 库

这里介绍两种常用的方式，一种是使用 GitHub Pages 托管，另一种是使用普通的 Web 服务器。

**方法一：使用 GitHub Pages 托管**

GitHub 可以使用两种不同的方式提供静态 web 页面：

1. 通过配置项目来提供 `docs/` 目录下的文件；
2. 通过配置项目为特定分支提供服务。

这里采用第二种方式提供演示。在仓库中新建名为 `gh-pages` 的分支。

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200129-1580284022164/wm)

然后将 `gh-pages` 分支设置为 Github Pages，点击 repo Settings，向下滚动到 GitHub Pages，并按照如下方式进行设置：

![图片描述](https://doc.shiyanlou.com/courses/uid600404-20200129-1580284870990/wm)

**方法二：使用普通的 Web 服务器**

如果配置普通的 Web 服务器存储 Helm Chart，需要确保：

- `index.yaml` 文件和 Chart 都处于服务器目录中；
- 无需认证就可以访问 `index.yaml` 文件；
- yaml 文件格式是正确的。

####  管理 Chart 库

准备好打包 Chart，创建一个新目录，然后将打包 Chart 移动到该目录下：

```bash
# 打包
$ helm package docs/examples/alpine/
# 创建新目录
$ mkdir fantastic-charts
# 将打包好的文件移动到新目录下
$ mv alpine-0.1.0.tgz fantastic-charts/
# helm repo index 命令为 fantastic-charts 目录生成 index.yaml 文件，https://xxx.com 表示的是远程库的 URL
$ helm repo index fantastic-charts --url https://xxx.com
```

如果在 fantastic-charts 目录下添加了新文件，可以使用 `helm repo index` 命令重新生成新的索引，或是使用 `--merge` 参数向 index.yaml 文件增量添加新 Chart 索引。

如果要分享 Chart，只需要提供仓库 URL 即可，完整命令为 `helm repo add [NAME] [URL]`。比如：

```bash
$ helm repo add fantastic-charts https://xxx.com
$ helm repo list
fantastic-charts    https://xxx.com
```

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Helm Hooks 简介
- 写一个 Hook
- Chart 仓库

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。

