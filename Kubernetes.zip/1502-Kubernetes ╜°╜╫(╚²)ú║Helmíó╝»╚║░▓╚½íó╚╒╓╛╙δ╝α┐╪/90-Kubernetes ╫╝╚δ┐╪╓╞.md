---
show: step
version: 1.0
---

# Kubernetes 准入控制

## 1.实验介绍

####  实验内容

本次实验向大家介绍 Kubernetes 准入控制（Admission Control）。

####  实验知识点

- Admission Control 简介
- Admission Control 插件列表
- 例子：一个 Webhook 准入控制器

####  推荐阅读

- [Using Admission Controllers](https://kubernetes.io/docs/reference/access-authn-authz/admission-controllers/)
- [admission-controller-webhook-demo](https://github.com/stackrox/admission-controller-webhook-demo)

## 2. Admission Control 简介

当账户经过 API Server 的认证、授权之后，还需要经过准入机制才能够获得 API Server 真正的响应。准入机制由一系列的控制器列表组成，它们被编译成 kube-apiserver 二进制文件，并且只能由集群管理员进行配置。

在这些控制器列表中，有两个特殊的控制器：`MutatingAdmissionWebhook` 和 `ValidatingAdmissionWebhook`。它们分别对 [Admission Control Webhooks](https://kubernetes.io/docs/reference/access-authn-authz/extensible-admission-controllers/#admission-webhooks) 执行 Mutating（变更） 和 Validating（验证）。

对于很多的 kubernetes 高级功能都是需要 Admission Control 开启的。Admission Control 通过在 API Server 中的 `--enable-admission-plugins` 参数进行设置，对于多个插件列表，它们之间使用逗号进行分隔，比如：`kube-apiserver --enable-admission-plugins=NamespaceLifecycle,LimitRanger ...`。如果想要关闭插件，则使用参数 `--disable-admission-plugins`。

## 3. Admission Control 插件列表

大家如果想要查看开启了哪些 Admission Control 插件，可以执行如下命令查看：

```bash
kube-apiserver -h | grep enable-admission-plugins
```

下面给大家详细介绍一下这些插件的作用：

- `AlwaysPullImages`：在启动容器之前总是尝试重新下载镜像。这对于多租户场景特别有用，容器启动之前可以使用租户的密钥下载镜像，保证镜像的安全性。
- `DefaultStorageClass`：默认的 StorageClass。当 PVC 资源对象创建时，如果没有指定 StorageClass，就会使用之前设置的默认 StorageClass。
- `DefaultTolerationSeconds`：对于没有设置容忍 `node.kubernetes.io/not-ready:NoExecute` 或是 `node.alpha.kubernetes.io/unreachable:NoExecute` 的 Pod，设置默认容忍时间为 5 min。
- `EventRateLimit`：用于应对事件密集情况下对 API Server 造成的洪水攻击。
- `ExtendedResourceToleration`：自动为申请特殊资源的 Pod 加入 Toleration 定义。
- `ImagePolicyWebhook`：允许后端的 Webhook 程序完成准入功能。通过启动参数 `--admission-control-config-file` 进行配置。
- `LimitPodHardAntiAffinityTopology`：启用 Pod 的反亲和性调度策略设置。在设置亲和性策略参数 `requiredDuringSchedulingRequiredDuringExecution` 时需要将 topologyKey 的值设置为 `kubernetes.io/hostname`，否则 Pod 会被拒绝创建。
- `LimitRanger`：监控进入的请求，保证请求符合在命名空间中定义的 LimitRanger 对象的资源限制。还可以为 Pod 设置默认的资源请求值，启用该插件后，会为 default 命名空间中的所有 Pod 都设置 0.1CPU 的资源请求。
- `MutatingAdmissionWebhook`：变更符合要求的请求内容，Webhook 以串行的方式顺序执行。
- `NamespaceAutoProvision`：检测所有进入的具备命名空间的资源请求，如果其中引用的命名空间不存在，就自动创建命名空间。
- `NamespaceExists`：检测所有进入的具备命名空间的资源请求，如果其中引用的命名空间不存在，就拒绝这一创建过程。
- `NamespaceLifecycle`：当命名空间删除时不会在其中创建新的资源对象，也会拒绝对于不存在的命名空间的访问请求，同时会阻止删除系统保留的 3 个命名空间：`default`、`kube-system`、`kube-public`。删除命名空间的时候还会删除该命名空间下的所有资源对象。
- `NodeRestriction`：限制 kubelet 对 Node 和 Pod 的修改行为。
- `OwnerReferencesPermissionEnforcement`：一个用户如果想要修改对象的 `metadata.ownerReferences`，必须具备 delete 权限。
- `PodNodeSelector`：读取命名空间的 annotation 字段和全局配置，对命名空间中对象的 node selectors 设置默认值或限制其取值。
- `PersistentVolumeClaimResize`：对 PVC 发起的 resize 请求进行额外校验。
- `PodPreset`：使用 PodSelector 选择 Pod，为符合条件的 Pod 进行注入。
- `PodSecurityPolicy`：在创建或修改 Pod 时决定是否根据 Pod 的 security context 和可用的 PodSecurityPolicy 对 Pod 的安全策略进行控制。
- `PodTolerationRestriction`：将 Pod 和其命名空间的 Toleration 进行冲突检测，如果存在冲突就拒绝 Pod 的创建。将命名空间和 Pod 的 Toleration 进行合并，将合并结果与命名空间中的白名单进行比较，如果合并结果不在白名单内就拒绝创建。如果不存在命名空间级的默认 Toleration 和白名单，就采用集群级别默认的 Toleration 和白名单。
- `Priority`：使用 `priorityClassName` 字段确定优先级，如果没有找到对应的 Priority Class，该 Pod 就会被拒绝。
- `ResourceQuota`：用于命名空间下的资源配额管理。
- `SecurityContextDeny`：使在 Pod 中定义的 SecurityContext 选项全部失效。SecurityContext 在容器中定义了操作系统级别的安全设定。
- `ServiceAccount`：让 ServiceAccount 实现了自动化。
- `StorageObjectInUseProtection`：在新创建的 PV 或 PVC 中加入 `kubernetes.io/pv-protection` 或 `kubernetes.io/pvc-protection` 的 finalizer。如果想删除 PV 或 PVC，需要等到所有 finalizer 的工作都完成，才会执行删除操作。
- `ValidatingAdmissionWebhook`：针对符合其选择要求的请求调用校验 Webhook。目标 Webhook 会以并行方式运行，如果其中任何一个 Webhook 拒绝了这个请求，那么请求失败。

官方推荐开启的准入控制插件如下：

```text
--enable-admission-plugins=NamespaceLifecycle,LimitRanger,ServiceAccount,PersistentVolumeLabel,DefaultStorageClass,ResourceQuota,DefaultTolerationSeconds
```

注意，上述插件的顺序也是非常重要的。

## 4. 例子：一个 Webhook 准入控制器

准入控制过程有两个阶段：第一个是执行变更阶段，第二个是验证阶段。比如：`LimitRanger` 控制器既可以给 Pod 添加默认的资源限制（变更阶段），也可以限制 Pod 的资源使用不超过命名空间设置的限定值（验证阶段）。

在前面提到的多个控制器中，有两个控制器比较特别：`MutatingAdmissionWebhooks` 和 `ValidatingAdmissionWebhooks`。这两个控制器本身并不进行决策控制，它们的操作是从集群中 webhook 服务的 REST API 获得。这样就可以将准入控制的逻辑与 API Server 分离开，用户可以在集群中创建、更新或删除资源时执行自定义逻辑。

这两个控制器的区别在于：`MutatingAdmissionWebhooks` 可以变更对象，而 `ValidatingAdmissionWebhooks` 不能。`MutatingAdmissionWebhooks` 也可以拒绝请求，这时它的作用与 `ValidatingAdmissionWebhooks` 相同。

使用准入控制机制可以让集群更加安全。比如，在 kubernetes 集群中为了使用的方便性，设置了很多默认的缺省值，这种设置是以安全性作为代价的，其中一个就是默认情况下允许容器以 root 身份运行，尽管容器在某种程度上与底层主机是隔离的，但是以 root 身份运行容器确实可能会增加部署的风险。

下面我们编写一个自定义的 Webhook 准入控制器，对用户身份进行验证。

在集群中启动 dind 脚本，然后进入 kube-master 容器中修改 kube-apiserver.yaml 文件，添加 MutatingAdmissionWebhook 插件：

```bash
$ docker exec -it kube-master /bin/bash
root@kube-master:/# cd /etc/kubernetes/manifests
root@kube-master:/etc/kubernetes/manifests # vim kube-apiserver.yaml
# 在容器启动参数 enable-admission-plugin 中添加 MutatingAdmissionWebhook 插件
...
    - --enable-admission-plugins=NodeRestriction,MutatingAdmissionWebhook
...
```

修改静态 kube-apiserver Pod 启动参数后，集群会自动重启该 Pod。

然后在 `/home/shiyanlou` 目录下创建如下目录结构的文件，后面我们将会一一讲解这些文件的作用和代码：

```bash
$ cd /home/shiyanlou
$ tree
.
├── deployment
│   ├── deployment.yaml.template
│   └── generate-keys.sh
├── deploy.sh
└── examples
    ├── pod-with-conflict.yaml
    ├── pod-with-defaults.yaml
    └── pod-with-override.yaml
```

`deployment/generate-keys.sh` 文件主要用于申请自注册的 CA 证书（证书和私钥用于 webhook demo 服务），使用的 CN 名为 `webhook-server.webhook-demo.svc`，这就是服务在集群中的 DNS 名称。代码内容如下所示：

```bash
#!/usr/bin/env bash

: ${1?'missing key directory'}

key_dir="$1"

chmod 0700 "$key_dir"
cd "$key_dir"

# 生成 CA 证书和私钥
openssl req -nodes -new -x509 -keyout ca.key -out ca.crt -subj "/CN=Admission Controller Webhook Demo CA"
# 为 webhook 生成私钥
openssl genrsa -out webhook-server-tls.key 2048
# 为私钥生成证书签名请求（CSR），并使用 CA 的私钥对其进行签名
openssl req -new -key webhook-server-tls.key -subj "/CN=webhook-server.webhook-demo.svc" \
    | openssl x509 -req -CA ca.crt -CAkey ca.key -CAcreateserial -out webhook-server-tls.crt
```

`deployment/deployment.yaml.template` 文件内容如下所示：

```yaml
# 使用 Deployment 部署一个 webhook-server Pod，在 admission-controller-webhook-demo:latest 镜像中设置了函数使 /mutate 路径映射到 8443 端口。
apiVersion: apps/v1
kind: Deployment
metadata:
  name: webhook-server
  namespace: webhook-demo
  labels:
    app: webhook-server
spec:
  replicas: 1
  selector:
    matchLabels:
      app: webhook-server
  template:
    metadata:
      labels:
        app: webhook-server
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1234
      containers:
      - name: server
        image: stackrox/admission-controller-webhook-demo:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8443
          name: webhook-api
        volumeMounts:
        - name: webhook-tls-certs
          mountPath: /run/secrets/tls
          readOnly: true
      volumes:
      - name: webhook-tls-certs
        secret:
          secretName: webhook-server-tls
---
# 创建 webhook-server 服务，webhook 配置接收 HTTPS 请求总是 443 端口，这里服务端口映射到 Pod 的 8443 端口
apiVersion: v1
kind: Service
metadata:
  name: webhook-server
  namespace: webhook-demo
spec:
  selector:
    app: webhook-server
  ports:
    - port: 443
      targetPort: webhook-api
---
# 使用 MutatingWebhookConfiguration 资源对象创建一个控制器，这个配置定义了一个名为 webhook-server.webhook-demo.svc 的 Webhook，定义的规则为：在 webhook-demo 命名空间中，当 Pod 创建的时候向 webhook-server 服务的 /mutate URL 路径发送 HTTP POST 请求。
apiVersion: admissionregistration.k8s.io/v1beta1
kind: MutatingWebhookConfiguration
metadata:
  name: demo-webhook
webhooks:
  - name: webhook-server.webhook-demo.svc
    clientConfig:
      service:
        name: webhook-server # 服务名
        namespace: webhook-demo # 命名空间
        path: "/mutate" # 路径
      caBundle: ${CA_PEM_B64}
    rules:
      - operations: [ "CREATE" ]
        apiGroups: [""]
        apiVersions: ["v1"]
        resources: ["pods"]
```

`deploy.sh` 文件主要用于在当前集群中设置 webhook demo 环境变量，代码内容如下所示：

```bash
#!/usr/bin/env bash

set -euo pipefail

basedir="$(dirname "$0")/deployment"
keydir="$(mktemp -d)"

# 在临时目录中生成密钥
echo "Generating TLS keys ..."
"${basedir}/generate-keys.sh" "$keydir"

# 创建 webhook-demo 命名空间
echo "Creating Kubernetes objects ..."
kubectl create namespace webhook-demo

# 创建 TLS 密钥
kubectl -n webhook-demo create secret tls webhook-server-tls \
    --cert "${keydir}/webhook-server-tls.crt" \
    --key "${keydir}/webhook-server-tls.key"

# 读取 pem 编码的 CA 证书，使用 base64 解码，替换 deployment.yaml.template YAML 文件中的 ${CA_PEM_B64} 对应的变量，然后创建资源对象
ca_pem_b64="$(openssl base64 -A <"${keydir}/ca.crt")"
sed -e 's@${CA_PEM_B64}@'"$ca_pem_b64"'@g' <"${basedir}/deployment.yaml.template" \
    | kubectl create -f -

# 删除密钥目录
rm -rf "$keydir"

echo "The webhook server has been deployed and configured!"
```

接下来，我们运行 3 个 Pod 进行测试：

- 一个不指定安全上下文的 Pod，这个 Pod 会以非 root、uid 1234 运行，写入 `pod-with-defaults.yaml` 文件中；
- 一个明确指定安全上下文的 Pod，这个 Pod 会以 root 形式运行，写入 `pod-with-override.yaml` 文件中；
- 一个配置有冲突的 Pod，这个 Pod 配置为以非 root、uid 0 运行，写入 `pod-with-conflict.yaml` 文件中。这个 Pod 就不会创建成功。

`examples/pod-with-defaults.yaml` 文件内容如下所示：

```yaml
# 不指定安全上下文，如果没有 webhook，这个 Pod 会以 root、uid 0 运行；由于设置了 webhook 会变更这个 Pod 以非 root、uid 1234 运行。
apiVersion: v1
kind: Pod
metadata:
  name: pod-with-defaults
  labels:
    app: pod-with-defaults
spec:
  restartPolicy: OnFailure
  containers:
    - name: busybox
      image: busybox
      command: ["sh", "-c", "echo I am running as user $(id -u)"]
```

`examples/pod-with-override.yaml` 文件内容如下所示：

```yaml
# 指定安全上下文，这个 Pod 需要以 root 形式运行。这样部署的话，有没有 webhook 都是一样的。
apiVersion: v1
kind: Pod
metadata:
  name: pod-with-override
  labels:
    app: pod-with-override
spec:
  restartPolicy: OnFailure
  securityContext:
    runAsNonRoot: false
  containers:
    - name: busybox
      image: busybox
      command: ["sh", "-c", "echo I am running as user $(id -u)"]
```

`examples/pod-with-conflict.yaml` 文件内容如下所示：

```yaml
# 指定安全上下文，以非 root、uid 0 运行。如果没有设置 webhook 的话，这个 Pod 是可以被创建的。由于这里设置了 webhook，没有验证通过就会返回 CreateContainerConfigError 状态使得这个 Pod 无法被创建。
apiVersion: v1
kind: Pod
metadata:
  name: pod-with-conflict
  labels:
    app: pod-with-conflict
spec:
  restartPolicy: OnFailure
  securityContext:
    runAsNonRoot: true
    runAsUser: 0
  containers:
    - name: busybox
      image: busybox
      command: ["sh", "-c", "echo I am running as user $(id -u)"]
```

现在我们来进行验证，首先是部署：

```bash
$ chmod +x deployment/generate-keys.sh
$ bash deploy.sh
Generating TLS keys ...
Generating a 2048 bit RSA private key
..............................+++
......+++
writing new private key to 'ca.key'
-----
Generating RSA private key, 2048 bit long modulus
.........+++
.......+++
e is 65537 (0x10001)
Signature ok
subject=/CN=webhook-server.webhook-demo.svc
Getting CA Private Key
Creating Kubernetes objects ...
namespace/webhook-demo created
secret/webhook-server-tls created
deployment.apps/webhook-server created
service/webhook-server created
mutatingwebhookconfiguration.admissionregistration.k8s.io/demo-webhook created
The webhook server has been deployed and configured!
```

查看创建好的 Pod 和 mutatingwebhookconfigurations：

```bash
$ kubectl -n webhook-demo get pods
NAME                              READY   STATUS    RESTARTS   AGE
webhook-server-7bb766fcfd-5h9vk   1/1     Running   0          114s
$ kubectl get mutatingwebhookconfigurations
NAME           CREATED AT
demo-webhook   2020-01-02T07:49:41Z
```

分别使用 3 个 Pod 对 Webhook 进行验证，第一个是 default Pod：

```bash
$ kubectl create -f examples/pod-with-defaults.yaml
pod/pod-with-defaults created
$ kubectl get pod/pod-with-defaults -o yaml
...
  securityContext:
    runAsNonRoot: true
    runAsUser: 1234
...
```

查看 default Pod 的日志，可以看到 Pod 创建成功，以 uid 1234 运行：

```bash
$ kubectl logs pod-with-defaults
I am running as user 1234
```

第二个是 override Pod，查看结果可以看到这个 Pod 是以 root、uid 0 运行：

```bash
$ kubectl create -f examples/pod-with-override.yaml
pod/pod-with-override created
$ kubectl get pod/pod-with-override -o yaml
...
  securityContext:
    runAsNonRoot: false
...
$ kubectl logs pod-with-override
I am running as user 0
```

最后创建 conflict Pod，由于配置冲突，将不会创建成功：

```bash
$ kubectl create -f examples/pod-with-conflict.yaml
Error from server: error when creating "examples/pod-with-conflict.yaml": admission webhook "webhook-server.webhook-demo.svc" denied the request: runAsNonRoot specified, but runAsUser set to 0 (the root user)
```

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Admission Control 简介
- Admission Control 插件列表
- 例子：一个 Webhook 准入控制器

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
