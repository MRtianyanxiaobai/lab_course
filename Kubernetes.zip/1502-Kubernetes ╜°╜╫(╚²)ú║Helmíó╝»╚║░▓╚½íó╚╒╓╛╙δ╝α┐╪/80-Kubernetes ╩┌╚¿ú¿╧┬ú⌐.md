---
show: step
version: 1.0
---

# Kubernetes 授权（下）

## 1.实验介绍

####  实验内容

本次实验继续为大家讲解 Kubernetes 授权（下）的内容。

####  实验知识点

- Node 授权模式
- ABAC 授权模式
- Webhook 授权模式

####  推荐阅读

- [Using ABAC Authorization](https://kubernetes.io/docs/reference/access-authn-authz/abac/)
- [Using Node Authorization](https://kubernetes.io/docs/reference/access-authn-authz/node/)
- [Webhook Mode](https://kubernetes.io/docs/reference/access-authn-authz/webhook/)

## 2. Node 授权模式

Node 授权模式用途比较单一，主要是对 kubelets 发出的 API 请求进行限制。需要在 API Server 启动时指明参数 `--authorization-mode=Node`。

Node 授权模式允许 kubelet 操作 API，主要包括：

- `可读操作`：涉及 services、endpoints、nodes、pods、secrets、configmaps、绑定到 kubelet 所在节点的 pv 和 pvc。
- `可写操作`：node 和 node status、pods 和 pod status、events。
- `授权操作`：可读/可写 API 证书。

为了能够通过授权，kubelets 必须使用一个凭证标识它们在 `system:nodes` 组中，并使用 `system:node:<nodeName>` 中的用户名。

## 3. ABAC 授权模式

如果使用 ABAC 授权模式，需要在 API Server 启动时指明参数 `--authorization-policy-file=SOME_FILENAME`（授权策略文件路径）和 `--authorization-mode=ABAC`（指明采用 ABAC 模式）。

授权策略文件中的每一行都是 Map 类型的 JSON 对象。每一行都被称为“访问策略对象”。

每个授权策略都有 3 个属性：

- `apiVersion`：为 `abac.authorization.kubernetes.io/v1beta1`。
- `kind`：为 `Policy`。
- `spec`：详细的策略设置。

对于 `spec` 有 4 个字段，如下：

- `主体属性`：
    - `user`：用户名。来源于 Token 文件或是认证用户的用户名。
    - `group`：用户组。可以设置为 `system:authenticated`(匹配所有已认证的请求) 或是 `system:unauthenticated`(匹配所有未认证的请求)。
- `资源属性`：
    - `apiGroup`：API 组。比如 extensions 或是 *（匹配所有 API 组）。
    - `namespace`：命名空间。比如 kube-system 或是 *（匹配所有命名空间）。
    - `resource`：API 资源对象。比如 pods 或是 *（匹配所有资源对象）。
- `非资源属性`：
    - `nonResourcePath`：非资源对象类 URL 路径。比如 /version 或是 /apis，* 表示匹配所有非资源对象类的请求路径，/foo/* 表示匹配 /foo 路径下的所有子路径。
- `readonly`：只读标识。当值为 true 时，对于所有的资源属性只允许 get、list、和 watch 操作，对于所有的非资源属性只允许 get 操作。

#### 授权算法

一个请求中的属性需要与授权策略中定义的属性相对应。对于未知的属性会设置为空值（比如：empty、0、false 等）。将请求中的属性与授权策略中的属性进行逐一匹配，只要有一条匹配成功，那么该请求就通过了授权。

一些策略设置技巧：

- 如果要允许所有经过身份认证的用户执行某些操作，可以设置 group 属性为 `system: authenticated`。
- 如果要允许所有未经过身份认证的用户执行某些操作，可以设置 group 属性为 `system: unauthenticated`。
- 如果要允许一个用户做任何事情，可以将 apiGroup、namespace、resource、nonResourcePath 都设置为 `*`。

#### 使用 kubectl

kubectl 使用 API Server 的 /api 和 /apis 端点发现服务资源类型。并通过 /openapi/v2 查询 create/update 命令发送给服务器的对象。

当使用 ABAC 授权策略时，需要在 nonResourcePath 属性中设置的特殊资源包括：

- 用于 API 版本协商的 `/api`、`/api/*`、`/apis`、`/apis/*`。
- 获取版本信息的 `/version`。
- 创建或是更新操作的 `/swaggerapi/*`。

#### 使用 ServiceAccount

每个 ServiceAccount 会自动生成一个 ABAC 用户名，命名规则为 `system:serviceaccount:<namespace>:<serviceaccountname>`。比如创建一个新的 foo 命名空间服务账户的名称为 default，那么它对应的命名规则就是 `system:serviceaccount:foo:default`。

比如设置在 kube-system 命名空间中的 default ServiceAccount 具有所有权限，那么定义的规则为：

```json
{"apiVersion":"abac.authorization.kubernetes.io/v1beta1","kind":"Policy","spec":{"user":"system:serviceaccount:kube-system:default","namespace":"*","resource":"*","apiGroup":"*"}}
```

当定义了新的策略后，需要重启 API Service 才能让设置生效。

#### 例子

下面展示一些策略定义例子，供大家参考：

1. 允许用户 alice 对所有资源做任何操作：

```json
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"user": "alice", "namespace": "*", "resource": "*", "apiGroup": "*"}}
```

2. kubelet 可以读取任意 Pod：

```json
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"user": "kubelet", "namespace": "*", "resource": "pods", "readonly": true}}
```

3. kubelet 可以读写 Event 对象：

```json
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"user": "kubelet", "namespace": "*", "resource": "events"}}
```

4. 用户 Bob 只能读取 projectCaribou 命名空间下的 Pod：

```json
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"user": "bob", "namespace": "projectCaribou", "resource": "pods", "readonly": true}}
```

5. 任何用户都可以对非资源类路径进行只读请求：

```json
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"group": "system:authenticated", "readonly": true, "nonResourcePath": "*"}}
{"apiVersion": "abac.authorization.kubernetes.io/v1beta1", "kind": "Policy", "spec": {"group": "system:unauthenticated", "readonly": true, "nonResourcePath": "*"}}
```

## 4. Webhook 授权模式

Webhook 是调用外部的 REST 服务对账户进行授权。通过参数 `--authorization-webhook-config-file=SOME_FILENAME`（HTTP 配置文件）设置远端授权服务的信息，并且通过参数 `--runtime-config=authorization.k8s.io/v1beta1=true` 启用拓展。

Webhook 定义了一个 HTTP 回调接口，实现 Webhook 的应用会在指定事件发生时，向一个 URL 地址发送（POST）通知消息。

#### 配置文件格式

配置文件使用 kubeconfig 文件格式，其中 `clusters` 指的是远端服务，`users` 指的是 API Server webhook。

下面的例子是一个使用 HTTPS 客户端认证的配置：

```yaml
# 版本号
apiVersion: v1
# 资源对象类型
kind: Config
# clusters 指的是远端服务
clusters:
  - name: name-of-remote-authz-service
    cluster:
      # 验证远端服务的 CA
      certificate-authority: /path/to/ca.pem
      # 远端服务的 URL，必须使用 HTTPS
      server: https://authz.example.com/authorize

# users 指的是 API Server 的 Webhook 配置
users:
  - name: name-of-api-server
    user:
      client-certificate: /path/to/cert.pem # Webhook 插件使用的证书
      client-key: /path/to/key.pem          # 证书的 key

# kubeconfig 文件需要设置 context
current-context: webhook
contexts:
- context:
    cluster: name-of-remote-authz-service
    user: name-of-api-server
  name: webhook
```

当开始授权时，API Server 会生成一个 `api.authorization.v1beta1.SubjectAccessReview` 资源对象描述操作信息（包含尝试访问资源的请求动作的描述、以及被访问资源的属性），当进行 JSON 序列化之后 POST 出来。

下面的例子表示希望获取 Pod 列表：

```json
{
  "apiVersion": "authorization.k8s.io/v1beta1",
  "kind": "SubjectAccessReview",
  "spec": {
    "resourceAttributes": {
      "namespace": "kittensandponies",
      "verb": "get",
      "group": "unicorn.example.org",
      "resource": "pods"
    },
    "user": "jane",
    "group": [
      "group1",
      "group2"
    ]
  }
}
```

远端服务需要填充 `status` 字段，并返回是否允许访问的结果。

比如允许访问就应该返回：

```json
{
  "apiVersion": "authorization.k8s.io/v1beta1",
  "kind": "SubjectAccessReview",
  "status": {
    "allowed": true
  }
}
```

不允许访问就返回：

```json
{
  "apiVersion": "authorization.k8s.io/v1beta1",
  "kind": "SubjectAccessReview",
  "status": {
    "allowed": false,
    "reason": "user does not have read access to the namespace"
  }
}
```

查询非资源路径，比如 /debug：

```json
{
  "apiVersion": "authorization.k8s.io/v1beta1",
  "kind": "SubjectAccessReview",
  "spec": {
    "nonResourceAttributes": {
      "path": "/debug",
      "verb": "get"
    },
    "user": "jane",
    "group": [
      "group1",
      "group2"
    ]
  }
}
```

非资源路径包括：`/api`、`/apis`、`/metrics`、`/resetMetrics`、`/logs`、`/debug`、`/healthz`、`/swagger-ui/`、`/swaggerapi/`、`/ui` 和 `/version`。这其中，通常对于 `/api`、`/api/*`、`/apis`、`/apis/*` 和 `/version` 默认允许授权，而其他的非资源路径默认禁止。

## 5. 实验总结

本次实验我们向大家介绍了如下知识点：

- Node 授权模式
- ABAC 授权模式
- Webhook 授权模式

请务必保证自己能够动手完成整个实验，只看文字很简单，真正操作的时候会遇到各种各样的问题，解决问题的过程才是收获的过程。
